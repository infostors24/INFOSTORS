-- =========================================================================
-- INFOSTORS MASTER ECOMMERCE PLATFORM MIGRATION (NON-DESTRUCTIVE)
-- Migration: 20260927000006_master_ecommerce_features.sql
-- Covers: Coupons, Flash Sales, Reviews, Returns, Refunds, Loyalty, Wallet, Offers, Vendors
-- =========================================================================

-- 1. COUPONS & DISCOUNTS
CREATE TABLE IF NOT EXISTS public.coupons (
  id text PRIMARY KEY,
  code text UNIQUE NOT NULL,
  discount_type text NOT NULL CHECK (discount_type IN ('percentage', 'fixed')),
  discount_value numeric(12,2) NOT NULL,
  min_order_value numeric(12,2) NOT NULL DEFAULT 0,
  max_discount numeric(12,2),
  start_date timestamptz NOT NULL,
  expiry_date timestamptz NOT NULL,
  usage_limit integer,
  usage_count integer NOT NULL DEFAULT 0,
  per_customer_limit integer NOT NULL DEFAULT 1,
  first_order_only boolean NOT NULL DEFAULT false,
  is_active boolean NOT NULL DEFAULT true,
  applicable_categories text[],
  applicable_products text[],
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 2. FLASH SALES
CREATE TABLE IF NOT EXISTS public.flash_sales (
  id text PRIMARY KEY,
  title text NOT NULL,
  subtitle text,
  start_date timestamptz NOT NULL,
  end_date timestamptz NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  discount_percentage numeric(5,2) NOT NULL DEFAULT 0,
  products jsonb NOT NULL DEFAULT '[]'::jsonb,
  banner_image text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 3. REVIEWS & RATINGS
CREATE TABLE IF NOT EXISTS public.reviews (
  id text PRIMARY KEY,
  product_id text NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  customer_id text REFERENCES public.customers(id) ON DELETE SET NULL,
  customer_name text NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text NOT NULL,
  images text[],
  verified_purchase boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'approved' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 4. RETURN REQUESTS
CREATE TABLE IF NOT EXISTS public.return_requests (
  id text PRIMARY KEY,
  order_id text NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  customer_id text REFERENCES public.customers(id) ON DELETE SET NULL,
  customer_name text NOT NULL,
  customer_phone text NOT NULL,
  customer_email text NOT NULL,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  reason text NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'requested' CHECK (status IN ('requested', 'approved', 'pickup_scheduled', 'returned', 'completed', 'rejected')),
  admin_notes text,
  evidence_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 5. REFUND RECORDS
CREATE TABLE IF NOT EXISTS public.refund_records (
  id text PRIMARY KEY,
  return_id text REFERENCES public.return_requests(id) ON DELETE SET NULL,
  order_id text NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  customer_id text REFERENCES public.customers(id) ON DELETE SET NULL,
  customer_name text,
  amount numeric(12,2) NOT NULL,
  method text NOT NULL DEFAULT 'original_payment' CHECK (method IN ('original_payment', 'wallet', 'manual')),
  status text NOT NULL DEFAULT 'requested' CHECK (status IN ('requested', 'approved', 'processing', 'completed', 'rejected', 'failed')),
  failure_reason text,
  transaction_ref text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz
);

-- 6. LOYALTY TRANSACTIONS
CREATE TABLE IF NOT EXISTS public.loyalty_transactions (
  id text PRIMARY KEY,
  customer_id text NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  points integer NOT NULL,
  type text NOT NULL CHECK (type IN ('earned', 'redeemed', 'adjusted', 'expired')),
  description text NOT NULL,
  order_id text REFERENCES public.orders(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 7. WALLET TRANSACTIONS
CREATE TABLE IF NOT EXISTS public.wallet_transactions (
  id text PRIMARY KEY,
  customer_id text NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  amount numeric(12,2) NOT NULL,
  type text NOT NULL CHECK (type IN ('credit', 'debit')),
  description text NOT NULL,
  reference_id text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 8. PROMOTIONAL OFFERS
CREATE TABLE IF NOT EXISTS public.promotional_offers (
  id text PRIMARY KEY,
  title text NOT NULL,
  description text NOT NULL,
  code text,
  banner_image text,
  category_id text REFERENCES public.categories(id) ON DELETE SET NULL,
  min_amount numeric(12,2),
  discount_text text NOT NULL,
  badge text,
  valid_till timestamptz NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 9. VENDORS / MULTI-VENDOR
CREATE TABLE IF NOT EXISTS public.vendors (
  id text PRIMARY KEY,
  store_name text NOT NULL,
  owner_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text NOT NULL,
  commission_rate numeric(5,2) NOT NULL DEFAULT 10.0,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'pending', 'suspended')),
  logo_url text,
  address text,
  city text,
  state text,
  pincode text,
  pan text,
  gstin text,
  rating numeric(3,2) NOT NULL DEFAULT 5.0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 10. EXTEND STORE SETTINGS
ALTER TABLE public.store_settings ADD COLUMN IF NOT EXISTS feature_flags jsonb;
ALTER TABLE public.store_settings ADD COLUMN IF NOT EXISTS theme_settings jsonb;
ALTER TABLE public.store_settings ADD COLUMN IF NOT EXISTS layout_settings jsonb;
ALTER TABLE public.store_settings ADD COLUMN IF NOT EXISTS delivery_api_settings jsonb;
ALTER TABLE public.store_settings ADD COLUMN IF NOT EXISTS email_settings jsonb;
ALTER TABLE public.store_settings ADD COLUMN IF NOT EXISTS loyalty_settings jsonb;
ALTER TABLE public.store_settings ADD COLUMN IF NOT EXISTS whatsapp_api_settings jsonb;

-- 11. INDEXES FOR PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_coupons_code ON public.coupons(code);
CREATE INDEX IF NOT EXISTS idx_reviews_product_id ON public.reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_return_requests_order_id ON public.return_requests(order_id);
CREATE INDEX IF NOT EXISTS idx_return_requests_customer_id ON public.return_requests(customer_id);
CREATE INDEX IF NOT EXISTS idx_refund_records_order_id ON public.refund_records(order_id);
CREATE INDEX IF NOT EXISTS idx_loyalty_customer_id ON public.loyalty_transactions(customer_id);
CREATE INDEX IF NOT EXISTS idx_wallet_customer_id ON public.wallet_transactions(customer_id);
CREATE INDEX IF NOT EXISTS idx_offers_active ON public.promotional_offers(is_active);

-- 12. ENABLE ROW LEVEL SECURITY
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.flash_sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.return_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.refund_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loyalty_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promotional_offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendors ENABLE ROW LEVEL SECURITY;

-- 13. RLS POLICIES (SAFE NON-DESTRUCTIVE IF NOT EXISTS)
DO $$
BEGIN
  -- Coupons public read active
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Public can view active coupons') THEN
    CREATE POLICY "Public can view active coupons" ON public.coupons FOR SELECT USING (is_active = true);
  END IF;

  -- Flash sales public read active
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Public can view active flash sales') THEN
    CREATE POLICY "Public can view active flash sales" ON public.flash_sales FOR SELECT USING (is_active = true);
  END IF;

  -- Reviews public read approved
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Public can view approved reviews') THEN
    CREATE POLICY "Public can view approved reviews" ON public.reviews FOR SELECT USING (status = 'approved');
  END IF;

  -- Promotional offers public read active
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Public can view active promotional offers') THEN
    CREATE POLICY "Public can view active promotional offers" ON public.promotional_offers FOR SELECT USING (is_active = true);
  END IF;
END $$;
