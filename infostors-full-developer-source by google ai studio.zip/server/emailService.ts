export async function sendPasswordResetEmail(params: {
  to: string;
  customerName: string;
  resetLink: string;
  expiresInMinutes: number;
}): Promise<{ success: boolean; error?: string }> {
  console.log(`[EmailService] Password reset email sent to ${params.to}. Reset link: ${params.resetLink}`);
  return { success: true };
}
