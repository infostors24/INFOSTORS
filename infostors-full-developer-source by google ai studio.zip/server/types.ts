export interface CustomerRecord {
  id: string;
  fullName: string;
  email: string;
  mobile: string;
  passwordHash: string;
  createdAt: string;
  updatedAt: string;
}

export type SafeCustomer = Omit<CustomerRecord, 'passwordHash'>;

export interface PasswordResetRecord {
  id: string;
  customerId: string;
  tokenHash: string;
  expiresAt: number; // timestamp ms
  used: boolean;
  createdAt: string;
}

export interface AdminUser {
  email: string;
  name: string;
  picture?: string;
  role: 'admin' | 'main_admin';
  mobile?: string;
}

export type AdminRole = 'main_admin' | 'admin';
export type AdminStatus = 'active' | 'disabled';

export interface AdminRecord {
  id: string;
  email: string;
  fullName: string;
  mobile: string;
  role: AdminRole;
  status: AdminStatus;
  passwordHash?: string;
  createdAt: string;
  updatedAt?: string;
  createdBy?: string;
}

export type PaymentMethod = 'razorpay' | 'upi' | 'cod';
export type PaymentStatus = 'pending' | 'authorized' | 'paid' | 'failed' | 'refunded';
export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image?: string;
}

export interface OrderCustomer {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
}

export interface OrderRecord {
  id: string; // internal order ID, e.g. ORD-2026-XXXXXX
  customerId?: string;
  customer: OrderCustomer;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  finalAmount: number;
  currency: string; // 'INR'
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  razorpaySignature?: string;
  paymentFailureReason?: string;
  b2bDetails?: {
    companyName?: string;
    gstin?: string;
  };
  taxBreakdown?: {
    gstEnabled: boolean;
    gstRate: number;
    gstType: 'inclusive' | 'exclusive';
    gstAmount: number;
    storeGstin?: string;
  };
  createdAt: string;
  updatedAt: string;
  paidAt?: string;
  estimatedDeliveryDate?: string;
  courierPartner?: string;
  trackingId?: string;
  resolution?: string;
}

export type DeleteTargetType = 'order' | 'customer';
export type DeleteRequestStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'COMPLETED' | 'FAILED';

export interface DeleteRequestRecord {
  id: string;
  targetType: DeleteTargetType;
  targetId: string;
  targetSummary: string;
  requestedByEmail: string;
  requestedByName?: string;
  requestedByRole: AdminRole;
  reason: string;
  status: DeleteRequestStatus;
  createdAt: string;
  reviewedByEmail?: string;
  reviewedByName?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  completedAt?: string;
  error?: string;
}

export interface AuditLogRecord {
  id: string;
  adminEmail: string;
  adminName?: string;
  adminUid?: string;
  action: string;
  targetType: string;
  targetId: string;
  reason?: string;
  timestamp: string;
  result: 'SUCCESS' | 'FAILED' | 'REJECTED';
  details?: string;
}

export interface StoreSettingsRecord {
  storeName: string;
  tagline: string;
  logoUrl?: string;
  headerLogoHeight?: number;
  helpline: string;
  email: string;
  officeAddress: string;
  freeDeliveryMin: number;
  announcement: string;
  whatsapp: string;
  instagram: string;
  facebook: string;
  youtube: string;
  whatsappUrl?: string;
  returnWindow?: string;

  // Business Profile Details
  businessLegalName?: string;
  ownerName?: string;
  tradeName?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  pincode?: string;
  country?: string;
  phone?: string;
  website?: string;
  pan?: string;

  // Delivery Charge Configuration
  standardDeliveryCharge: number;
  enableFreeDeliveryThreshold: boolean;

  // Full Profile GST Configuration
  gstEnabled: boolean;
  gstin?: string;
  gstPercentage: number;
  gstType: 'inclusive' | 'exclusive';
  gstState?: string;
  showGstinOnInvoice: boolean;
  allowCustomerB2bGst: boolean;

  // App Install / PWA Configuration
  pwaSettings?: PwaSettingsRecord;

  // Master Extended Settings
  featureFlags?: FeatureFlagsRecord;
  themeSettings?: ThemeSettingsRecord;
  layoutSettings?: LayoutSettingsRecord;
  deliveryApiSettings?: DeliveryApiSettingsRecord;
  whatsAppApiSettings?: WhatsAppApiSettingsRecord;
  emailSettings?: EmailSettingsRecord;

  updatedAt?: string;
  updatedBy?: string;
}

export interface FeatureFlagsRecord {
  coupons: boolean;
  flashSale: boolean;
  reviews: boolean;
  returns: boolean;
  refunds: boolean;
  deliveryApi: boolean;
  whatsappApi: boolean;
  emailNotifications: boolean;
  loyalty: boolean;
  wallet: boolean;
  offers: boolean;
  multiVendor: boolean;
  advancedReports: boolean;
}

export interface ThemeSettingsRecord {
  mode: 'light' | 'dark' | 'system';
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  buttonColor: string;
  backgroundColor: string;
  cardStyle: 'elevated' | 'bordered' | 'minimal' | 'flat';
  borderRadius: 'none' | 'sm' | 'md' | 'lg' | 'xl' | 'full';
  typographyScale: 'compact' | 'normal' | 'large';
  headerStyle: 'modern' | 'minimal' | 'dense';
  sidebarStyle: 'dark' | 'light' | 'accent';
  productCardStyle: 'compact' | 'standard' | 'dense';
}

export interface LayoutSettingsRecord {
  customer: {
    productGridDensity: 'compact' | 'comfortable' | 'dense';
    cardStyle: 'compact-modern' | 'classic' | 'minimal';
    headerDensity: 'compact' | 'normal';
    categoryLayout: 'horizontal-rail' | 'grid' | 'carousel';
    sectionSpacing: 'compact' | 'normal';
    showHeroBanner: boolean;
    showDealsSection: boolean;
    showTrendingSection: boolean;
    showBestsellerSection: boolean;
    showNewArrivalsSection: boolean;
    showOffersSection: boolean;
    showFlashSaleSection: boolean;
  };
  admin: {
    sidebarCollapsed: boolean;
    tableDensity: 'compact' | 'normal' | 'relaxed';
    dashboardCards: '4-col' | '3-col' | '2-col';
    layoutMode: 'default' | 'dense';
  };
}

export interface CouponRecord {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderValue: number;
  maxDiscount?: number;
  startDate: string;
  expiryDate: string;
  usageLimit?: number;
  usageCount: number;
  perCustomerLimit: number;
  firstOrderOnly: boolean;
  isActive: boolean;
  applicableCategories?: string[];
  applicableProducts?: string[];
  createdAt: string;
}

export interface FlashSaleItemRecord {
  productId: string;
  flashPrice: number;
  flashStock: number;
  soldCount: number;
}

export interface FlashSaleRecord {
  id: string;
  title: string;
  subtitle?: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  discountPercentage: number;
  products: FlashSaleItemRecord[];
  bannerImage?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface ReviewRecord {
  id: string;
  productId: string;
  productName?: string;
  customerId?: string;
  customerName: string;
  rating: number;
  comment: string;
  images?: string[];
  verifiedPurchase: boolean;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface ReturnRequestRecord {
  id: string;
  orderId: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  items: { productId: string; name: string; quantity: number; price: number }[];
  reason: string;
  description?: string;
  status: 'requested' | 'approved' | 'pickup_scheduled' | 'returned' | 'completed' | 'rejected';
  createdAt: string;
  updatedAt: string;
  adminNotes?: string;
  evidenceUrl?: string;
}

export interface RefundRecord {
  id: string;
  returnId?: string;
  orderId: string;
  customerId: string;
  customerName?: string;
  amount: number;
  method: 'original_payment' | 'wallet' | 'manual';
  status: 'requested' | 'approved' | 'processing' | 'completed' | 'rejected' | 'failed';
  failureReason?: string;
  transactionRef?: string;
  notes?: string;
  createdAt: string;
  processedAt?: string;
}

export interface DeliveryApiSettingsRecord {
  provider: 'delhivery' | 'shiprocket' | 'bluedart' | 'xpressbees' | 'custom';
  apiKeyEncrypted?: string;
  apiSecretEncrypted?: string;
  liveMode: boolean;
  webhookUrl?: string;
  autoGenerateWaybill: boolean;
  status: 'NOT CONFIGURED' | 'CONNECTED' | 'ERROR';
}

export interface WhatsAppApiSettingsRecord {
  provider: 'wati' | 'interakt' | 'aisensy' | 'meta_cloud' | 'custom';
  apiKeyEncrypted?: string;
  phoneNumberId?: string;
  enabledTemplates: Record<string, boolean>;
  status: 'NOT CONFIGURED' | 'CONNECTED' | 'ERROR';
  lastTestedAt?: string;
}

export interface EmailSettingsRecord {
  provider: 'resend' | 'smtp' | 'sendgrid';
  apiKey?: string;
  fromEmail: string;
  enabledEvents: {
    welcome: boolean;
    orderConfirmation: boolean;
    shippingUpdate: boolean;
    delivery: boolean;
    cancellation: boolean;
    returnUpdate: boolean;
    refundUpdate: boolean;
    passwordReset: boolean;
  };
  status: 'NOT CONFIGURED' | 'CONNECTED' | 'ERROR';
}

export interface LoyaltyTransactionRecord {
  id: string;
  customerId: string;
  customerName?: string;
  points: number;
  type: 'earned' | 'redeemed' | 'adjusted' | 'expired';
  description: string;
  orderId?: string;
  createdAt: string;
}

export interface WalletTransactionRecord {
  id: string;
  customerId: string;
  customerName?: string;
  amount: number;
  type: 'credit' | 'debit';
  description: string;
  referenceId?: string;
  createdAt: string;
}

export interface PromotionalOfferRecord {
  id: string;
  title: string;
  description: string;
  code?: string;
  bannerImage?: string;
  categoryId?: string;
  minAmount?: number;
  discountText: string;
  badge?: string;
  validTill: string;
  isActive: boolean;
  createdAt: string;
}

export interface VendorRecord {
  id: string;
  storeName: string;
  ownerName: string;
  email: string;
  phone: string;
  commissionRate: number;
  status: 'active' | 'pending' | 'suspended';
  logoUrl?: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  pan?: string;
  gstin?: string;
  rating: number;
  createdAt: string;
  updatedAt?: string;
}

export interface PwaSettingsRecord {
  appName: string;
  appShortName: string;
  appIconUrl: string;
  appDescription: string;
  installButtonText: string;
  installBannerText: string;
  bannerEnabled: boolean;
  themeColor: string;
  backgroundColor: string;
  apkDownloadUrl?: string;
  showApkDownload?: boolean;
  apkButtonText?: string;
  pwaInstallEnabled?: boolean;
  playStoreEnabled?: boolean;
  playStoreUrl?: string;
}

export interface PaymentSettingsRecord {
  mode: 'test' | 'live';
  keyId: string;
  keySecretEncrypted: string;
  webhookSecretEncrypted: string;
  isActive?: boolean;
  updatedAt: string;
  updatedBy?: string;
}

export interface PaymentAuditLogRecord {
  id: string;
  adminEmail: string;
  action: string;
  mode: 'test' | 'live';
  success: boolean;
  timestamp: string;
}

export interface CustomerMessageRecord {
  id: string;
  customerId: string;
  customerEmail?: string;
  customerMobile?: string;
  senderType: 'admin' | 'customer';
  senderName: string;
  subject: string;
  message: string;
  messageType: 'offer' | 'order_update' | 'recommendation' | 'support';
  isRead: boolean;
  createdAt: string;
}

export interface NotificationRecord {
  id: string;
  title: string;
  body: string;
  targetAudience: 'all' | 'segment' | 'selected' | 'individual';
  targetCustomerId?: string;
  category: 'special_offer' | 'order_update' | 'new_product' | 'restock' | 'promo';
  status: 'sent' | 'queued' | 'not_configured';
  createdAt: string;
  sentBy?: string;
}

