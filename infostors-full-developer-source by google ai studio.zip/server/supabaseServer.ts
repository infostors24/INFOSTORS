import dotenv from 'dotenv';
dotenv.config();
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || '';
const key = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

export const isSupabaseServerConfigured = Boolean(
  url &&
  key &&
  url.startsWith('https://') &&
  !url.includes('YOUR_PROJECT') &&
  !key.includes('YOUR_SERVER_ONLY')
);

export const supabaseServer: SupabaseClient | null = isSupabaseServerConfigured
  ? createClient(url, key, {
      auth: { autoRefreshToken: false, persistSession: false },
      db: { schema: 'public' },
    })
  : null;

