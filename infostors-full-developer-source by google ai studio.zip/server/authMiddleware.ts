import dotenv from 'dotenv';
dotenv.config();
import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { findCustomerById, getActiveAdminEmails, findAdminByEmail } from './db';
import { CustomerRecord } from './types';

export const JWT_SECRET = process.env.JWT_SECRET || 'infostors-default-jwt-secret-token-key-2026';

export async function getAuthorizedAdminEmails(): Promise<string[]> {
  const envEmails = (process.env.ADMIN_EMAILS || '').split(',').map(e=>e.trim().toLowerCase()).filter(Boolean);
  const dbEmails = await getActiveAdminEmails();
  return Array.from(new Set([...envEmails, ...dbEmails]));
}
export interface CustomerAuthRequest extends Request { customer?: CustomerRecord; }
export interface AdminAuthRequest extends Request { adminEmail?: string; admin?: {email:string;role:string;name?:string}; }
export function generateCustomerToken(customerId:string){return jwt.sign({customerId,type:'customer'},JWT_SECRET,{expiresIn:'7d'});}
export function generateAdminToken(email:string){return jwt.sign({email:email.toLowerCase(),type:'admin'},JWT_SECRET,{expiresIn:'30d'});}
export async function requireCustomerAuth(req:CustomerAuthRequest,res:Response,next:NextFunction){const h=req.headers.authorization;if(!h?.startsWith('Bearer ')){res.status(401).json({error:'Unauthorized'});return;}try{const d=jwt.verify(h.slice(7),JWT_SECRET) as any;if(d.type!=='customer'||!d.customerId)throw new Error('invalid');const c=await findCustomerById(d.customerId);if(!c)throw new Error('missing');req.customer=c;next();}catch{res.status(401).json({error:'Unauthorized: Token expired or invalid'});}}
export async function requireAdminAuth(req:AdminAuthRequest,res:Response,next:NextFunction){const h=req.headers.authorization;if(!h?.startsWith('Bearer ')){res.status(401).json({success:false,error:'Admin authentication token required'});return;}try{const d=jwt.verify(h.slice(7),JWT_SECRET) as any;if(d.type!=='admin'||!d.email)throw new Error('invalid');const admin=await findAdminByEmail(d.email);if(!admin||admin.status!=='active'){res.status(403).json({success:false,error:'Access denied'});return;}req.adminEmail=admin.email.toLowerCase();req.admin={email:admin.email.toLowerCase(),role:admin.role,name:admin.fullName};next();}catch{res.status(401).json({success:false,error:'Unauthorized: Admin session expired or invalid'});}}
export async function optionalCustomerAuth(req:CustomerAuthRequest,_res:Response,next:NextFunction){const h=req.headers.authorization;if(h?.startsWith('Bearer ')){try{const d=jwt.verify(h.slice(7),JWT_SECRET) as any;if(d.type==='customer'&&d.customerId){const c=await findCustomerById(d.customerId);if(c)req.customer=c;}}catch{}}next();}
