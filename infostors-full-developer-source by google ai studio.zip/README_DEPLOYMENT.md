# INFOSTORS — Full Developer Source

This is the complete editable source package. Customer + Admin + Node/Express server + Supabase migrations are included.

## Run
npm install --legacy-peer-deps
npm run lint
npm run build
npm start

## One host / two host modes
Set `VITE_APP_MODE=customer` for customer-only UI, `VITE_APP_MODE=admin` for admin-only UI, or leave unset for customer public routes + `/admin/*`.

## Important
Do not commit real production secrets. Use environment variables. Supabase service-role credentials are server-only.
