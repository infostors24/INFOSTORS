# INFOSTORS — SUPABASE CONNECTION CONFIGURATION MASTER GUIDE

**Target Supabase Project ID:** `oewerfftzqklptdsdfrm`  
**Target Project URL:** `https://oewerfftzqklptdsdfrm.supabase.co`  
**REST API Base:** `https://oewerfftzqklptdsdfrm.supabase.co/rest/v1/`  
**Standard:** Central Database Source of Truth (Zero External Spreadsheets)  

---

## 1. SHARED ARCHITECTURAL TOPOLOGY

Both the **Admin Panel** and the **Customer Storefront** connect to the **SAME** Supabase backend instance:

```
                     ┌─────────────────────────────────────────┐
                     │          REAL SUPABASE BACKEND          │
                     │       Project: oewerfftzqklptdsdfrm     │
                     │  URL: https://oewerfftzqklptdsdfrm...   │
                     │                                         │
                     │   PostgreSQL 15+ Database + Auth + RLS  │
                     │       Supabase Storage (4 Buckets)      │
                     └────────────────────┬────────────────────┘
                                          │
                     ┌────────────────────┴────────────────────┐
                     │                                         │
                     ▼                                         ▼
      ┌─────────────────────────────┐           ┌─────────────────────────────┐
      │         ADMIN PANEL         │           │     CUSTOMER STOREFRONT     │
      │   (Management Operations)   │           │     (Shopping & Orders)     │
      │                             │           │                             │
      │  VITE_SUPABASE_URL          │           │  VITE_SUPABASE_URL          │
      │  VITE_SUPABASE_ANON_KEY     │           │  VITE_SUPABASE_ANON_KEY     │
      │  Role: Authenticated Admin  │           │  Role: Public / Customer    │
      └─────────────────────────────┘           └─────────────────────────────┘
```

---

## 2. CLIENT-SIDE ENVIRONMENT CONFIGURATION (`.env`)

In your local `.env` file (or your hosting provider's build environment settings, e.g. Netlify, Vercel, Cloudflare):

```env
# =============================================================================
# INFOSTORS PUBLIC / CLIENT-SAFE CONFIGURATION
# =============================================================================
VITE_SUPABASE_URL=https://oewerfftzqklptdsdfrm.supabase.co
VITE_SUPABASE_ANON_KEY=<PASTE_YOUR_ACTUAL_ANON_PUBLISHABLE_KEY_HERE>

# =============================================================================
# SERVER-SIDE ONLY CONFIGURATION (NEVER EXPOSE TO BROWSER / CLIENT BUNDLES)
# =============================================================================
PORT=3000
NODE_ENV=production
JWT_SECRET=your-secure-random-jwt-secret-min-32-chars
ENCRYPTION_KEY=your-aes256-master-encryption-key-32-chars

# Supabase Service Role Key (BYPASSES RLS — SERVER-SIDE BATCH / CRON / SEED ONLY)
SUPABASE_SERVICE_ROLE_KEY=
```

### Security Rules:
1. `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` are safe for browser execution because database access is governed by **Row Level Security (RLS)**.
2. `SUPABASE_SERVICE_ROLE_KEY` bypasses all RLS policies. It **MUST NEVER** be placed into any frontend code or prefixed with `VITE_`.

---

## 3. CODE IMPLEMENTATION REFERENCES

### A. Supabase Client Wrapper (`src/shared/services/supabaseClient.ts`)
```typescript
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Database } from '../types/database.types';

export function getSupabaseConfig() {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

  const isReady = Boolean(
    supabaseUrl &&
    supabaseAnonKey &&
    supabaseUrl.startsWith('https://') &&
    supabaseUrl.includes('supabase.co')
  );

  return { supabaseUrl, supabaseAnonKey, isReady };
}

const config = getSupabaseConfig();

export const supabase: SupabaseClient<Database> | null = config.isReady
  ? createClient<Database>(config.supabaseUrl, config.supabaseAnonKey)
  : null;

export const isSupabaseConfigured = (): boolean => getSupabaseConfig().isReady;
```

### B. Provider-Independent Repository Layer (`src/shared/services/supabaseAdapter.ts`)
Components never interact with database drivers directly; they call repository interfaces (`IProductRepository`, `IOrderRepository`, `ICategoryRepository`):
- `SupabaseProductRepository`: Fetches and queries `public.products`.
- `SupabaseCategoryRepository`: Fetches and manages `public.categories`.
- `SupabaseOrderRepository`: Handles order creation, status progression, and dispatch waybills.

---

## 4. ADMIN & CUSTOMER SHARED WORKFLOW MATRIX

| Event / Action | Origin | Supabase Flow | Destination |
|---|---|---|---|
| **Catalog Price / Stock Edit** | Admin Panel | `UPDATE public.products` | Customer storefront reflects live price & availability instantly |
| **New Customer Order** | Customer Site | `INSERT public.orders` + `order_items` | Admin dashboard receives order with monotonic ID (`INF-YYYYMMDD-XXXX`) |
| **Inventory Decrement** | Automatic Trigger | `trigger_deduct_inventory_order_item` | Decrements `products.stock` and appends to `public.inventory_logs` |
| **Parcel Dispatch & AWB** | Admin Panel | `UPDATE orders SET package_status = 'dispatched'` | Customer views live tracking number and status on `/order-tracking` |
| **Customer Auth Signup** | Customer Site | `supabase.auth.signUp()` | Creates `auth.users` row; triggers profile creation in `public.customers` |
| **Store Settings Change** | Admin Panel | `UPDATE public.store_settings` | Customer sees updated delivery fee thresholds and announcement marquee |
| **Direct VIP Message** | Admin Panel | `INSERT public.customer_messages` | Customer sees isolated notification in their private account feed |
