-- ============================================================================
-- INFOSTORS FINAL SUPABASE MASTER BUILD — MIGRATION 07: TRIGGERS
-- Target Project ID: oewerfftzqklptdsdfrm
-- Safety: Non-destructive, idempotent
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. UPDATED_AT TRIGGERS
-- ----------------------------------------------------------------------------

DROP TRIGGER IF EXISTS trigger_set_updated_at_products ON public.products;
CREATE TRIGGER trigger_set_updated_at_products
    BEFORE UPDATE ON public.products
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_categories ON public.categories;
CREATE TRIGGER trigger_set_updated_at_categories
    BEFORE UPDATE ON public.categories
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_customers ON public.customers;
CREATE TRIGGER trigger_set_updated_at_customers
    BEFORE UPDATE ON public.customers
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_customer_addresses ON public.customer_addresses;
CREATE TRIGGER trigger_set_updated_at_customer_addresses
    BEFORE UPDATE ON public.customer_addresses
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_orders ON public.orders;
CREATE TRIGGER trigger_set_updated_at_orders
    BEFORE UPDATE ON public.orders
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_admin_users ON public.admin_users;
CREATE TRIGGER trigger_set_updated_at_admin_users
    BEFORE UPDATE ON public.admin_users
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trigger_set_updated_at_store_settings ON public.store_settings;
CREATE TRIGGER trigger_set_updated_at_store_settings
    BEFORE UPDATE ON public.store_settings
    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ----------------------------------------------------------------------------
-- 2. ORDER STATUS HISTORY TRIGGER
-- ----------------------------------------------------------------------------

DROP TRIGGER IF EXISTS trigger_record_order_status_change ON public.orders;
CREATE TRIGGER trigger_record_order_status_change
    AFTER UPDATE ON public.orders
    FOR EACH ROW EXECUTE FUNCTION public.record_order_status_change();

-- ----------------------------------------------------------------------------
-- 3. INVENTORY ATOMIC DEDUCTION TRIGGER
-- ----------------------------------------------------------------------------

DROP TRIGGER IF EXISTS trigger_deduct_inventory_order_item ON public.order_items;
CREATE TRIGGER trigger_deduct_inventory_order_item
    AFTER INSERT ON public.order_items
    FOR EACH ROW EXECUTE FUNCTION public.deduct_inventory_for_order_item();
