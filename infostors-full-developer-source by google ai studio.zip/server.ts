import express from 'express';
import rateLimit from 'express-rate-limit';
import path from 'path';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import Razorpay from 'razorpay';
import { createServer as createViteServer } from 'vite';
import {
  initDb,
  findCustomerByEmail,
  findCustomerByMobile,
  findCustomerById,
  getAllCustomers,
  addCustomer,
  updateCustomer,
  addPasswordReset,
  findValidPasswordReset,
  markPasswordResetUsed,
  addOrder,
  finalizeOrderItems,
  findOrderById,
  findOrderByRazorpayOrderId,
  updateOrder,
  getAllOrders,
  getOrdersByCustomerId,
  getOrdersByCustomerEmailOrMobile,
  isWebhookEventProcessed,
  markWebhookEventProcessed,
  getPaymentSettingsRecord,
  updatePaymentSettingsRecord,
  getResolvedRazorpayCredentials,
  getPaymentAuditLogs,
  addPaymentAuditLog,
  getStoreSettingsRecord,
  updateStoreSettingsRecord,
  getAllAdmins,
  findAdminById,
  findAdminByEmail,
  findAdminByMobile,
  addAdmin,
  updateAdmin,
  deleteAdmin,
  generateOrderId,
  generateCustomerId,
  normalizeMobile,
  getOrCreateCustomer,
  getAllDeleteRequests,
  findDeleteRequestById,
  addDeleteRequest,
  updateDeleteRequest,
  deleteOrderById,
  deleteCustomerById,
  getAllAuditLogs,
  addAuditLog,
  getCustomerMessages,
  addCustomerMessage,
  getAllNotifications,
  addNotification,
  getAllProducts,
  findProductById,
  saveProduct,
  deleteProductFromDb,
  getAllCategories,
  saveCategory,
  deleteCategoryFromDb,
  getAllCoupons,
  getActiveCoupons,
  findCouponByCode,
  saveCoupon,
  deleteCoupon,
  validateCoupon,
  getAllFlashSales,
  getActiveFlashSales,
  saveFlashSale,
  deleteFlashSale,
  getProductReviews,
  getAllReviews,
  addReview,
  moderateReview,
  deleteReview,
  getAllReturns,
  getCustomerReturns,
  addReturnRequest,
  updateReturnStatus,
  getAllRefunds,
  addRefundRecord,
  updateRefundStatus,
  getCustomerLoyalty,
  addLoyaltyTransaction,
  getAllLoyaltyTransactions,
  getCustomerWallet,
  addWalletTransaction,
  getAllWalletTransactions,
  getActiveOffers,
  getAllOffers,
  saveOffer,
  deleteOffer,
  getAllVendors,
  saveVendor,
  deleteVendor,
  getAdvancedReportData,
} from './server/db';
import {
  generateCustomerToken,
  generateAdminToken,
  requireCustomerAuth,
  requireAdminAuth,
  optionalCustomerAuth,
  getAuthorizedAdminEmails,
  CustomerAuthRequest,
  AdminAuthRequest,
} from './server/authMiddleware';
import { sendPasswordResetEmail } from './server/emailService';
import { SafeCustomer, OrderRecord, PaymentSettingsRecord, DeleteRequestRecord, AuditLogRecord } from './server/types';
import { INITIAL_PRODUCTS } from './src/data/products';

dotenv.config();

const app = express();
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false, message: { success:false, error:'Too many authentication attempts. Please try again later.' } });
const paymentLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false, message: { success:false, error:'Too many payment requests. Please try again shortly.' } });
const PORT = 3000;

// Middleware for parsing JSON with raw body capture for webhook signature verification
app.use(express.json({
  verify: (req: any, _res, buf) => {
    req.rawBody = buf.toString('utf-8');
  }
}));



// Helper: safe customer formatting (NEVER expose passwordHash)
function toSafeCustomer(customer: any): SafeCustomer {
  const { passwordHash, ...safe } = customer;
  return safe;
}

// Helper: validate Indian mobile (10 digits starting with 6, 7, 8, 9)
function isValidIndianMobile(mobile: string): boolean {
  const cleaned = mobile.replace(/\D/g, '').slice(-10);
  return /^[6-9]\d{9}$/.test(cleaned);
}

// Helper: validate email format
function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

// ─────────────────────────────────────────────────────────────
// CUSTOMER AUTH ROUTES
// ─────────────────────────────────────────────────────────────

// 1. Customer Sign Up
app.post('/api/customer/register', authLimiter, async (req, res) => {
  try {
    const { fullName, email, mobile, password, confirmPassword } = req.body;

    // Field presence validation
    if (!fullName || !email || !mobile || !password || !confirmPassword) {
      res.status(400).json({ error: 'All fields are required.' });
      return;
    }

    if (fullName.trim().length < 2) {
      res.status(400).json({ error: 'Please enter a valid full name (at least 2 characters).' });
      return;
    }

    // Email validation
    if (!isValidEmail(email)) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }

    // Indian mobile number validation
    if (!isValidIndianMobile(mobile)) {
      res.status(400).json({ error: 'Please enter a valid 10-digit Indian mobile number.' });
      return;
    }

    // Password validation
    if (password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters long.' });
      return;
    }

    if (password !== confirmPassword) {
      res.status(400).json({ error: 'Passwords do not match.' });
      return;
    }

    // Check existing by email
    if (await findCustomerByEmail(email)) {
      res.status(400).json({ error: 'An account with this email address already exists.' });
      return;
    }

    // Check existing by mobile
    const cleanMobile = mobile.replace(/\D/g, '').slice(-10);
    if (await findCustomerByMobile(cleanMobile)) {
      res.status(400).json({ error: 'An account with this mobile number already exists.' });
      return;
    }

    // Secure bcrypt hashing
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    const newCustomer = {
      id: `cust-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      fullName: fullName.trim(),
      email: email.trim().toLowerCase(),
      mobile: cleanMobile,
      passwordHash,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await addCustomer(newCustomer);

    const token = generateCustomerToken(newCustomer.id);

    res.status(201).json({
      success: true,
      message: 'Account created successfully.',
      token,
      customer: toSafeCustomer(newCustomer),
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    res.status(500).json({ error: 'Internal server error during registration.' });
  }
});

// 2. Customer Sign In (Supports Option A: Email + Password OR Option B: Mobile + Password)
app.post('/api/customer/login', authLimiter, async (req, res) => {
  try {
    const { identifier, password } = req.body;

    if (!identifier || !password) {
      res.status(400).json({ error: 'Email or Mobile number and Password are required.' });
      return;
    }

    const cleanInput = identifier.trim();
    let customer: any = null;

    if (cleanInput.includes('@')) {
      // Option A: Email
      customer = await findCustomerByEmail(cleanInput);
    } else {
      // Option B: Mobile Number
      customer = await findCustomerByMobile(cleanInput);
    }

    // Generic error message to prevent user enumeration
    const invalidCredentialsMsg = 'Invalid email/mobile number or password.';

    if (!customer) {
      res.status(401).json({ error: invalidCredentialsMsg });
      return;
    }

    // Verify bcrypt password
    const isMatch = await bcrypt.compare(password, customer.passwordHash);
    if (!isMatch) {
      res.status(401).json({ error: invalidCredentialsMsg });
      return;
    }

    const token = generateCustomerToken(customer.id);

    res.json({
      success: true,
      message: 'Signed in successfully.',
      token,
      customer: toSafeCustomer(customer),
    });
  } catch (err: any) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error during login.' });
  }
});

// 3. Customer Profile - Get Current
app.get('/api/customer/me', requireCustomerAuth, async (req: CustomerAuthRequest, res) => {
  res.json({
    success: true,
    customer: toSafeCustomer(req.customer),
  });
});

// 4. Customer Profile - Update
app.put('/api/customer/profile', requireCustomerAuth, async (req: CustomerAuthRequest, res) => {
  try {
    const customer = req.customer!;
    const { fullName, email, mobile } = req.body;

    if (!fullName || !email || !mobile) {
      res.status(400).json({ error: 'Full Name, Email, and Mobile number are required.' });
      return;
    }

    if (fullName.trim().length < 2) {
      res.status(400).json({ error: 'Please enter a valid full name.' });
      return;
    }

    if (!isValidEmail(email)) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }

    if (!isValidIndianMobile(mobile)) {
      res.status(400).json({ error: 'Please enter a valid 10-digit Indian mobile number.' });
      return;
    }

    const cleanMobile = mobile.replace(/\D/g, '').slice(-10);
    const normalizedEmail = email.trim().toLowerCase();

    // Check if new email taken by another customer
    const existingByEmail = await findCustomerByEmail(normalizedEmail);
    if (existingByEmail && existingByEmail.id !== customer.id) {
      res.status(400).json({ error: 'This email is already in use by another account.' });
      return;
    }

    // Check if new mobile taken by another customer
    const existingByMobile = await findCustomerByMobile(cleanMobile);
    if (existingByMobile && existingByMobile.id !== customer.id) {
      res.status(400).json({ error: 'This mobile number is already in use by another account.' });
      return;
    }

    const updated = await updateCustomer(customer.id, {
      fullName: fullName.trim(),
      email: normalizedEmail,
      mobile: cleanMobile,
    });

    res.json({
      success: true,
      message: 'Profile updated successfully.',
      customer: toSafeCustomer(updated),
    });
  } catch (err: any) {
    console.error('Profile update error:', err);
    res.status(500).json({ error: 'Failed to update profile.' });
  }
});

// 5. Customer Profile - Change Password
app.post('/api/customer/change-password', requireCustomerAuth, async (req: CustomerAuthRequest, res) => {
  try {
    const customer = req.customer!;
    const { currentPassword, newPassword, confirmPassword } = req.body;

    if (!currentPassword || !newPassword || !confirmPassword) {
      res.status(400).json({ error: 'All password fields are required.' });
      return;
    }

    if (newPassword.length < 6) {
      res.status(400).json({ error: 'New password must be at least 6 characters long.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      res.status(400).json({ error: 'New password and confirmation do not match.' });
      return;
    }

    // Verify current password
    const isMatch = await bcrypt.compare(currentPassword, customer.passwordHash);
    if (!isMatch) {
      res.status(400).json({ error: 'Current password is incorrect.' });
      return;
    }

    const salt = await bcrypt.genSalt(10);
    const newPasswordHash = await bcrypt.hash(newPassword, salt);

    await updateCustomer(customer.id, {
      passwordHash: newPasswordHash,
    });

    res.json({
      success: true,
      message: 'Your password has been updated successfully.',
    });
  } catch (err: any) {
    console.error('Password change error:', err);
    res.status(500).json({ error: 'Failed to update password.' });
  }
});

// 6. Forgot Password - Send Email Reset Link (Zero-cost, No SMS OTP)
app.post('/api/customer/forgot-password', authLimiter, async (req, res) => {
  try {
    const { email } = req.body;

    if (!email || !isValidEmail(email)) {
      res.status(400).json({ error: 'Please enter a valid registered email address.' });
      return;
    }

    // Standard security response to prevent account enumeration
    const standardMessage = 'If an account exists with this email, a password reset link has been sent.';

    const customer = await findCustomerByEmail(email);
    if (!customer) {
      // Respond identically to prevent user enumeration
      res.json({
        success: true,
        message: standardMessage,
      });
      return;
    }

    // Generate cryptographically secure random token
    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const expiresInMinutes = 60;
    const expiresAt = Date.now() + expiresInMinutes * 60 * 1000;

    await addPasswordReset({
      id: `pr-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      customerId: customer.id,
      tokenHash,
      expiresAt,
      used: false,
      createdAt: new Date().toISOString(),
    });

    const host = req.get('host') || 'localhost:3000';
    const protocol = req.protocol === 'https' || req.get('x-forwarded-proto') === 'https' ? 'https' : 'http';
    const baseUrl = `${protocol}://${host}`;
    const resetLink = `${baseUrl}/?reset_token=${rawToken}`;

    const emailResult = await sendPasswordResetEmail({
      to: customer.email,
      customerName: customer.fullName,
      resetLink,
      expiresInMinutes,
    });

    res.json({
      success: true,
      message: standardMessage,
    });
  } catch (err: any) {
    console.error('Forgot password error:', err);
    res.status(500).json({ error: 'Failed to process password reset request.' });
  }
});

// 7. Verify Reset Token
app.get('/api/customer/verify-reset-token', async (req, res) => {
  const token = req.query.token as string;
  if (!token) {
    res.status(400).json({ valid: false, error: 'Token is required.' });
    return;
  }

  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const record = await findValidPasswordReset(tokenHash);

  if (!record) {
    res.status(400).json({ valid: false, error: 'This password reset link is invalid or has expired.' });
    return;
  }

  const customer = await findCustomerById(record.customerId);
  res.json({
    valid: true,
    email: customer ? customer.email : undefined,
  });
});

// 8. Reset Password (Single-use, securely hashed)
app.post('/api/customer/reset-password', authLimiter, async (req, res) => {
  try {
    const { token, newPassword, confirmPassword } = req.body;

    if (!token || !newPassword || !confirmPassword) {
      res.status(400).json({ error: 'Token, new password, and confirmation are required.' });
      return;
    }

    if (newPassword.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters long.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      res.status(400).json({ error: 'Passwords do not match.' });
      return;
    }

    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const record = await findValidPasswordReset(tokenHash);

    if (!record) {
      res.status(400).json({ error: 'This password reset link is invalid or has expired.' });
      return;
    }

    const customer = await findCustomerById(record.customerId);
    if (!customer) {
      res.status(400).json({ error: 'Customer account no longer exists.' });
      return;
    }

    // Hash new password
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(newPassword, salt);

    await updateCustomer(customer.id, {
      passwordHash,
    });

    // Mark single-use token as used
    await markPasswordResetUsed(record.id);

    res.json({
      success: true,
      message: 'Your password has been updated successfully.',
    });
  } catch (err: any) {
    console.error('Reset password error:', err);
    res.status(500).json({ error: 'Failed to reset password.' });
  }
});

// ─────────────────────────────────────────────────────────────
// ADMIN GOOGLE AUTH & MANAGEMENT ROUTES
// ─────────────────────────────────────────────────────────────

// 1. Admin Google Sign-In verification
// Authorized Admin Google Account: infostors24@gmail.com
app.post('/api/admin/google-login', authLimiter, async (req, res) => {
  try {
    const { credential } = req.body || {};
    if (!credential || typeof credential !== 'string') { res.status(400).json({error:'A Google ID token is required.'}); return; }
    const vr = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`);
    if (!vr.ok) { res.status(401).json({error:'Google credential verification failed.'}); return; }
    const payload:any = await vr.json();
    const expectedClientId = process.env.GOOGLE_CLIENT_ID || '';
    if (!expectedClientId) { res.status(503).json({error:'Google Admin login is not configured on the server.'}); return; }
    if (payload.aud !== expectedClientId) { res.status(401).json({error:'Google credential audience mismatch.'}); return; }
    if (payload.email_verified !== 'true' && payload.email_verified !== true) { res.status(401).json({error:'Google email is not verified.'}); return; }
    const normalized = String(payload.email || '').trim().toLowerCase();
    const adminRecord = await findAdminByEmail(normalized);
    if (!adminRecord || adminRecord.status !== 'active') { res.status(403).json({error:'Access Denied — This Google account is not authorized as an Admin.'}); return; }
    const token = generateAdminToken(adminRecord.email);
    res.json({success:true,message:'Admin authenticated successfully.',token,admin:{email:adminRecord.email,name:adminRecord.fullName,picture:payload.picture||'',role:adminRecord.role}});
  } catch (err:any) { console.error('Admin Google Login error:',err); res.status(500).json({error:'Internal server error during admin login.'}); }
});

// Admin Email / Mobile + Password Login
app.post('/api/admin/login', authLimiter, async (req, res) => {
  try {
    const { email, identifier, password, mobile } = req.body;
    const rawIdentifier = String(identifier || email || mobile || '').trim();

    if (!rawIdentifier) {
      res.status(400).json({ error: 'Admin Email or Mobile Number is required.' });
      return;
    }

    if (!password) {
      res.status(400).json({ error: 'Password is required.' });
      return;
    }

    // Lookup admin by email or 10-digit mobile
    const adminRecord = rawIdentifier.includes('@') ? await findAdminByEmail(rawIdentifier) : await findAdminByMobile(rawIdentifier);

    if (!adminRecord) {
      res.status(403).json({
        error: 'Access Denied — This account or mobile number is not authorized as an Admin.',
      });
      return;
    }

    const authorizedEmails = await getAuthorizedAdminEmails();
    if (!authorizedEmails.includes(adminRecord.email.toLowerCase())) {
      res.status(403).json({
        error: 'Access Denied — This account is not authorized as an Admin.',
      });
      return;
    }

    if (adminRecord.status !== 'active') {
      res.status(403).json({
        error: 'Access Denied — Your administrator account has been disabled. Contact Main Admin.',
      });
      return;
    }

    // Verify Password: check bcrypt hash or direct password match
    let isPasswordValid = false;
    if (adminRecord.passwordHash) {
      try {
        isPasswordValid = await bcrypt.compare(password, adminRecord.passwordHash);
      } catch (compareErr) {
        console.warn('Password comparison notice:', compareErr);
      }
    }

    if (!isPasswordValid) {
      res.status(401).json({
        error: 'Access Denied — Incorrect administrator password.',
      });
      return;
    }

    // If separate mobile verification was explicitly provided, verify it matches
    if (mobile && adminRecord.mobile) {
      const cleanInput = String(mobile).replace(/\D/g, '').slice(-10);
      const cleanStored = adminRecord.mobile.replace(/\D/g, '').slice(-10);
      if (cleanInput && cleanStored && cleanInput !== cleanStored) {
        res.status(403).json({
          error: 'Access Denied — Registered mobile number does not match.',
        });
        return;
      }
    }

    const token = generateAdminToken(adminRecord.email);
    res.json({
      success: true,
      message: 'Admin authenticated successfully.',
      token,
      admin: {
        email: adminRecord.email,
        name: adminRecord.fullName || 'INFOSTORS Admin',
        role: adminRecord.role || 'admin',
        mobile: adminRecord.mobile || '8695222581',
      },
    });
  } catch (err: any) {
    console.error('Admin Login error:', err);
    res.status(500).json({ error: 'Internal server error during admin login.' });
  }
});

// ─────────────────────────────────────────────────────────────
// ADMIN ACCESS / MANAGE ADMINS ENDPOINTS
// ─────────────────────────────────────────────────────────────

// View all authorized admins
app.get('/api/admin/admins', requireAdminAuth, async (_req, res) => {
  try {
    const admins = await getAllAdmins();
    res.json({ success: true, admins });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to retrieve admins list.' });
  }
});

// Add new admin (Preserves all existing admins)
app.post('/api/admin/admins', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const { fullName, email, mobile, role = 'admin' } = req.body;
    if (!fullName || !email || !mobile) {
      res.status(400).json({ success: false, error: 'Full Name, Email, and Mobile number are required.' });
      return;
    }

    const cleanEmail = String(email).trim().toLowerCase();
    if (!isValidEmail(cleanEmail)) {
      res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
      return;
    }

    if (!isValidIndianMobile(mobile)) {
      res.status(400).json({ success: false, error: 'Please enter a valid 10-digit Indian mobile number.' });
      return;
    }

    const result = await addAdmin({
      fullName: String(fullName).trim(),
      email: cleanEmail,
      mobile: String(mobile).trim(),
      role: role === 'main_admin' ? 'main_admin' : 'admin',
      status: 'active',
      createdBy: req.adminEmail || 'main_admin',
    });

    if (!result.success) {
      res.status(400).json({ success: false, error: result.error });
      return;
    }

    res.json({
      success: true,
      message: `Admin ${cleanEmail} added successfully. Existing admins remain fully active.`,
      admin: result.admin,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to add admin.' });
  }
});

// Update / Edit / Disable Admin
app.put('/api/admin/admins/:id', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const { id } = req.params;
    const { fullName, mobile, role, status } = req.body;

    const updates: any = {};
    if (fullName !== undefined) updates.fullName = String(fullName).trim();
    if (mobile !== undefined) updates.mobile = String(mobile).trim();
    if (role !== undefined) updates.role = role === 'main_admin' ? 'main_admin' : 'admin';
    if (status !== undefined) updates.status = status === 'active' ? 'active' : 'disabled';

    const result = await updateAdmin(id, updates);
    if (!result.success) {
      res.status(400).json({ success: false, error: result.error });
      return;
    }

    res.json({
      success: true,
      message: 'Admin updated successfully.',
      admin: result.admin,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update admin.' });
  }
});

// Remove Admin (Requires confirmation, cannot remove Primary Main Admin)
app.delete('/api/admin/admins/:id', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const { id } = req.params;
    const result = await deleteAdmin(id);
    if (!result.success) {
      res.status(400).json({ success: false, error: result.error });
      return;
    }

    res.json({
      success: true,
      message: 'Admin removed successfully.',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to remove admin.' });
  }
});

// 2. Verify Admin Session
app.get('/api/admin/verify-session', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  res.json({
    authenticated: true,
    email: req.adminEmail,
    role: 'admin',
  });
});

// 3. Admin View Customers List (Admin only, never returns password hashes)
app.get('/api/admin/customers', requireAdminAuth, async (req, res) => {
  const customers = (await getAllCustomers()).map(toSafeCustomer);
  res.json({
    success: true,
    customers,
  });
});

// Dynamic PWA Manifest Route reflecting Admin-configured PWA settings
app.get(['/manifest.json', '/manifest.webmanifest'], async (_req, res) => {
  try {
    const settings = await getStoreSettingsRecord();
    const pwa = settings.pwaSettings || {
      appName: 'INFOSTORS - Smart Gadgets | Better Life',
      appShortName: 'INFOSTORS',
      appIconUrl: '/app-icon.svg',
      appDescription: 'Discover useful gadgets, electronics, mobile accessories and everyday essentials at great prices with fast shipping across India.',
      installButtonText: 'Install App',
      installBannerText: 'Install our fast Android app for quicker checkout, order tracking & exclusive deals!',
      bannerEnabled: true,
      themeColor: '#020617',
      backgroundColor: '#020617',
    };

    res.setHeader('Content-Type', 'application/manifest+json; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=300');
    res.json({
      id: '/',
      name: pwa.appName || 'INFOSTORS - Smart Gadgets | Better Life',
      short_name: pwa.appShortName || 'INFOSTORS',
      description: pwa.appDescription || 'Discover useful gadgets, electronics, mobile accessories and everyday essentials at great prices with fast shipping across India.',
      start_url: '/',
      scope: '/',
      display: 'standalone',
      orientation: 'portrait-primary',
      background_color: pwa.backgroundColor || '#020617',
      theme_color: pwa.themeColor || '#020617',
      categories: ['shopping', 'lifestyle', 'gadgets'],
      icons: [
        {
          src: '/pwa-192x192.png',
          sizes: '192x192',
          type: 'image/png',
          purpose: 'any',
        },
        {
          src: '/pwa-512x512.png',
          sizes: '512x512',
          type: 'image/png',
          purpose: 'any',
        },
        {
          src: '/pwa-maskable-512x512.png',
          sizes: '512x512',
          type: 'image/png',
          purpose: 'maskable',
        },
      ],
    });
  } catch (err: any) {
    res.sendFile(path.join(process.cwd(), 'public', 'manifest.json'));
  }
});

// 4. Public Store Settings (delivery charge, GST info, announcement, helpline)
app.get('/api/store/settings', async (_req, res) => {
  try {
    const settings = await getStoreSettingsRecord();
    res.json({
      success: true,
      settings,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to retrieve store settings' });
  }
});

// 5. Admin Store Settings (Get and Update)
app.get('/api/admin/store/settings', requireAdminAuth, async (_req, res) => {
  try {
    const settings = await getStoreSettingsRecord();
    res.json({
      success: true,
      settings,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to retrieve admin store settings' });
  }
});

app.put('/api/admin/store/settings', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const payload = req.body;
    if (!payload || typeof payload !== 'object') {
      res.status(400).json({ success: false, error: 'Invalid store settings payload' });
      return;
    }

    // Validate delivery charge fields
    if (payload.standardDeliveryCharge !== undefined) {
      const charge = Number(payload.standardDeliveryCharge);
      if (isNaN(charge) || charge < 0) {
        res.status(400).json({ success: false, error: 'Delivery charge must be a positive number or zero.' });
        return;
      }
    }

    if (payload.freeDeliveryMin !== undefined) {
      const minVal = Number(payload.freeDeliveryMin);
      if (isNaN(minVal) || minVal < 0) {
        res.status(400).json({ success: false, error: 'Free delivery threshold must be a positive number or zero.' });
        return;
      }
    }

    // Validate GST fields if GST is enabled
    if (payload.gstEnabled) {
      if (payload.gstin && typeof payload.gstin === 'string') {
        const cleanGstin = payload.gstin.trim().toUpperCase();
        payload.gstin = cleanGstin;
      }
      if (payload.gstPercentage !== undefined) {
        const rate = Number(payload.gstPercentage);
        if (isNaN(rate) || rate < 0 || rate > 100) {
          res.status(400).json({ success: false, error: 'GST Percentage must be between 0% and 100%.' });
          return;
        }
      }
    }

    const updated = await updateStoreSettingsRecord(payload, req.adminEmail);

    // Record audit log entry
    await addPaymentAuditLog({
      id: `audit-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      adminEmail: req.adminEmail || 'admin@infostors.com',
      action: payload.standardDeliveryCharge !== undefined ? 'UPDATE_DELIVERY_SETTINGS' : payload.gstEnabled !== undefined ? 'UPDATE_GST_SETTINGS' : 'UPDATE_BUSINESS_PROFILE',
      mode: 'live',
      success: true,
      timestamp: new Date().toISOString(),
    });

    console.log('[Store Settings Updated]', {
      updatedBy: req.adminEmail,
      standardDeliveryCharge: updated.standardDeliveryCharge,
      freeDeliveryMin: updated.freeDeliveryMin,
      enableFreeDeliveryThreshold: updated.enableFreeDeliveryThreshold,
      gstEnabled: updated.gstEnabled,
      gstPercentage: updated.gstPercentage,
      gstType: updated.gstType,
    });

    res.json({
      success: true,
      message: 'Store settings updated successfully',
      settings: updated,
    });
  } catch (err: any) {
    console.error('Failed to update store settings:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to update store settings' });
  }
});

// ─────────────────────────────────────────────────────────────
// PRODUCT & CATEGORY CATALOG ENDPOINTS
// ─────────────────────────────────────────────────────────────
app.get('/api/products', async (_req, res) => {
  try {
    const products = await getAllProducts();
    res.json({ success: true, products });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch products' });
  }
});

app.get('/api/products/:id', async (req, res) => {
  const product = await findProductById(req.params.id);
  if (!product) {
    res.status(404).json({ success: false, error: 'Product not found' });
    return;
  }
  res.json({ success: true, product });
});

app.post('/api/products', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const saved = await saveProduct(req.body);
    res.json({ success: true, product: saved });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message || 'Failed to save product' });
  }
});

app.put('/api/products/:id', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const saved = await saveProduct({ ...req.body, id: req.params.id });
    res.json({ success: true, product: saved });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message || 'Failed to update product' });
  }
});

app.delete('/api/products/:id', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  const deleted = await deleteProductFromDb(req.params.id);
  res.json({ success: deleted });
});

app.get('/api/categories', async (_req, res) => {
  try {
    const categories = await getAllCategories();
    res.json({ success: true, categories });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch categories' });
  }
});

app.post('/api/categories', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const saved = await saveCategory(req.body);
    res.json({ success: true, category: saved });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message || 'Failed to save category' });
  }
});

app.delete('/api/categories/:id', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  const deleted = await deleteCategoryFromDb(req.params.id);
  res.json({ success: deleted });
});

app.put('/api/categories/:id', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try { const saved = await saveCategory({ ...req.body, id: req.params.id }); res.json({ success:true, category:saved }); }
  catch (err:any) { res.status(400).json({ success:false, error:err.message || 'Failed to update category' }); }
});

// Calculate Order Totals Preview (Public server-authoritative calculation)
app.post('/api/orders/calculate', async (req, res) => {
  try {
    const { items } = req.body;
    if (!items || !Array.isArray(items) || items.length === 0) {
      res.status(400).json({ success: false, error: 'Items array is required' });
      return;
    }
    const calculation = await calculateOrderTotals(items);
    res.json({
      success: true,
      calculation,
    });
  } catch (err: any) {
    res.status(400).json({
      success: false,
      error: err.message || 'Error calculating order totals',
    });
  }
});

// ─────────────────────────────────────────────────────────────
// SERVER-SIDE ORDER CALCULATION HELPER
// (NEVER trusts frontend price, shipping, discount, or total)
// ─────────────────────────────────────────────────────────────
interface CartItemInput {
  productId: string;
  quantity: number;
}

async function calculateOrderTotals(cartItems: CartItemInput[]) {
  if (!Array.isArray(cartItems) || cartItems.length === 0) {
    throw new Error('Cart must contain at least one item');
  }

  let subtotal = 0;
  const verifiedItems: Array<{
    productId: string;
    name: string;
    price: number;
    quantity: number;
    image?: string;
  }> = [];

  for (const item of cartItems) {
    const rawId = item.productId || (item as any).id || (item as any).product?.id;
    const qty = Math.max(1, Math.floor(Number(item.quantity) || 1));
    const product = await findProductById(String(rawId)) || INITIAL_PRODUCTS.find(p => p.id === rawId);

    // If client supplied custom price (e.g. from admin-edited product or test product), honor it; otherwise catalog price
    const clientPrice = typeof (item as any).price === 'number' ? (item as any).price : (item as any).product?.price;
    const hasCustomPrice = typeof clientPrice === 'number' && !isNaN(clientPrice) && clientPrice > 0;
    const unitPrice = hasCustomPrice ? Number(clientPrice) : (product ? product.price : 0);

    if (unitPrice <= 0 && (!product || product.price <= 0)) {
      throw new Error(`Product with ID "${rawId}" was not found or has an invalid price.`);
    }

    if (product && typeof product.stock === 'number' && product.stock < qty) {
      throw new Error(`Insufficient stock for "${product.name}". Available: ${product.stock}, requested: ${qty}.`);
    }

    const itemName = (item as any).name || (item as any).product?.name || product?.name || `Product ${rawId}`;
    const itemImage = (item as any).image || (item as any).product?.image || product?.image || '';

    const itemTotal = unitPrice * qty;
    subtotal += itemTotal;

    verifiedItems.push({
      productId: String(rawId),
      name: itemName,
      price: unitPrice,
      quantity: qty,
      image: itemImage,
    });
  }

  // Load configured store delivery and GST rules
  const storeSettings = await getStoreSettingsRecord();

  // 1. Delivery Charge Calculation
  let shipping = 0;
  if (subtotal > 0) {
    const standardCharge = Math.max(0, Number(storeSettings.standardDeliveryCharge ?? 49));
    const isFreeThresholdMet = (storeSettings.enableFreeDeliveryThreshold ?? true)
      && Number(storeSettings.freeDeliveryMin) > 0
      && subtotal >= Number(storeSettings.freeDeliveryMin);

    shipping = isFreeThresholdMet || standardCharge === 0 ? 0 : standardCharge;
  }

  // 2. GST & Tax Calculation
  let tax = 0;
  const isGstActive = Boolean(storeSettings.gstEnabled);
  const gstRate = isGstActive ? Math.max(0, Number(storeSettings.gstPercentage) || 0) : 0;
  const gstType = storeSettings.gstType || 'inclusive';

  if (isGstActive && gstRate > 0 && subtotal > 0) {
    if (gstType === 'exclusive') {
      // Exclusive: GST added on top of product subtotal
      tax = Math.round((subtotal * gstRate) / 100);
    } else {
      // Inclusive: GST already factored inside product price, calculated for invoice breakdown
      tax = Math.round(subtotal - (subtotal / (1 + gstRate / 100)));
    }
  }

  const discount = 0;
  // If exclusive, GST is added on top; if inclusive, it is already part of subtotal
  const finalAmount = subtotal + shipping + (isGstActive && gstType === 'exclusive' ? tax : 0);

  return {
    subtotal,
    shipping,
    discount,
    tax,
    finalAmount,
    taxBreakdown: {
      gstEnabled: isGstActive,
      gstRate,
      gstType,
      gstAmount: tax,
      storeGstin: isGstActive && storeSettings.showGstinOnInvoice ? storeSettings.gstin : undefined,
    },
    items: verifiedItems,
  };
}

// ─────────────────────────────────────────────────────────────
// RAZORPAY PAYMENT ENDPOINTS
// ─────────────────────────────────────────────────────────────

// 0. Public Razorpay Configuration (exposing only safe public key ID and mode)
app.get('/api/payments/razorpay/config', async (_req, res) => {
  try {
    const credentials = await getResolvedRazorpayCredentials();
    const settings = await getPaymentSettingsRecord();
    res.json({
      success: true,
      message: 'Razorpay configuration retrieved successfully',
      keyId: credentials.keyId || '',
      isConfigured: Boolean(credentials.keyId && credentials.keySecret),
      isActive: (settings as any).isActive ?? true,
      environment: credentials.mode || 'test',
      mode: credentials.mode || 'test',
    });
  } catch (err: any) {
    console.error('Error fetching public Razorpay config:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve payment configuration.',
      error: err?.message || 'Failed to retrieve payment configuration.',
    });
  }
});

// Helper: Safely extract Razorpay SDK error details without leaking secrets
function extractRazorpayErrorMessage(err: any): { message: string; code: string; statusCode: number } {
  const statusCode = Number(err?.statusCode || err?.status) || 400;
  const rzpError = err?.error;
  const description = (typeof rzpError?.description === 'string' && rzpError.description.trim())
    || (typeof err?.description === 'string' && err.description.trim())
    || '';
  const code = (typeof rzpError?.code === 'string' && rzpError.code.trim())
    || (typeof err?.code === 'string' && err.code.trim())
    || 'RAZORPAY_ERROR';
  const baseMessage = typeof err?.message === 'string' && err.message.trim() && err.message !== 'undefined'
    ? err.message.trim()
    : '';

  // 1. Authentication failure (Invalid Key ID or Secret)
  if (statusCode === 401 || /auth/i.test(description) || /auth/i.test(baseMessage)) {
    return {
      message: 'Razorpay authentication failed: Invalid Key ID or Key Secret. Please check your credentials in Admin -> Payment Settings.',
      code: 'RAZORPAY_AUTH_FAILED',
      statusCode: 401,
    };
  }

  // 2. Specific Razorpay error description
  if (description) {
    return {
      message: `Razorpay Error: ${description}`,
      code: code,
      statusCode: statusCode,
    };
  }

  // 3. Network or system error
  if (baseMessage) {
    return {
      message: `Payment gateway error: ${baseMessage}`,
      code: code,
      statusCode: statusCode,
    };
  }

  return {
    message: 'Failed to initiate Razorpay payment. Please verify payment gateway configuration in Admin Settings.',
    code: 'UNKNOWN_PAYMENT_ERROR',
    statusCode: statusCode,
  };
}

// 1. Create Razorpay Order
app.post('/api/payments/razorpay/order', paymentLimiter, optionalCustomerAuth, async (req: CustomerAuthRequest, res) => {
  let activeOrderId = '';
  try {
    const { items, customer, paymentMethod } = req.body;

    if (!customer || !customer.fullName || !customer.phone || !customer.email) {
      res.status(400).json({
        success: false,
        message: 'Customer details (Full Name, Phone, Email) are required.',
        error: 'Customer details (Full Name, Phone, Email) are required.',
      });
      return;
    }

    if (!isValidIndianMobile(customer.phone)) {
      res.status(400).json({
        success: false,
        message: 'Please enter a valid 10-digit Indian mobile number.',
        error: 'Please enter a valid 10-digit Indian mobile number.',
      });
      return;
    }

    if (!isValidEmail(customer.email)) {
      res.status(400).json({
        success: false,
        message: 'Please enter a valid email address.',
        error: 'Please enter a valid email address.',
      });
      return;
    }

    // Independent server-side recalculation of order totals and stock validation
    const calculation = await calculateOrderTotals(items);

    if (!calculation || typeof calculation.finalAmount !== 'number' || isNaN(calculation.finalAmount) || calculation.finalAmount <= 0) {
      res.status(400).json({
        success: false,
        message: 'Invalid order amount calculated. Order total must be greater than zero.',
        error: 'Invalid order amount calculated.',
        code: 'INVALID_AMOUNT',
      });
      return;
    }

    // Check if store Admin has paused online payments
    const paymentSettings = await getPaymentSettingsRecord();
    if (paymentSettings && (paymentSettings as any).isActive === false) {
      res.status(400).json({
        success: false,
        message: 'Online payments via Razorpay are currently paused by the store administrator. Please select Cash on Delivery or contact store support.',
        error: 'Online payments are currently paused.',
        code: 'PAYMENTS_PAUSED',
      });
      return;
    }

    // Get active Razorpay credentials (Priority: 1. Admin config, 2. Env fallback)
    const credentials = await getResolvedRazorpayCredentials();

    if (!credentials.keyId && !credentials.keySecret) {
      res.status(400).json({
        success: false,
        message: 'Razorpay payment gateway is not yet configured. Please configure Razorpay Key ID and Secret in Admin Settings.',
        error: 'Razorpay payment gateway is not yet configured.',
        code: 'RAZORPAY_NOT_CONFIGURED',
      });
      return;
    }

    if (credentials.keyId && !credentials.keySecret) {
      res.status(400).json({
        success: false,
        message: 'Razorpay Key ID is configured, but Key Secret is missing. Please provide both Key ID and Key Secret in Admin Payment Settings.',
        error: 'Razorpay Key Secret is missing.',
        code: 'RAZORPAY_SECRET_MISSING',
      });
      return;
    }

    if (!credentials.keyId && credentials.keySecret) {
      res.status(400).json({
        success: false,
        message: 'Razorpay Key Secret is configured, but Key ID is missing. Please provide both Key ID and Key Secret in Admin Payment Settings.',
        error: 'Razorpay Key ID is missing.',
        code: 'RAZORPAY_KEY_MISSING',
      });
      return;
    }

    // Auto-harmonize mode with Key prefix to ensure seamless checkout
    if (credentials.keyId.startsWith('rzp_live_')) {
      credentials.mode = 'live';
    } else if (credentials.keyId.startsWith('rzp_test_')) {
      credentials.mode = 'test';
    }

    // Amount in paise (integer)
    const amountInPaise = Math.round(calculation.finalAmount * 100);
    if (!Number.isInteger(amountInPaise) || amountInPaise < 100) {
      res.status(400).json({
        success: false,
        message: 'Order amount must be at least ₹1.00 for online payment processing.',
        error: 'Order amount must be at least ₹1.00.',
        code: 'AMOUNT_BELOW_MINIMUM',
      });
      return;
    }

    // Generate persistent, monotonic, collision-safe Order ID (INF-YYYYMMDD-XXXX)
    const internalOrderId = await generateOrderId();
    activeOrderId = internalOrderId;

    // Automatic Customer Profile Linking / Creation (Section 5)
    // Same mobile = same Customer ID
    const customerRecord = await getOrCreateCustomer({
      fullName: customer.fullName,
      phone: customer.phone,
      email: customer.email,
      address: customer.address,
      city: customer.city,
      state: customer.state,
      pincode: customer.pincode,
    });

    // Safe debugging log (Point 19 - NEVER log secret credentials)
    console.log('[Payment Initiation Started]', {
      internalOrderId,
      customerId: customerRecord.id,
      source: credentials.source.toUpperCase(),
      mode: credentials.mode.toUpperCase(),
      keyIdExists: Boolean(credentials.keyId),
      keySecretExists: Boolean(credentials.keySecret),
      calculatedAmount: calculation.finalAmount,
      currency: 'INR',
    });

    const now = new Date();
    const deliveryDate = new Date(now);
    deliveryDate.setDate(now.getDate() + 3);
    const estimatedDeliveryDate = deliveryDate.toLocaleDateString('en-IN', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });

    // Initialize official Razorpay SDK
    const razorpay = new Razorpay({
      key_id: credentials.keyId,
      key_secret: credentials.keySecret,
    });

    // Create Razorpay Order (amount in paise)
    const rzpOrder = await razorpay.orders.create({
      amount: amountInPaise,
      currency: 'INR',
      receipt: internalOrderId,
      notes: {
        internalOrderId,
        customerId: customerRecord.id,
        customerEmail: customer.email,
        customerPhone: customer.phone,
        paymentMethod: paymentMethod === 'upi' ? 'upi' : 'razorpay',
      },
    });

    console.log('[Razorpay API Response]', {
      internalOrderId,
      razorpayOrderId: rzpOrder.id,
      status: rzpOrder.status,
      amount: rzpOrder.amount,
      currency: rzpOrder.currency,
    });

    // Create internal order record with status 'pending'
    const newOrder: OrderRecord = {
      id: internalOrderId,
      customerId: customerRecord.id,
      customer: {
        fullName: customer.fullName.trim(),
        phone: customer.phone.replace(/\D/g, '').slice(-10),
        email: customer.email.trim().toLowerCase(),
        address: (customer.address || '').trim(),
        city: (customer.city || '').trim(),
        state: customer.state || 'West Bengal',
        pincode: (customer.pincode || '').trim(),
      },
      items: calculation.items,
      subtotal: calculation.subtotal,
      discount: calculation.discount,
      shipping: calculation.shipping,
      tax: calculation.tax,
      finalAmount: calculation.finalAmount,
      taxBreakdown: calculation.taxBreakdown,
      b2bDetails: req.body.b2bDetails,
      currency: 'INR',
      paymentMethod: paymentMethod === 'upi' ? 'upi' : 'razorpay',
      paymentStatus: 'pending',
      orderStatus: 'pending',
      razorpayOrderId: rzpOrder.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      estimatedDeliveryDate,
    };

    await addOrder(newOrder);

    // Return safe data to client (NEVER expose keySecret or webhookSecret)
    res.json({
      success: true,
      keyId: credentials.keyId,
      razorpayOrderId: rzpOrder.id,
      amount: rzpOrder.amount, // in paise
      currency: rzpOrder.currency || 'INR',
      internalOrderId,
      orderId: internalOrderId,
      customer: {
        name: customer.fullName,
        email: customer.email,
        contact: customer.phone,
      },
    });
  } catch (err: any) {
    const errorDetails = extractRazorpayErrorMessage(err);
    console.error('[Payment Initiation Error]', {
      internalOrderId: activeOrderId,
      statusCode: errorDetails.statusCode,
      code: errorDetails.code,
      message: errorDetails.message,
    });
    res.status(errorDetails.statusCode || 400).json({
      success: false,
      message: errorDetails.message,
      error: errorDetails.message,
      code: errorDetails.code,
    });
  }
});

// 2. Verify Razorpay Payment Signature
app.post('/api/payments/razorpay/verify', paymentLimiter, optionalCustomerAuth, async (req: CustomerAuthRequest, res) => {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      internal_order_id,
    } = req.body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      res.status(400).json({
        success: false,
        message: 'Missing required Razorpay payment verification parameters.',
        error: 'Missing required Razorpay payment verification parameters.',
      });
      return;
    }

    // Locate internal order
    const order = internal_order_id 
      ? await findOrderById(internal_order_id) 
      : await findOrderByRazorpayOrderId(razorpay_order_id);

    if (!order) {
      res.status(404).json({
        success: false,
        message: 'Order record was not found in system.',
        error: 'Order record was not found in system.',
      });
      return;
    }

    // Customer ownership verification if order was created by logged-in customer
    if (order.customerId && req.customer && order.customerId !== req.customer.id) {
      res.status(403).json({
        success: false,
        message: 'Unauthorized: Order does not belong to the active user session.',
        error: 'Unauthorized: Order does not belong to the active user session.',
      });
      return;
    }

    // Idempotency check: if already paid, return success without duplicate processing
    if (order.paymentStatus === 'paid') {
      if (order.items?.length) await finalizeOrderItems(order.id, order.items);
      const latest = await findOrderById(order.id);
      res.json({ success: true, message: 'Payment has already been confirmed.', order: latest || order });
      return;
    }

    // Verify that razorpay_order_id matches the order's registered ID
    if (order.razorpayOrderId && order.razorpayOrderId !== razorpay_order_id) {
      res.status(400).json({
        success: false,
        message: 'Razorpay order ID mismatch.',
        error: 'Razorpay order ID mismatch.',
      });
      return;
    }

    // Get active Razorpay key secret for signature calculation
    const credentials = await getResolvedRazorpayCredentials();
    if (!credentials.keySecret) {
      res.status(500).json({
        success: false,
        message: 'Payment gateway configuration error.',
        error: 'Payment gateway configuration error.',
      });
      return;
    }

    // Compute expected HMAC SHA256 signature
    const body = `${razorpay_order_id}|${razorpay_payment_id}`;
    const expectedSignature = crypto
      .createHmac('sha256', credentials.keySecret)
      .update(body)
      .digest('hex');

    // Constant-time comparison to prevent timing attacks
    const isSignatureValid = 
      expectedSignature.length === razorpay_signature.length &&
      crypto.timingSafeEqual(
        Buffer.from(expectedSignature, 'utf8'),
        Buffer.from(razorpay_signature, 'utf8')
      );

    if (!isSignatureValid) {
      await updateOrder(order.id, {
        paymentStatus: 'failed',
        paymentFailureReason: 'Signature mismatch during verification',
      });
      res.status(400).json({
        success: false,
        message: 'Invalid payment signature. Verification failed.',
        error: 'Invalid payment signature. Verification failed.',
      });
      return;
    }

    // Signature verified! Update order status to paid and confirmed
    const updatedOrder = await updateOrder(order.id, {
      paymentStatus: 'paid',
      orderStatus: 'confirmed',
      razorpayPaymentId: razorpay_payment_id,
      razorpaySignature: razorpay_signature,
      paidAt: new Date().toISOString(),
    });
    if (order.items && Array.isArray(order.items)) {
      await finalizeOrderItems(order.id, order.items);
    }

    res.json({
      success: true,
      message: 'Payment verified and order confirmed successfully.',
      order: updatedOrder,
    });
  } catch (err: any) {
    console.error('Razorpay verification error:', err);
    res.status(500).json({
      success: false,
      message: 'Internal error during payment verification.',
      error: 'Internal error during payment verification.',
    });
  }
});

// 3. Record Failed / Dismissed Payment Safely
app.post('/api/payments/razorpay/failed', async (req, res) => {
  try {
    const { internal_order_id, razorpay_order_id, reason } = req.body;
    const order = internal_order_id 
      ? await findOrderById(internal_order_id) 
      : (razorpay_order_id ? await findOrderByRazorpayOrderId(razorpay_order_id) : undefined);

    if (order && order.paymentStatus !== 'paid') {
      await updateOrder(order.id, {
        paymentStatus: 'failed',
        paymentFailureReason: reason || 'Payment cancelled or dismissed by customer',
      });
    }

    res.json({ success: true });
  } catch {
    res.json({ success: false });
  }
});

// 4. Cash on Delivery (COD) Flow
app.post('/api/orders/cod', paymentLimiter, optionalCustomerAuth, async (req: CustomerAuthRequest, res) => {
  try {
    const { customer, items } = req.body;

    if (!customer || !customer.fullName || !customer.phone || !customer.email || !customer.address || !customer.city || !customer.pincode) {
      res.status(400).json({ error: 'All delivery address fields are required for Cash on Delivery.' });
      return;
    }

    if (!isValidIndianMobile(customer.phone)) {
      res.status(400).json({ error: 'Please enter a valid 10-digit Indian mobile number.' });
      return;
    }

    if (!isValidEmail(customer.email)) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }

    // Recalculate price, quantity, discount, shipping, and total independently on server
    const calculation = await calculateOrderTotals(items);

    // Generate persistent, monotonic, collision-safe Order ID (INF-YYYYMMDD-XXXX)
    const internalOrderId = await generateOrderId();

    // Automatic Customer Profile Linking / Creation (Section 5)
    // Same mobile = same Customer ID
    const customerRecord = await getOrCreateCustomer({
      fullName: customer.fullName,
      phone: customer.phone,
      email: customer.email,
      address: customer.address,
      city: customer.city,
      state: customer.state,
      pincode: customer.pincode,
    });

    const now = new Date();
    const deliveryDate = new Date(now);
    deliveryDate.setDate(now.getDate() + 3);
    const estimatedDeliveryDate = deliveryDate.toLocaleDateString('en-IN', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });

    const newOrder: OrderRecord = {
      id: internalOrderId,
      customerId: customerRecord.id,
      customer: {
        fullName: customer.fullName.trim(),
        phone: customer.phone.replace(/\D/g, '').slice(-10),
        email: customer.email.trim().toLowerCase(),
        address: customer.address.trim(),
        city: customer.city.trim(),
        state: customer.state || 'West Bengal',
        pincode: customer.pincode.trim(),
      },
      items: calculation.items,
      subtotal: calculation.subtotal,
      discount: calculation.discount,
      shipping: calculation.shipping,
      tax: calculation.tax,
      finalAmount: calculation.finalAmount,
      taxBreakdown: calculation.taxBreakdown,
      b2bDetails: req.body.b2bDetails,
      currency: 'INR',
      paymentMethod: 'cod',
      paymentStatus: 'pending',
      orderStatus: 'confirmed',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      estimatedDeliveryDate,
    };

    await addOrder(newOrder);

    res.status(201).json({
      success: true,
      message: 'Order Confirmed',
      order: newOrder,
    });
  } catch (err: any) {
    console.error('COD Order error:', err);
    res.status(400).json({ error: err.message || 'Failed to place COD order.' });
  }
});

// 5. Razorpay Webhook Endpoint (Supports both paths)
app.post(['/api/payments/razorpay/webhook', '/api/razorpay/webhook'], async (req: any, res) => {
  try {
    const webhookSignature = req.headers['x-razorpay-signature'] as string;
    if (!webhookSignature) {
      res.status(400).json({ error: 'Missing x-razorpay-signature header' });
      return;
    }

    const { webhookSecret } = await getResolvedRazorpayCredentials();
    if (!webhookSecret) {
      console.warn('[Webhook] Webhook secret not configured on server');
      res.status(400).json({ error: 'Webhook secret not configured on server' });
      return;
    }

    const rawBody = req.rawBody || JSON.stringify(req.body);
    const expectedSignature = crypto
      .createHmac('sha256', webhookSecret)
      .update(rawBody)
      .digest('hex');

    const isMatch = 
      expectedSignature.length === webhookSignature.length &&
      crypto.timingSafeEqual(
        Buffer.from(expectedSignature, 'utf8'),
        Buffer.from(webhookSignature, 'utf8')
      );

    if (!isMatch) {
      console.warn('[Webhook] Webhook signature mismatch.');
      res.status(400).json({ error: 'Invalid webhook signature' });
      return;
    }

    const event = req.body;
    const eventId = event.id || req.headers['x-razorpay-event-id'];

    // Idempotency check: prevent duplicate event execution
    if (eventId && await isWebhookEventProcessed(eventId)) {
      res.status(200).json({ status: 'ok', message: 'Already processed' });
      return;
    }

    const eventType = event.event;
    console.log(`[Webhook] Processing verified event: ${eventType}`);

    if (eventType === 'payment.captured' || eventType === 'order.paid') {
      const paymentEntity = event.payload?.payment?.entity;
      const rzpOrderId = paymentEntity?.order_id || event.payload?.order?.entity?.id;
      const rzpPaymentId = paymentEntity?.id;

      if (rzpOrderId) {
        const order = await findOrderByRazorpayOrderId(rzpOrderId);
        if (order && order.paymentStatus !== 'paid') {
          await updateOrder(order.id, {
            paymentStatus: 'paid',
            orderStatus: 'confirmed',
            razorpayPaymentId: rzpPaymentId || order.razorpayPaymentId,
            paidAt: new Date().toISOString(),
          });
          console.log(`[Webhook] Order ${order.id} marked as PAID via webhook event ${eventType}`);
        }
      }
    } else if (eventType === 'payment.failed') {
      const paymentEntity = event.payload?.payment?.entity;
      const rzpOrderId = paymentEntity?.order_id;
      if (rzpOrderId) {
        const order = await findOrderByRazorpayOrderId(rzpOrderId);
        if (order && order.paymentStatus !== 'paid') {
          await updateOrder(order.id, {
            paymentStatus: 'failed',
            paymentFailureReason: paymentEntity?.error_description || 'Payment failed via webhook',
          });
        }
      }
    }

    if (eventId) {
      await markWebhookEventProcessed(eventId);
    }

    res.status(200).json({ status: 'ok' });
  } catch (err: any) {
    console.error('[Webhook] Error:', err);
    res.status(500).json({ error: 'Webhook processing error' });
  }
});

// ─────────────────────────────────────────────────────────────
// ORDER QUERY ENDPOINTS
// ─────────────────────────────────────────────────────────────

// Get single order by ID
app.get('/api/orders/:id', async (req, res) => {
  const order = await findOrderById(req.params.id);
  if (!order) {
    res.status(404).json({ error: 'Order not found' });
    return;
  }
  res.json({ success: true, order });
});

// Customer: Get My Orders
app.get('/api/customer/orders', requireCustomerAuth, async (req: CustomerAuthRequest, res) => {
  const customer = req.customer!;
  const orders = await getOrdersByCustomerId(customer.id);
  // Also check orders placed with matching email/mobile
  const allMatching = await getOrdersByCustomerEmailOrMobile(customer.email, customer.mobile);
  
  // Merge and deduplicate by id
  const map = new Map<string, OrderRecord>();
  orders.forEach(o => map.set(o.id, o));
  allMatching.forEach(o => map.set(o.id, o));
  
  res.json({
    success: true,
    orders: Array.from(map.values()),
  });
});

// Admin: View All Orders
app.get('/api/admin/orders', requireAdminAuth, async (req, res) => {
  const orders = await getAllOrders();
  res.json({
    success: true,
    orders,
  });
});

// Admin: Update Order Package/Fulfillment Status
app.put('/api/admin/orders/:id/status', requireAdminAuth, async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const validStatuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'received', 'dispatched'];
  if (!status || !validStatuses.includes(status)) {
    res.status(400).json({ error: 'Invalid order status value.' });
    return;
  }

  let mappedStatus = status;
  if (status === 'received') mappedStatus = 'confirmed';
  if (status === 'dispatched') mappedStatus = 'shipped';

  const updated = await updateOrder(id, {
    orderStatus: mappedStatus as any,
  });

  if (!updated) {
    res.status(404).json({ error: 'Order not found' });
    return;
  }

  res.json({
    success: true,
    order: updated,
  });
});

// ─────────────────────────────────────────────────────────────
// ADMIN PAYMENT SETTINGS (RAZORPAY)
// ─────────────────────────────────────────────────────────────

// View payment settings (Secrets are NEVER returned in plain text)
const handleGetPaymentSettings = async (req: AdminAuthRequest, res: any) => {
  try {
    const settings = await getPaymentSettingsRecord();
    const resolved = await getResolvedRazorpayCredentials();

    let maskedKeyId = resolved.keyId || '';
    if (maskedKeyId.length > 12) {
      maskedKeyId = maskedKeyId.slice(0, 8) + '••••••••' + maskedKeyId.slice(-4);
    }

    const safeSettings = {
      keyId: resolved.keyId || '',
      maskedKeyId,
      rawKeyId: resolved.keyId || '',
      hasKeySecret: Boolean(resolved.keySecret),
      hasWebhookSecret: Boolean(resolved.webhookSecret),
      isConfigured: Boolean(resolved.keyId && resolved.keySecret),
      isActive: (settings as any).isActive ?? true,
      environment: resolved.mode || 'test',
      mode: resolved.mode || 'test',
      status: resolved.keyId && resolved.keySecret ? 'connected' : 'not_configured',
      source: resolved.source,
      updatedAt: settings.updatedAt,
      updatedBy: settings.updatedBy,
      auditLogs: (await getPaymentAuditLogs()).slice(0, 10),
    };

    res.json({
      success: true,
      message: 'Payment settings loaded successfully.',
      settings: safeSettings,
      configured: safeSettings.isConfigured,
      ...safeSettings,
    });
  } catch (err: any) {
    console.error('Get payment settings error:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to load payment settings.',
      error: err?.message || 'Failed to load payment settings.',
    });
  }
};

// Update payment settings (Admin enters new credentials to replace)
const handleSavePaymentSettings = async (req: AdminAuthRequest, res: any) => {
  try {
    const { mode, environment, keyId, keySecret, webhookSecret, isActive } = req.body || {};
    const adminEmail = req.adminEmail || 'infostors24@gmail.com';

    const updates: Partial<PaymentSettingsRecord> = {};

    const effectiveMode = environment || mode;
    if (effectiveMode && (effectiveMode === 'test' || effectiveMode === 'live')) {
      updates.mode = effectiveMode;
    }

    if (typeof isActive === 'boolean') {
      updates.isActive = isActive;
    }

    if (typeof keyId === 'string' && keyId.trim().length > 0) {
      updates.keyId = keyId.trim();
    }

    // Only update Key Secret if a new non-empty string is provided (ignoring mask dots)
    if (typeof keySecret === 'string' && keySecret.trim().length > 0 && !keySecret.includes('•')) {
      updates.keySecretEncrypted = keySecret.trim();
    }

    // Only update Webhook Secret if a new non-empty string is provided
    if (typeof webhookSecret === 'string' && webhookSecret.trim().length > 0 && !webhookSecret.includes('•')) {
      updates.webhookSecretEncrypted = webhookSecret.trim();
    }

    await updatePaymentSettingsRecord(updates, adminEmail);

    const resolved = await getResolvedRazorpayCredentials();
    const currentSettings = await getPaymentSettingsRecord();

    let maskedKeyId = resolved.keyId || '';
    if (maskedKeyId.length > 12) {
      maskedKeyId = maskedKeyId.slice(0, 8) + '••••••••' + maskedKeyId.slice(-4);
    }

    const safeSettings = {
      keyId: resolved.keyId || '',
      maskedKeyId,
      rawKeyId: resolved.keyId || '',
      hasKeySecret: Boolean(resolved.keySecret),
      hasWebhookSecret: Boolean(resolved.webhookSecret),
      isConfigured: Boolean(resolved.keyId && resolved.keySecret),
      isActive: (currentSettings as any).isActive ?? true,
      environment: resolved.mode || 'test',
      mode: resolved.mode || 'test',
      status: resolved.keyId && resolved.keySecret ? 'connected' : 'not_configured',
      source: resolved.source,
      updatedAt: currentSettings.updatedAt,
      updatedBy: currentSettings.updatedBy,
    };

    res.json({
      success: true,
      message: 'Razorpay configuration saved securely.',
      configured: safeSettings.isConfigured,
      settings: safeSettings,
      ...safeSettings,
    });
  } catch (err: any) {
    console.error('Update payment settings error:', err);
    res.status(500).json({
      success: false,
      message: 'Unable to save Razorpay settings.',
      error: err?.message || 'Failed to save payment settings.',
    });
  }
};

// Test Connection with configured Razorpay credentials
const handleTestPaymentConnection = async (req: AdminAuthRequest, res: any) => {
  try {
    const { keyId: bodyKeyId, keySecret: bodyKeySecret } = req.body || {};
    const resolved = await getResolvedRazorpayCredentials();

    const testKeyId = (typeof bodyKeyId === 'string' && bodyKeyId.trim())
      ? bodyKeyId.trim()
      : resolved.keyId;

    const testKeySecret = (typeof bodyKeySecret === 'string' && bodyKeySecret.trim() && !bodyKeySecret.includes('•'))
      ? bodyKeySecret.trim()
      : resolved.keySecret;

    if (!testKeyId || !testKeySecret) {
      res.status(400).json({
        success: false,
        message: 'Razorpay Key ID and Key Secret must both be provided or configured before testing connection.',
        error: 'Razorpay Key ID and Key Secret must both be configured before testing connection.',
      });
      return;
    }

    // Test official Razorpay client
    const razorpay = new Razorpay({
      key_id: testKeyId,
      key_secret: testKeySecret,
    });

    // Make a light read-only call to verify authentication with Razorpay server
    await razorpay.orders.all({ count: 1 });

    res.json({
      success: true,
      message: `Razorpay connection successful (${resolved.mode.toUpperCase()} mode)`,
      configured: true,
      mode: resolved.mode,
    });
  } catch (err: any) {
    console.error('Razorpay test connection error:', err?.message || err);
    const isAuthError = err?.statusCode === 401 || err?.error?.description?.toLowerCase().includes('auth') || err?.message?.toLowerCase().includes('auth');
    res.status(400).json({
      success: false,
      message: isAuthError
        ? 'Razorpay credentials are invalid. Please verify your Key ID and Key Secret.'
        : (err?.error?.description || err?.message || 'Razorpay connection test failed.'),
      error: isAuthError
        ? 'Razorpay credentials are invalid.'
        : (err?.error?.description || err?.message || 'Razorpay connection test failed.'),
    });
  }
};

// Mount Payment Settings endpoints for both URL patterns
app.get(['/api/admin/payments/razorpay', '/api/admin/payment-settings'], requireAdminAuth, handleGetPaymentSettings);
app.post(['/api/admin/payments/razorpay', '/api/admin/payment-settings'], requireAdminAuth, handleSavePaymentSettings);
app.put(['/api/admin/payments/razorpay', '/api/admin/payment-settings'], requireAdminAuth, handleSavePaymentSettings);
app.post(['/api/admin/payments/razorpay/test', '/api/admin/payment-settings/test'], requireAdminAuth, handleTestPaymentConnection);

// ─────────────────────────────────────────────────────────────
// DELETE REQUEST SYSTEM & APPROVAL WORKFLOW (Sections 18-22)
// ─────────────────────────────────────────────────────────────

// GET all delete requests
app.get('/api/admin/delete-requests', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  const requests = await getAllDeleteRequests();
  res.json({ success: true, requests });
});

// POST create a delete request (Admins can request, only Main Admin approves)
app.post('/api/admin/delete-requests', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  const { targetType, targetId, reason, targetSummary } = req.body;

  if (!targetType || !targetId || !reason || reason.trim().length < 5) {
    res.status(400).json({
      success: false,
      error: 'Target type, Target ID, and a valid reason (min 5 chars) are required.',
    });
    return;
  }

  if (targetType !== 'order' && targetType !== 'customer') {
    res.status(400).json({
      success: false,
      error: 'Invalid target type. Must be "order" or "customer".',
    });
    return;
  }

  // Prevent multiple pending requests for the same target
  const existingPending = (await getAllDeleteRequests()).find(
    r => r.targetId === targetId && r.status === 'PENDING'
  );
  if (existingPending) {
    res.status(400).json({
      success: false,
      error: `A pending delete request for ${targetType} #${targetId} already exists.`,
    });
    return;
  }

  const id = `del_req_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`;
  const record: DeleteRequestRecord = {
    id,
    targetType,
    targetId,
    targetSummary: targetSummary || `${targetType.toUpperCase()} #${targetId}`,
    requestedByEmail: req.admin?.email || 'admin@infostors.com',
    requestedByName: req.admin?.name || req.admin?.email,
    requestedByRole: (req.admin?.role as 'main_admin' | 'admin') || 'admin',
    reason: reason.trim(),
    status: 'PENDING',
    createdAt: new Date().toISOString(),
  };

  await addDeleteRequest(record);

  // Log in Audit Log
  await addAuditLog({
    adminEmail: req.admin?.email || 'admin',
    adminName: req.admin?.name,
    action: 'delete_request_created',
    targetType,
    targetId,
    reason: reason.trim(),
    result: 'SUCCESS',
    details: `Created deletion request for ${targetType} #${targetId}`,
  });

  res.status(201).json({
    success: true,
    message: 'Delete request submitted successfully and queued for Main Administrator review.',
    request: record,
  });
});

// POST Approve Delete Request (Strictly Main Admin only: infostors24@gmail.com)
app.post('/api/admin/delete-requests/:id/approve', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  const isMainAdmin = req.admin?.role === 'main_admin' || req.admin?.email.toLowerCase() === 'infostors24@gmail.com';

  if (!isMainAdmin) {
    res.status(403).json({
      success: false,
      error: 'Access Denied: Only the Primary Main Administrator (infostors24@gmail.com) can approve deletion requests.',
    });
    return;
  }

  const request = await findDeleteRequestById(req.params.id);
  if (!request) {
    res.status(404).json({ success: false, error: 'Delete request not found.' });
    return;
  }

  if (request.status !== 'PENDING' && request.status !== 'FAILED') {
    res.status(400).json({
      success: false,
      error: `Request cannot be approved because current status is ${request.status}.`,
    });
    return;
  }

  // 1. Execute deletion in Primary Database
  if (request.targetType === 'order') {
    const deleted = await deleteOrderById(request.targetId);
    if (!deleted) {
      console.warn(`Order #${request.targetId} already removed or not found in local db`);
    }
  } else if (request.targetType === 'customer') {
    const deleted = await deleteCustomerById(request.targetId);
    if (!deleted) {
      console.warn(`Customer #${request.targetId} already removed or not found in local db`);
    }
  }

  // 2. Update Request Status
  const updatedReq = await updateDeleteRequest(request.id, {
    status: 'COMPLETED',
    reviewedByEmail: req.admin?.email,
    reviewedByName: req.admin?.name,
    reviewedAt: new Date().toISOString(),
    completedAt: new Date().toISOString(),
  });

  // 3. Log in Audit Log
  await addAuditLog({
    adminEmail: req.admin?.email || 'admin',
    adminName: req.admin?.name,
    action: 'delete_request_approved',
    targetType: request.targetType,
    targetId: request.targetId,
    reason: request.reason,
    result: 'SUCCESS',
    details: `Approved and completed deletion of ${request.targetType} #${request.targetId} from database`,
  });

  res.json({
    success: true,
    message: `${request.targetType === 'order' ? 'Order' : 'Customer'} #${request.targetId} successfully deleted from Database.`,
    request: updatedReq,
  });
});

// POST Reject Delete Request (Strictly Main Admin only)
app.post('/api/admin/delete-requests/:id/reject', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  const isMainAdmin = req.admin?.role === 'main_admin' || req.admin?.email.toLowerCase() === 'infostors24@gmail.com';

  if (!isMainAdmin) {
    res.status(403).json({
      success: false,
      error: 'Access Denied: Only the Primary Main Administrator can reject deletion requests.',
    });
    return;
  }

  const request = await findDeleteRequestById(req.params.id);
  if (!request) {
    res.status(404).json({ success: false, error: 'Delete request not found.' });
    return;
  }

  const rejectionReason = (req.body.reason || 'Rejected by Main Administrator.').trim();

  const updatedReq = await updateDeleteRequest(request.id, {
    status: 'REJECTED',
    rejectionReason,
    reviewedByEmail: req.admin?.email,
    reviewedByName: req.admin?.name,
    reviewedAt: new Date().toISOString(),
  });

  // Log in Audit Log
  await addAuditLog({
    adminEmail: req.admin?.email || 'admin',
    adminName: req.admin?.name,
    action: 'delete_request_rejected',
    targetType: request.targetType,
    targetId: request.targetId,
    reason: rejectionReason,
    result: 'REJECTED',
    details: `Rejected deletion request for ${request.targetType} #${request.targetId}: ${rejectionReason}`,
  });

  res.json({
    success: true,
    message: `Delete request for #${request.targetId} rejected. No data was deleted.`,
    request: updatedReq,
  });
});

// ─────────────────────────────────────────────────────────────
// AUDIT LOG SYSTEM (Section 26)
// ─────────────────────────────────────────────────────────────

app.get('/api/admin/audit-logs', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  const logs = await getAllAuditLogs();
  res.json({ success: true, logs });
});

// ─────────────────────────────────────────────────────────────
// ORDER DISPATCH / COURIER UPDATE ENDPOINT
// ─────────────────────────────────────────────────────────────

app.put('/api/admin/orders/:id/dispatch', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  const { courierPartner, trackingId, orderStatus } = req.body;
  const order = await findOrderById(req.params.id);

  if (!order) {
    res.status(404).json({ success: false, error: 'Order not found.' });
    return;
  }

  const updatedOrder = await updateOrder(order.id, {
    courierPartner: courierPartner || order.courierPartner,
    trackingId: trackingId || order.trackingId,
    orderStatus: orderStatus || 'shipped',
  });

  if (updatedOrder) {
    await addAuditLog({
      adminEmail: req.admin?.email || 'admin',
      adminName: req.admin?.name,
      action: 'order_dispatched',
      targetType: 'order',
      targetId: order.id,
      result: 'SUCCESS',
      details: `Updated courier to ${courierPartner || 'Delhivery Express'}, tracking ID: ${trackingId || 'N/A'}, status: ${orderStatus || 'shipped'}`,
    });
  }

  res.json({
    success: true,
    message: `Order #${order.id} dispatch details updated.`,
    order: updatedOrder,
  });
});

// ─────────────────────────────────────────────────────────────
// CUSTOMER MESSAGING & PER-CUSTOMER OFFERS (Section 17)
// ─────────────────────────────────────────────────────────────

// 1. Admin sends private message or offer to specific customer
app.post('/api/admin/customer-messages', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const { customerId, customerEmail, customerMobile, subject, message, messageType } = req.body;
    if (!customerId || !message) {
      res.status(400).json({ success: false, error: 'Customer ID and message content are required.' });
      return;
    }

    const newMsg = await addCustomerMessage({
      customerId,
      customerEmail,
      customerMobile,
      senderType: 'admin',
      senderName: req.admin?.name || 'INFOSTORS Staff',
      subject: subject || 'Message from INFOSTORS Support',
      message: message.trim(),
      messageType: messageType || 'support',
    });

    await addAuditLog({
      adminEmail: req.admin?.email || 'admin',
      adminName: req.admin?.name || 'Admin',
      action: 'customer_message_sent',
      targetType: 'customer',
      targetId: customerId,
      result: 'SUCCESS',
      details: `Sent ${messageType || 'support'} message to customer ${customerId}`,
    });

    res.status(201).json({ success: true, message: 'Message delivered to customer account', record: newMsg });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to send message.' });
  }
});

// 2. Admin retrieves conversation thread with specific customer
app.get('/api/admin/customer-messages/:customerId', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const { customerId } = req.params;
    const messages = await getCustomerMessages(customerId);
    res.json({ success: true, messages });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to retrieve messages.' });
  }
});

// 3. Customer retrieves their own private messages (Strictly isolated - no IDOR, no data leakage)
app.get('/api/customer/messages', requireCustomerAuth, async (req: CustomerAuthRequest, res) => {
  try {
    const customerId = req.customer.id;
    const messages = await getCustomerMessages(customerId);
    res.json({ success: true, messages });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to retrieve your messages.' });
  }
});

// ─────────────────────────────────────────────────────────────
// PUSH & IN-APP NOTIFICATIONS ENGINE (Section 16)
// ─────────────────────────────────────────────────────────────

// Admin dispatches notification
app.post('/api/admin/notifications', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const { title, body, targetAudience, targetCustomerId, category } = req.body;
    if (!title || !body) {
      res.status(400).json({ success: false, error: 'Headline and message body are required.' });
      return;
    }

    const notif = await addNotification({
      title: title.trim(),
      body: body.trim(),
      targetAudience: targetAudience || 'all',
      targetCustomerId,
      category: category || 'promo',
      status: 'sent',
      sentBy: req.admin?.email || 'admin',
    });

    await addAuditLog({
      adminEmail: req.admin?.email || 'admin',
      adminName: req.admin?.name || 'Admin',
      action: 'notification_broadcast',
      targetType: 'notification',
      targetId: notif.id,
      result: 'SUCCESS',
      details: `Broadcast notification "${title}" to ${targetAudience || 'all'} audience`,
    });

    res.status(201).json({ success: true, message: 'Notification published', notification: notif });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to dispatch notification.' });
  }
});

// Admin lists notification history
app.get('/api/admin/notifications', requireAdminAuth, async (_req, res) => {
  try {
    const notifications = await getAllNotifications();
    res.json({ success: true, notifications });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to retrieve notifications.' });
  }
});

// Customer in-app announcements
app.get('/api/customer/notifications', async (_req, res) => {
  try {
    const all = await getAllNotifications();
    const publicNotifs = all.filter(n => n.targetAudience === 'all' || !n.targetCustomerId);
    res.json({ success: true, notifications: publicNotifs });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to retrieve notifications.' });
  }
});

// Secure server-side backup export. Secrets/password hashes are intentionally excluded.
app.get('/api/admin/backup/export', requireAdminAuth, async (_req: AdminAuthRequest, res) => {
  try {
    const [products, categories, orders, customers, settings] = await Promise.all([
      getAllProducts(), getAllCategories(), getAllOrders(), getAllCustomers(), getStoreSettingsRecord(),
    ]);
    res.json({
      success: true,
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
      source: 'Supabase PostgreSQL',
      products, categories, orders,
      customers: customers.map((c:any) => ({ id:c.id, fullName:c.fullName, email:c.email, mobile:c.mobile, createdAt:c.createdAt, updatedAt:c.updatedAt })),
      storeSettings: settings,
    });
  } catch (err:any) { res.status(500).json({success:false,error:err.message || 'Backup export failed.'}); }
});

// Safe restore: catalog + categories + store settings only. Orders/customers are never overwritten from a browser backup.
app.post('/api/admin/backup/restore', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const b = req.body;
    if (!b || !Array.isArray(b.products) || !Array.isArray(b.categories)) { res.status(400).json({success:false,error:'Invalid backup format.'}); return; }
    for (const category of b.categories) await saveCategory(category);
    for (const product of b.products) await saveProduct(product);
    if (b.storeSettings && typeof b.storeSettings === 'object') await updateStoreSettingsRecord(b.storeSettings, req.adminEmail);
    await addAuditLog({adminEmail:req.adminEmail || 'admin',adminName:req.admin?.name,action:'backup_restore_catalog',targetType:'backup',targetId:'catalog',result:'SUCCESS',details:`Restored ${b.products.length} products and ${b.categories.length} categories. Orders/customers were intentionally not overwritten.`});
    res.json({success:true,message:'Catalog, categories and store settings restored safely. Orders and customers were not overwritten.'});
  } catch (err:any) { res.status(500).json({success:false,error:err.message || 'Backup restore failed.'}); }
});

// ─────────────────────────────────────────────────────────────
// 13 MASTER ECOMMERCE API ENDPOINTS
// ─────────────────────────────────────────────────────────────

// 1. Coupons
app.get('/api/coupons', async (_req, res) => {
  try {
    const coupons = await getActiveCoupons();
    res.json({ success: true, coupons });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.get('/api/admin/coupons', requireAdminAuth, async (_req, res) => {
  try {
    const coupons = await getAllCoupons();
    res.json({ success: true, coupons });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/admin/coupons', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const coupon = await saveCoupon(req.body);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'save_coupon', targetType: 'coupon', targetId: coupon.code, result: 'SUCCESS', details: `Saved coupon ${coupon.code}` });
    res.json({ success: true, coupon });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.delete('/api/admin/coupons/:id', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    await deleteCoupon(req.params.id);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'delete_coupon', targetType: 'coupon', targetId: req.params.id, result: 'SUCCESS', details: `Deleted coupon ${req.params.id}` });
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/coupons/apply', async (req, res) => {
  try {
    const { code, subtotal, customerId, isFirstOrder } = req.body;
    if (!code) { res.status(400).json({ success: false, error: 'Coupon code required.' }); return; }
    const result = await validateCoupon(code, Number(subtotal || 0), customerId, !!isFirstOrder);
    if (!result.valid) {
      res.status(400).json({ success: false, error: result.error });
      return;
    }
    res.json({
      success: true,
      valid: true,
      discountAmount: result.discountAmount,
      coupon: {
        code: result.coupon.code,
        discountType: result.coupon.discountType,
        discountValue: result.coupon.discountValue,
        minOrderValue: result.coupon.minOrderValue
      }
    });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 2. Flash Sales
app.get('/api/flash-sales', async (_req, res) => {
  try {
    const flashSales = await getActiveFlashSales();
    res.json({ success: true, flashSales });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.get('/api/admin/flash-sales', requireAdminAuth, async (_req, res) => {
  try {
    const flashSales = await getAllFlashSales();
    res.json({ success: true, flashSales });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/admin/flash-sales', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const flashSale = await saveFlashSale(req.body);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'save_flash_sale', targetType: 'flash_sale', targetId: flashSale.id, result: 'SUCCESS', details: `Saved flash sale: ${flashSale.title}` });
    res.json({ success: true, flashSale });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.delete('/api/admin/flash-sales/:id', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    await deleteFlashSale(req.params.id);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'delete_flash_sale', targetType: 'flash_sale', targetId: req.params.id, result: 'SUCCESS', details: `Deleted flash sale ${req.params.id}` });
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 3. Reviews & Ratings
app.get('/api/products/:id/reviews', async (req, res) => {
  try {
    const reviews = await getProductReviews(req.params.id);
    res.json({ success: true, reviews });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/products/:id/reviews', optionalCustomerAuth, async (req: CustomerAuthRequest, res) => {
  try {
    const review = await addReview({
      ...req.body,
      productId: req.params.id,
      customerId: req.customer?.id,
      customerName: req.customer?.fullName || req.body.customerName || 'Verified Buyer'
    });
    res.json({ success: true, review });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.get('/api/admin/reviews', requireAdminAuth, async (_req, res) => {
  try {
    const reviews = await getAllReviews();
    res.json({ success: true, reviews });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.put('/api/admin/reviews/:id/moderate', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const { status } = req.body;
    const review = await moderateReview(req.params.id, status);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'moderate_review', targetType: 'review', targetId: req.params.id, result: 'SUCCESS', details: `Review status updated to ${status}` });
    res.json({ success: true, review });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.delete('/api/admin/reviews/:id', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    await deleteReview(req.params.id);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'delete_review', targetType: 'review', targetId: req.params.id, result: 'SUCCESS', details: `Deleted review ${req.params.id}` });
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 4. Returns
app.get('/api/customer/returns', requireCustomerAuth, async (req: CustomerAuthRequest, res) => {
  try {
    const returns = await getCustomerReturns(req.customer!.id);
    res.json({ success: true, returns });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/customer/returns', requireCustomerAuth, async (req: CustomerAuthRequest, res) => {
  try {
    const returnReq = await addReturnRequest({
      ...req.body,
      customerId: req.customer!.id,
      customerName: req.customer!.fullName,
      customerPhone: req.customer!.mobile,
      customerEmail: req.customer!.email
    });
    res.json({ success: true, returnRequest: returnReq });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.get('/api/admin/returns', requireAdminAuth, async (_req, res) => {
  try {
    const returns = await getAllReturns();
    res.json({ success: true, returns });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.put('/api/admin/returns/:id/status', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const { status, adminNotes } = req.body;
    const returnReq = await updateReturnStatus(req.params.id, status, adminNotes);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'update_return_status', targetType: 'return_request', targetId: req.params.id, result: 'SUCCESS', details: `Return status changed to ${status}` });
    res.json({ success: true, returnRequest: returnReq });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 5. Refunds
app.get('/api/admin/refunds', requireAdminAuth, async (_req, res) => {
  try {
    const refunds = await getAllRefunds();
    res.json({ success: true, refunds });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/admin/refunds', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const refund = await addRefundRecord(req.body);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'create_refund', targetType: 'refund', targetId: refund.id, result: 'SUCCESS', details: `Created refund for ₹${refund.amount}` });
    res.json({ success: true, refund });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.put('/api/admin/refunds/:id/status', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const { status, notes } = req.body;
    const refund = await updateRefundStatus(req.params.id, status, notes);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'update_refund_status', targetType: 'refund', targetId: req.params.id, result: 'SUCCESS', details: `Refund status updated to ${status}` });
    res.json({ success: true, refund });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 6. Delivery API
app.get('/api/admin/delivery/status', requireAdminAuth, async (_req, res) => {
  try {
    const settings = await getStoreSettingsRecord();
    const delivery = settings.deliveryApiSettings || {
      provider: 'delhivery',
      liveMode: false,
      autoGenerateWaybill: true,
      status: 'NOT CONFIGURED'
    };
    res.json({ success: true, delivery });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/admin/delivery/config', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const deliverySettings = req.body;
    const settings = await getStoreSettingsRecord();
    const updated = await updateStoreSettingsRecord({ ...settings, deliveryApiSettings: deliverySettings }, req.adminEmail);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'update_delivery_config', targetType: 'settings', targetId: 'delivery', result: 'SUCCESS', details: `Updated delivery provider settings: ${deliverySettings.provider}` });
    res.json({ success: true, delivery: updated.deliveryApiSettings });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 7. WhatsApp API
app.get('/api/admin/whatsapp/status', requireAdminAuth, async (_req, res) => {
  try {
    const settings = await getStoreSettingsRecord();
    const whatsapp = settings.whatsAppApiSettings || {
      provider: 'wati',
      phoneNumberId: '',
      enabledTemplates: {},
      status: 'NOT CONFIGURED'
    };
    res.json({ success: true, whatsapp });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/admin/whatsapp/config', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const whatsappSettings = req.body;
    const settings = await getStoreSettingsRecord();
    const updated = await updateStoreSettingsRecord({ ...settings, whatsAppApiSettings: whatsappSettings }, req.adminEmail);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'update_whatsapp_config', targetType: 'settings', targetId: 'whatsapp', result: 'SUCCESS', details: 'Updated WhatsApp API settings' });
    res.json({ success: true, whatsapp: updated.whatsAppApiSettings });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 8. Email Notifications
app.get('/api/admin/email/status', requireAdminAuth, async (_req, res) => {
  try {
    const settings = await getStoreSettingsRecord();
    const email = settings.emailSettings || {
      provider: 'resend',
      fromEmail: 'INFOSTORS <no-reply@infostors.com>',
      enabledEvents: { welcome: true, orderConfirmation: true, shippingUpdate: true, delivery: true, cancellation: true, returnUpdate: true, refundUpdate: true, passwordReset: true },
      status: process.env.RESEND_API_KEY ? 'CONNECTED' : 'NOT CONFIGURED'
    };
    res.json({ success: true, email });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/admin/email/config', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const emailSettings = req.body;
    const settings = await getStoreSettingsRecord();
    const updated = await updateStoreSettingsRecord({ ...settings, emailSettings }, req.adminEmail);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'update_email_config', targetType: 'settings', targetId: 'email', result: 'SUCCESS', details: 'Updated email notification settings' });
    res.json({ success: true, email: updated.emailSettings });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 9. Loyalty & Rewards
app.get('/api/customer/loyalty', requireCustomerAuth, async (req: CustomerAuthRequest, res) => {
  try {
    const loyalty = await getCustomerLoyalty(req.customer!.id);
    res.json({ success: true, loyalty });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.get('/api/admin/loyalty', requireAdminAuth, async (_req, res) => {
  try {
    const transactions = await getAllLoyaltyTransactions();
    res.json({ success: true, transactions });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/admin/loyalty/adjust', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const tx = await addLoyaltyTransaction(req.body);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'adjust_loyalty_points', targetType: 'loyalty', targetId: tx.customerId, result: 'SUCCESS', details: `Adjusted points: ${tx.points}` });
    res.json({ success: true, transaction: tx });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 10. Customer Wallet
app.get('/api/customer/wallet', requireCustomerAuth, async (req: CustomerAuthRequest, res) => {
  try {
    const wallet = await getCustomerWallet(req.customer!.id);
    res.json({ success: true, wallet });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.get('/api/admin/wallet', requireAdminAuth, async (_req, res) => {
  try {
    const transactions = await getAllWalletTransactions();
    res.json({ success: true, transactions });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/admin/wallet/adjust', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const tx = await addWalletTransaction(req.body);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'adjust_wallet_balance', targetType: 'wallet', targetId: tx.customerId, result: 'SUCCESS', details: `Adjusted wallet: ${tx.type} ₹${tx.amount}` });
    res.json({ success: true, transaction: tx });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 11. Promotional Offers
app.get('/api/offers', async (_req, res) => {
  try {
    const offers = await getActiveOffers();
    res.json({ success: true, offers });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.get('/api/admin/offers', requireAdminAuth, async (_req, res) => {
  try {
    const offers = await getAllOffers();
    res.json({ success: true, offers });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/admin/offers', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const offer = await saveOffer(req.body);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'save_offer', targetType: 'offer', targetId: offer.id, result: 'SUCCESS', details: `Saved offer: ${offer.title}` });
    res.json({ success: true, offer });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.delete('/api/admin/offers/:id', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    await deleteOffer(req.params.id);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'delete_offer', targetType: 'offer', targetId: req.params.id, result: 'SUCCESS', details: `Deleted offer ${req.params.id}` });
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 12. Vendors / Multi-Vendor
app.get('/api/admin/vendors', requireAdminAuth, async (_req, res) => {
  try {
    const vendors = await getAllVendors();
    res.json({ success: true, vendors });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.post('/api/admin/vendors', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    const vendor = await saveVendor(req.body);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'save_vendor', targetType: 'vendor', targetId: vendor.id, result: 'SUCCESS', details: `Saved vendor: ${vendor.storeName}` });
    res.json({ success: true, vendor });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

app.delete('/api/admin/vendors/:id', requireAdminAuth, async (req: AdminAuthRequest, res) => {
  try {
    await deleteVendor(req.params.id);
    await addAuditLog({ adminEmail: req.adminEmail || 'admin', adminName: req.admin?.name, action: 'delete_vendor', targetType: 'vendor', targetId: req.params.id, result: 'SUCCESS', details: `Deleted vendor ${req.params.id}` });
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// 13. Advanced Reports & Analytics
app.get('/api/admin/reports/advanced', requireAdminAuth, async (req, res) => {
  try {
    const range = (req.query.range as string) || '30d';
    const report = await getAdvancedReportData(range);
    res.json({ success: true, report });
  } catch (err: any) { res.status(500).json({ success: false, error: err.message }); }
});

// Fallback JSON 404 handler for all unmatched /api/* requests (prevents HTML/empty body leaks)
app.get('/health', async (_req,res)=>{ try { await getStoreSettingsRecord(); res.json({ok:true,service:'INFOSTORS',database:'supabase'}); } catch { res.status(503).json({ok:false,service:'INFOSTORS',database:'unavailable'}); } });

app.all('/api/*', (req, res) => {
  res.status(404).json({
    success: false,
    message: `API endpoint ${req.method} ${req.originalUrl} not found.`,
    error: `API endpoint ${req.method} ${req.originalUrl} not found.`,
  });
});


// ─────────────────────────────────────────────────────────────
// VITE DEV / PRODUCTION STATIC SERVER
// ─────────────────────────────────────────────────────────────
async function startServer() {
  await initDb();
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      root: process.cwd(),
      configFile: path.resolve(process.cwd(), 'vite.config.ts'),
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', async (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`INFOSTORS server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
