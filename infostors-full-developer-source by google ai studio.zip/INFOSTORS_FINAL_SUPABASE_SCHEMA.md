# INFOSTORS — SUPABASE DATABASE SCHEMA SPECIFICATION

**Target Project ID:** `oewerfftzqklptdsdfrm`  
**Database Engine:** PostgreSQL 15+  
**Schema:** `public`  
**Classification:** SOURCE OF TRUTH DATA SPECIFICATION  

---

## 1. TABLE SPECIFICATIONS

### 1. `roles`
Defines operational administrative roles.
- `id` (TEXT, PK): `'main_admin'`, `'admin'`, `'support'`.
- `name` (TEXT, NOT NULL): Display title.
- `description` (TEXT): Description of duties.
- `created_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).

### 2. `permissions`
Defines granular permission capabilities.
- `id` (TEXT, PK): e.g. `'products.read'`, `'products.write'`, `'orders.read'`, `'orders.write'`, etc.
- `name` (TEXT, NOT NULL): Human-readable permission name.
- `module` (TEXT, NOT NULL): Module grouping (`'catalog'`, `'orders'`, `'customers'`, etc.).
- `description` (TEXT): Detailed capability explanation.
- `created_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).

### 3. `role_permissions`
Maps roles to permissions.
- `role_id` (TEXT, PK, FK -> `roles.id` ON DELETE CASCADE).
- `permission_id` (TEXT, PK, FK -> `permissions.id` ON DELETE CASCADE).

### 4. `admin_users`
Authorized administrative staff members.
- `id` (TEXT, PK): `'admin_infostors24_main'` or `'adm_<t36>_<r4>'`.
- `auth_user_id` (UUID, UNIQUE, NULLABLE): References Supabase `auth.users(id)`.
- `email` (TEXT, NOT NULL, UNIQUE): Administrative email.
- `mobile` (TEXT, NOT NULL): Staff contact phone.
- `full_name` (TEXT, NOT NULL): Staff display name.
- `role` (TEXT, NOT NULL, FK -> `roles.id`, DEFAULT `'admin'`).
- `status` (TEXT, NOT NULL, DEFAULT `'active'`, CHECK `IN ('active', 'disabled')`).
- `created_by` (TEXT): Email of authoring administrator.
- `created_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).
- `updated_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).

### 5. `customers`
Customer accounts and profile information.
- `id` (TEXT, PK): Format: `CUS-<10_digit_mobile>` or `cust-<t36>-<r4>`.
- `auth_user_id` (UUID, UNIQUE, NULLABLE): References `auth.users(id)`.
- `full_name` (TEXT, NOT NULL): Customer name.
- `email` (TEXT, NOT NULL, UNIQUE): Contact email.
- `mobile` (TEXT, NOT NULL, UNIQUE, CHECK `~ '^[6-9][0-9]{9}$'`): 10-digit Indian mobile.
- `address`, `city`, `state` (TEXT, NULLABLE).
- `pincode` (TEXT, NULLABLE, CHECK `IS NULL OR ~ '^[0-9]{6}$'`).
- `total_orders` (INTEGER, NOT NULL, DEFAULT 0, CHECK `>= 0`).
- `total_spent` (NUMERIC(12, 2), NOT NULL, DEFAULT 0.00, CHECK `>= 0`).
- `status` (TEXT, NOT NULL, DEFAULT `'active'`, CHECK `IN ('active', 'suspended')`).
- `created_at`, `updated_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).

### 6. `customer_addresses`
Multiple delivery addresses per customer account.
- `id` (UUID, PK, DEFAULT `uuid_generate_v4()`).
- `customer_id` (TEXT, NOT NULL, FK -> `customers.id` ON DELETE CASCADE).
- `full_name` (TEXT, NOT NULL): Recipient name.
- `phone` (TEXT, NOT NULL, CHECK `~ '^[6-9][0-9]{9}$'`).
- `address_line1` (TEXT, NOT NULL): Street, building, house.
- `address_line2` (TEXT, NULLABLE): Landmark, area.
- `city`, `state` (TEXT, NOT NULL).
- `pincode` (TEXT, NOT NULL, CHECK `~ '^[0-9]{6}$'`).
- `is_default` (BOOLEAN, NOT NULL, DEFAULT `false`).
- `created_at`, `updated_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).

### 7. `categories`
Product category taxonomy.
- `id` (TEXT, PK): Slug string (e.g. `'electronics'`, `'audio-sound'`).
- `name` (TEXT, NOT NULL): Display title.
- `emoji` (TEXT, NOT NULL, DEFAULT `'📦'`).
- `description` (TEXT, NOT NULL).
- `icon_name`, `banner_image` (TEXT, NULLABLE).
- `display_order` (INTEGER, NOT NULL, DEFAULT 0).
- `created_at`, `updated_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).

### 8. `products`
Product catalog and warehouse SKU registry.
- `id` (TEXT, PK): SKU code (e.g. `'inf-101'`).
- `name` (TEXT, NOT NULL): Product title.
- `category_id` (TEXT, NOT NULL, FK -> `categories.id` ON DELETE RESTRICT).
- `brand` (TEXT, NOT NULL, DEFAULT `'INFOSTORS'`).
- `price` (NUMERIC(10, 2), NOT NULL, CHECK `>= 0`): Selling price INR.
- `original_price` (NUMERIC(10, 2), NOT NULL, CHECK `>= price`): MRP INR.
- `discount_percentage` (INTEGER, GENERATED ALWAYS AS virtual discount percentage).
- `image_url` (TEXT, NOT NULL): Primary thumbnail URL.
- `gallery_images` (JSONB, NOT NULL, DEFAULT `'[]'::jsonb`): Array of image URLs.
- `short_description`, `description` (TEXT, NOT NULL).
- `features` (JSONB, NOT NULL, DEFAULT `'[]'::jsonb`).
- `stock` (INTEGER, NOT NULL, DEFAULT 0, CHECK `>= 0`).
- `rating` (NUMERIC(3, 2), NOT NULL, DEFAULT 4.80, CHECK `BETWEEN 1.0 AND 5.0`).
- `reviews_count` (INTEGER, NOT NULL, DEFAULT 0, CHECK `>= 0`).
- `is_trending`, `is_bestseller`, `is_new_arrival`, `is_deal` (BOOLEAN, NOT NULL, DEFAULT `false`).
- `badge` (TEXT, NULLABLE): Visual badge.
- `warranty` (TEXT, DEFAULT `'1 Year Brand Replacement Warranty'`).
- `is_active` (BOOLEAN, NOT NULL, DEFAULT `true`).
- `created_at`, `updated_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).

### 9. `inventory_logs`
Immutable stock movement history.
- `id` (UUID, PK, DEFAULT `uuid_generate_v4()`).
- `product_id` (TEXT, NOT NULL, FK -> `products.id` ON DELETE CASCADE).
- `change_amount` (INTEGER, NOT NULL): Delta (-1 for order, +10 for restock).
- `previous_stock`, `new_stock` (INTEGER, NOT NULL, CHECK `>= 0`).
- `reason` (TEXT, NOT NULL, CHECK `IN ('order_placed', 'order_cancelled', 'admin_adjustment', 'restock', 'damage_writeoff')`).
- `order_id` (TEXT, NULLABLE).
- `notes` (TEXT, NULLABLE).
- `created_by` (TEXT, NULLABLE): Email or `'system'`.
- `created_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).

### 10. `orders`
Purchases and fulfillment state.
- `id` (TEXT, PK): Format `INF-YYYYMMDD-XXXX`.
- `customer_id` (TEXT, NULLABLE, FK -> `customers.id` ON DELETE SET NULL).
- `customer_name`, `customer_phone`, `customer_email`, `shipping_address`, `city`, `state`, `pincode` (TEXT, NOT NULL).
- `subtotal`, `discount_amount`, `shipping_fee`, `tax_amount`, `grand_total` (NUMERIC(10, 2), NOT NULL).
- `currency` (TEXT, NOT NULL, DEFAULT `'INR'`).
- `payment_method` (TEXT, NOT NULL, CHECK `IN ('razorpay', 'upi', 'cod')`).
- `payment_status` (TEXT, NOT NULL, DEFAULT `'pending'`, CHECK `IN ('pending', 'authorized', 'paid', 'failed', 'refunded')`).
- `order_status` (TEXT, NOT NULL, DEFAULT `'pending'`, CHECK `IN ('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled')`).
- `package_status` (TEXT, NOT NULL, DEFAULT `'received'`, CHECK `IN ('received', 'dispatched', 'delivered', 'cancelled')`).
- `razorpay_order_id`, `razorpay_payment_id`, `razorpay_signature`, `payment_failure_reason` (TEXT, NULLABLE).
- `courier_partner` (TEXT, DEFAULT `'Delhivery Express'`).
- `tracking_id`, `estimated_delivery_date`, `resolution` (TEXT, NULLABLE).
- `b2b_company_name`, `b2b_gstin` (TEXT, NULLABLE).
- `tax_breakdown` (JSONB, NOT NULL, DEFAULT `'{}'::jsonb`).
- `paid_at` (TIMESTAMPTZ, NULLABLE).
- `created_at`, `updated_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).

### 11. `order_items`
Purchased line items per order.
- `id` (UUID, PK, DEFAULT `uuid_generate_v4()`).
- `order_id` (TEXT, NOT NULL, FK -> `orders.id` ON DELETE CASCADE).
- `product_id` (TEXT, NOT NULL, FK -> `products.id` ON DELETE RESTRICT).
- `product_name` (TEXT, NOT NULL).
- `unit_price`, `total_price` (NUMERIC(10, 2), NOT NULL, CHECK `>= 0`).
- `quantity` (INTEGER, NOT NULL, CHECK `> 0`).
- `image_url` (TEXT, NULLABLE).
- `created_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).

### 12. `order_status_history`
Audit transitions of order statuses.
- `id` (UUID, PK, DEFAULT `uuid_generate_v4()`).
- `order_id` (TEXT, NOT NULL, FK -> `orders.id` ON DELETE CASCADE).
- `previous_status`, `new_status` (TEXT, NOT NULL).
- `changed_by` (TEXT, NOT NULL).
- `notes` (TEXT, NULLABLE).
- `created_at` (TIMESTAMPTZ, NOT NULL, DEFAULT `now()`).

### 13. `store_settings`
Global store branding and tax rules (Single row `id = 'default'`).
- `id` (TEXT, PK, CHECK `id = 'default'`).
- `store_name`, `tagline`, `logo_url`, `helpline`, `email`, `office_address`.
- `standard_delivery_charge` (NUMERIC, DEFAULT 49.00).
- `free_delivery_min` (NUMERIC, DEFAULT 499.00).
- `enable_free_delivery_threshold` (BOOLEAN, DEFAULT true).
- `gst_enabled`, `gstin`, `gst_percentage` (18.00), `gst_type` (`'inclusive'`), `gst_state`.
- `show_gstin_on_invoice`, `allow_customer_b2b_gst` (BOOLEAN).
- `pwa_settings`, `whatsapp_notification_settings`, `shipping_label_settings` (JSONB).

### 14. `payment_settings`
Gateway credentials (Single row `id = 'default'`).
- `mode` (`'test'` or `'live'`).
- `key_id` (TEXT).
- `key_secret_encrypted`, `webhook_secret_encrypted` (AES-256 ciphertext).
- `is_active` (BOOLEAN).

### 15. `delete_requests`
Two-man rule destruction approval workflow.
- `id` (TEXT, PK, format `del_req_<t36>_<r4>`).
- `target_type` (`'order'` or `'customer'`).
- `target_id`, `target_summary`, `requested_by_email`, `requested_by_name`, `requested_by_role`, `reason` (min length 5).
- `status` (`'PENDING'`, `'APPROVED'`, `'REJECTED'`, `'COMPLETED'`, `'FAILED'`).
- `reviewed_by_email`, `reviewed_by_name`, `reviewed_at`, `rejection_reason`, `completed_at`.

### 16. `audit_logs`
Immutable activity ledger (No UPDATE or DELETE).
- `id` (TEXT, PK, format `log_<t36>_<r4>`).
- `admin_email`, `admin_name`, `action`, `target_type`, `target_id`, `reason`, `result`, `details`, `metadata` (JSONB), `timestamp`.

### 17. `customer_messages`
Targeted direct customer communication.
- `id` (TEXT, PK, format `msg_<t36>_<r4>`).
- `customer_id` (FK -> `customers.id`).
- `sender_type` (`'admin'` or `'customer'`), `sender_name`, `subject`, `message`, `message_type`, `is_read`, `created_at`.

### 18. `notifications`
Store-wide and segmented broadcast notices.
- `id` (TEXT, PK, format `notif_<t36>_<r4>`).
- `title`, `body`, `target_audience` (`'all'`, `'segment'`, `'individual'`), `target_customer_id`, `category`, `status`, `sent_by`, `created_at`.
