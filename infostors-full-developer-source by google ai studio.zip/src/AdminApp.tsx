import React from 'react';
import { AdminProductModal } from './components/AdminProductModal';

export const AdminApp: React.FC = () => {
  return <AdminProductModal isStandalone={true} />;
};

export default AdminApp;
