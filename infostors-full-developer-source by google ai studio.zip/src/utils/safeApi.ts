export async function parseApiResponse(res: Response): Promise<{ ok: boolean; data: any; errorMessage: string | null }> {
  try {
    const text = await res.text();
    let data: any = null;
    try {
      data = JSON.parse(text);
    } catch {
      data = { message: text };
    }
    if (!res.ok) {
      const msg = data?.message || data?.error || `Request failed with status ${res.status}`;
      return { ok: false, data, errorMessage: msg };
    }
    return { ok: true, data, errorMessage: null };
  } catch (err: any) {
    return { ok: false, data: null, errorMessage: err.message || 'Network error' };
  }
}
