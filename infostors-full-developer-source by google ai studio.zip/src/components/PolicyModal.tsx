import React from 'react';
import { X, ShieldCheck, Truck, RotateCcw, FileText, Lock } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const PolicyModal: React.FC = () => {
  const { policyModal, setPolicyModal, storeSettings } = useShop();

  if (!policyModal) return null;

  const contentMap: Record<string, { title: string; icon: React.ReactNode; body: React.ReactNode }> = {
    shipping: {
      title: 'Shipping & Delivery Policy',
      icon: <Truck className="w-5 h-5 text-blue-500" />,
      body: (
        <div className="space-y-4 text-sm text-slate-600 dark:text-slate-300">
          <p>
            At {storeSettings.storeName || 'INFOSTORS'}, we partner with premier express courier logistics (Delhivery, BlueDart, XpressBees, DTDC) to deliver your smart gadgets swiftly and securely across India.
          </p>
          <h4 className="font-bold text-slate-900 dark:text-white">Delivery Timeline</h4>
          <ul className="list-disc pl-5 space-y-1">
            <li>Metro Cities: 2 - 4 business days</li>
            <li>Rest of India: 3 - 6 business days</li>
            <li>Dispatch SLA: Same-day dispatch for orders placed before 2:00 PM IST</li>
          </ul>
          <h4 className="font-bold text-slate-900 dark:text-white">Shipping Rates</h4>
          <p>
            Orders over ₹{storeSettings.freeDeliveryMin || 499} qualify for <strong>FREE Express Delivery</strong>. Standard delivery fee of ₹{storeSettings.standardDeliveryCharge || 49} applies to smaller orders.
          </p>
        </div>
      ),
    },
    returns: {
      title: '7-Day Return & Replacement Policy',
      icon: <RotateCcw className="w-5 h-5 text-emerald-500" />,
      body: (
        <div className="space-y-4 text-sm text-slate-600 dark:text-slate-300">
          <p>
            We offer an unconditional 7-day doorstep replacement or refund guarantee on all defective, damaged, or mismatched items.
          </p>
          <h4 className="font-bold text-slate-900 dark:text-white">How It Works</h4>
          <ol className="list-decimal pl-5 space-y-1">
            <li>Open the Account modal or contact our helpline via WhatsApp within 7 days of delivery.</li>
            <li>Our logistics partner arranges free pickup from your address within 24–48 hours.</li>
            <li>Upon warehouse intake check, immediate replacement or full refund is initiated to your original payment method.</li>
          </ol>
        </div>
      ),
    },
    warranty: {
      title: 'Warranty & Genuine Guarantee',
      icon: <ShieldCheck className="w-5 h-5 text-indigo-500" />,
      body: (
        <div className="space-y-4 text-sm text-slate-600 dark:text-slate-300">
          <p>
            Every product sold on {storeSettings.storeName || 'INFOSTORS'} carries a minimum 1-Year Manufacturer Replacement Warranty.
          </p>
          <h4 className="font-bold text-slate-900 dark:text-white">Warranty Coverage</h4>
          <ul className="list-disc pl-5 space-y-1">
            <li>Covers internal electrical and electronic failure</li>
            <li>Battery degradation beyond normal thresholds within warranty</li>
            <li>Free parts and unit replacement via authorized centers</li>
          </ul>
        </div>
      ),
    },
    terms: {
      title: 'Terms of Service',
      icon: <FileText className="w-5 h-5 text-blue-500" />,
      body: (
        <div className="space-y-4 text-sm text-slate-600 dark:text-slate-300">
          <p>
            Welcome to {storeSettings.storeName || 'INFOSTORS'}. By using our marketplace, website, or progressive web app, you agree to these terms governed under the laws of the Republic of India.
          </p>
          <h4 className="font-bold text-slate-900 dark:text-white">Pricing & GST</h4>
          <p>
            All listed prices include applicable GST ({storeSettings.gstPercentage || 18}% IGST/CGST/SGST) unless specified otherwise. Tax invoices with GST compliance are generated automatically.
          </p>
        </div>
      ),
    },
    privacy: {
      title: 'Privacy Policy',
      icon: <Lock className="w-5 h-5 text-amber-500" />,
      body: (
        <div className="space-y-4 text-sm text-slate-600 dark:text-slate-300">
          <p>
            We respect your privacy. Customer mobile numbers, shipping addresses, and transaction tokens are encrypted using AES-256-GCM. We never share or sell customer data to third-party advertisers.
          </p>
        </div>
      ),
    },
  };

  const item = contentMap[policyModal] || contentMap.shipping;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800">
              {item.icon}
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">{item.title}</h3>
          </div>
          <button
            onClick={() => setPolicyModal(null)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 max-h-[70vh] overflow-y-auto">
          {item.body}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            onClick={() => setPolicyModal(null)}
            className="px-5 py-2 rounded-xl font-bold text-sm bg-blue-600 hover:bg-blue-500 text-white shadow-md transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
