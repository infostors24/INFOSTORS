import React from 'react';

interface InfostorsLogoProps {
  className?: string;
}

export const InfostorsLogo: React.FC<InfostorsLogoProps> = ({ className = 'h-10 w-auto' }) => {
  return (
    <div className={`flex items-center gap-2 select-none ${className}`}>
      <div className="relative flex items-center justify-center h-10 w-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 text-white shadow-md shadow-blue-500/25 shrink-0">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" fill="currentColor" fillOpacity="0.2" />
        </svg>
        <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500"></span>
        </span>
      </div>
      <div className="flex flex-col text-left leading-none">
        <span className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white uppercase font-sans">
          INFO<span className="text-blue-600 dark:text-blue-400">STORS</span>
        </span>
        <span className="text-[9px] font-bold tracking-widest text-slate-500 dark:text-slate-400 uppercase">
          Smart Gadgets
        </span>
      </div>
    </div>
  );
};
