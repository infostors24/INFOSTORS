import React, { useRef } from 'react';
import { X, Printer, Package, Truck, MapPin, Building, ShieldCheck } from 'lucide-react';
import { Order, StoreSettings } from '../types';

interface ShippingLabelModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order;
  storeSettings: StoreSettings;
  onOrderUpdated?: (orderId: string, updates: any) => void;
}

export const ShippingLabelModal: React.FC<ShippingLabelModalProps> = ({
  isOpen,
  onClose,
  order,
  storeSettings,
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Modal Controls */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Standard 4×6 Thermal Shipping Label</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Label</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 4x6 Thermal Label Preview */}
        <div className="p-6 bg-slate-100 dark:bg-slate-950 flex justify-center">
          <div 
            ref={printRef}
            className="w-[380px] bg-white text-black p-4 border-2 border-black rounded shadow-md font-sans text-xs space-y-3"
          >
            {/* Header / Brand */}
            <div className="flex items-center justify-between border-b-2 border-black pb-2">
              <div>
                <h2 className="text-lg font-black tracking-tight uppercase">{storeSettings.storeName || 'INFOSTORS'}</h2>
                <p className="text-[10px] text-gray-700">Prepaid Express Parcel</p>
              </div>
              <div className="text-right">
                <span className="inline-block px-2 py-0.5 border border-black font-black text-xs uppercase">
                  {order.paymentMethod === 'cod' ? 'C.O.D.' : 'PREPAID'}
                </span>
                <p className="text-[10px] font-bold mt-0.5">₹{order.totalAmount?.toLocaleString('en-IN')}</p>
              </div>
            </div>

            {/* Courier & Tracking */}
            <div className="border-b border-black pb-2 flex justify-between items-center text-[11px]">
              <div>
                <p className="text-gray-600 text-[9px] uppercase">Courier Partner</p>
                <p className="font-bold">{order.courierPartner || 'Delhivery Express'}</p>
              </div>
              <div className="text-right">
                <p className="text-gray-600 text-[9px] uppercase">Tracking AWB</p>
                <p className="font-mono font-bold">{order.trackingId || 'INF-' + order.id.slice(-8)}</p>
              </div>
            </div>

            {/* Deliver To */}
            <div className="border-b-2 border-black pb-2">
              <p className="text-[9px] font-bold text-gray-500 uppercase">Deliver To (Shipping Address):</p>
              <p className="text-sm font-black">{order.shippingAddress?.fullName || order.customerName}</p>
              <p className="leading-tight mt-0.5">{order.shippingAddress?.address}</p>
              <p className="font-bold mt-0.5">
                {order.shippingAddress?.city}, {order.shippingAddress?.state} - <span className="text-sm font-black">{order.shippingAddress?.pincode}</span>
              </p>
              <p className="mt-1 font-mono font-bold">Phone: {order.shippingAddress?.mobile || order.customerMobile}</p>
            </div>

            {/* Package Contents */}
            <div className="border-b border-black pb-2">
              <p className="text-[9px] font-bold text-gray-500 uppercase">Contents ({order.items?.length || 0} items):</p>
              <ul className="text-[10px] space-y-0.5 mt-0.5">
                {order.items?.map((item, idx) => (
                  <li key={idx} className="truncate">
                    {item.quantity}× {item.product?.name}
                  </li>
                ))}
              </ul>
            </div>

            {/* Return Address / Shipper */}
            <div className="text-[9px] text-gray-600 pt-1">
              <p className="font-bold text-black uppercase">If Undelivered, Return To:</p>
              <p>{storeSettings.tradeName || storeSettings.storeName || 'INFOSTORS Logistics'}</p>
              <p>{storeSettings.officeAddress || 'INFOSTORS HQ, Garia station road, Kolkata 700084, India'}</p>
              <p>Helpline: {storeSettings.helpline || '+91 94778 39200'}</p>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
