import React, { useState } from 'react';
import { Palette, Layout, Sliders, Check, Sun, Moon, Monitor, SlidersHorizontal, Sparkles } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { FeatureFlags, ThemeSettings, LayoutSettings, ThemeMode } from '../../types';

export const AdminThemeLayoutTab: React.FC = () => {
  const {
    featureFlags,
    updateFeatureFlags,
    themeSettings,
    updateThemeSettings,
    layoutSettings,
    updateLayoutSettings,
    themeMode,
    setThemeMode,
  } = useShop();

  const [activeSubTab, setActiveSubTab] = useState<'features' | 'theme' | 'layout'>('features');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Local draft states
  const [localFlags, setLocalFlags] = useState<FeatureFlags>({ ...featureFlags });
  const [localTheme, setLocalTheme] = useState<ThemeSettings>({ ...themeSettings });
  const [localLayout, setLocalLayout] = useState<LayoutSettings>({ ...layoutSettings });

  const handleToggleFlag = (key: keyof FeatureFlags) => {
    setLocalFlags(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSaveFlags = async () => {
    await updateFeatureFlags(localFlags);
    setStatusMessage('Feature flags updated. Changes applied to store immediately.');
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleSaveTheme = async () => {
    setThemeMode(localTheme.mode);
    await updateThemeSettings(localTheme);
    setStatusMessage('Store theme appearance updated and applied live.');
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleSaveLayout = async () => {
    await updateLayoutSettings(localLayout);
    setStatusMessage('Layout preferences saved.');
    setTimeout(() => setStatusMessage(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white">
        <div>
          <div className="flex items-center gap-2">
            <Palette className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-black tracking-tight">Theme, Layout & Feature Controls</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Toggle e-commerce modules ON/OFF, customize the color palette, dark mode, typography scale, and layout density.
          </p>
        </div>

        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => setActiveSubTab('features')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'features' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Feature Toggles</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveSubTab('theme')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'theme' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Theme & Colors</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveSubTab('layout')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'layout' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layout className="w-3.5 h-3.5" />
            <span>Layout & Sections</span>
          </button>
        </div>
      </div>

      {statusMessage && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* 1. FEATURE ON/OFF TOGGLES */}
      {activeSubTab === 'features' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white space-y-5">
          <div>
            <h3 className="font-bold text-sm text-white">Master E-commerce Module Toggles</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Enable or disable specific store features without touching code. Disabled features are cleanly removed from both customer views and checkout.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {[
              { key: 'coupons', label: 'Coupons & Discount Codes', desc: 'Promo code input in cart & checkout' },
              { key: 'flashSale', label: 'Flash Sale Urgent Drops', desc: 'Countdown banner & urgency rail on homepage' },
              { key: 'reviews', label: 'Reviews & Star Ratings', desc: 'Customer review submission & verified reviews' },
              { key: 'returns', label: 'Customer Order Returns', desc: 'Return request flow in customer accounts' },
              { key: 'refunds', label: 'Instant Refunds', desc: 'Store wallet or source payment refunds' },
              { key: 'deliveryApi', label: 'Courier API Integration', desc: 'Delhivery / Shiprocket automated dispatch' },
              { key: 'whatsappApi', label: 'WhatsApp Alerts', desc: 'Automated order status notifications' },
              { key: 'emailNotifications', label: 'Email Notifications', desc: 'Invoices, dispatch, and password resets' },
              { key: 'loyalty', label: 'Loyalty & Reward Points', desc: 'Earn points on orders, redeemable at checkout' },
              { key: 'wallet', label: 'Store Customer Wallet', desc: 'Store credits & wallet payments' },
              { key: 'offers', label: 'Promotional Offer Banners', desc: 'Homepage offer cards and copyable codes' },
              { key: 'multiVendor', label: 'Multi-Vendor Marketplace', desc: 'Onboard external vendors with commission' },
              { key: 'advancedReports', label: 'Advanced Analytics', desc: 'Detailed sales & tax reports' },
            ].map(({ key, label, desc }) => {
              const isEnabled = localFlags[key as keyof FeatureFlags];

              return (
                <div
                  key={key}
                  onClick={() => handleToggleFlag(key as keyof FeatureFlags)}
                  className={`p-3.5 rounded-xl border text-xs flex items-start justify-between gap-3 cursor-pointer transition select-none ${
                    isEnabled
                      ? 'bg-blue-600/10 border-blue-500/40 text-white'
                      : 'bg-slate-800/40 border-slate-700/60 text-slate-400 opacity-60'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="font-bold text-slate-100">{label}</div>
                    <div className="text-[11px] text-slate-400">{desc}</div>
                  </div>

                  <div className={`w-9 h-5 rounded-full p-0.5 transition-colors shrink-0 ${isEnabled ? 'bg-blue-600' : 'bg-slate-700'}`}>
                    <div className={`w-4 h-4 rounded-full bg-white transition-transform ${isEnabled ? 'translate-x-4' : 'translate-x-0'}`} />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex justify-end pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={handleSaveFlags}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
            >
              Save Feature Toggles
            </button>
          </div>
        </div>
      )}

      {/* 2. THEME & COLORS */}
      {activeSubTab === 'theme' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white space-y-5">
          <div>
            <h3 className="font-bold text-sm text-white">Brand Palette & Styling</h3>
            <p className="text-xs text-slate-400 mt-0.5">Customize your brand appearance and theme style.</p>
          </div>

          {/* Theme Mode Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-300">Theme Mode</label>
            <div className="flex items-center gap-2 max-w-sm">
              {[
                { id: 'light', label: 'Light', icon: Sun },
                { id: 'dark', label: 'Dark', icon: Moon },
                { id: 'system', label: 'System Auto', icon: Monitor },
              ].map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setLocalTheme({ ...localTheme, mode: id as ThemeMode })}
                  className={`flex-1 py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                    localTheme.mode === id
                      ? 'bg-blue-600 border-blue-500 text-white shadow-xs'
                      : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Color Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Primary Brand Color</label>
              <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 p-1.5 rounded-xl">
                <input
                  type="color"
                  value={localTheme.primaryColor}
                  onChange={e => setLocalTheme({ ...localTheme, primaryColor: e.target.value })}
                  className="w-7 h-7 rounded-lg border-0 cursor-pointer bg-transparent"
                />
                <input
                  type="text"
                  value={localTheme.primaryColor}
                  onChange={e => setLocalTheme({ ...localTheme, primaryColor: e.target.value })}
                  className="bg-transparent text-xs font-mono font-bold text-white w-full outline-none uppercase"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Secondary Color</label>
              <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 p-1.5 rounded-xl">
                <input
                  type="color"
                  value={localTheme.secondaryColor}
                  onChange={e => setLocalTheme({ ...localTheme, secondaryColor: e.target.value })}
                  className="w-7 h-7 rounded-lg border-0 cursor-pointer bg-transparent"
                />
                <input
                  type="text"
                  value={localTheme.secondaryColor}
                  onChange={e => setLocalTheme({ ...localTheme, secondaryColor: e.target.value })}
                  className="bg-transparent text-xs font-mono font-bold text-white w-full outline-none uppercase"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Accent Glow Color</label>
              <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 p-1.5 rounded-xl">
                <input
                  type="color"
                  value={localTheme.accentColor}
                  onChange={e => setLocalTheme({ ...localTheme, accentColor: e.target.value })}
                  className="w-7 h-7 rounded-lg border-0 cursor-pointer bg-transparent"
                />
                <input
                  type="text"
                  value={localTheme.accentColor}
                  onChange={e => setLocalTheme({ ...localTheme, accentColor: e.target.value })}
                  className="bg-transparent text-xs font-mono font-bold text-white w-full outline-none uppercase"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Button CTA Color</label>
              <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 p-1.5 rounded-xl">
                <input
                  type="color"
                  value={localTheme.buttonColor}
                  onChange={e => setLocalTheme({ ...localTheme, buttonColor: e.target.value })}
                  className="w-7 h-7 rounded-lg border-0 cursor-pointer bg-transparent"
                />
                <input
                  type="text"
                  value={localTheme.buttonColor}
                  onChange={e => setLocalTheme({ ...localTheme, buttonColor: e.target.value })}
                  className="bg-transparent text-xs font-mono font-bold text-white w-full outline-none uppercase"
                />
              </div>
            </div>
          </div>

          {/* Typography Scale & Card Corner Radius */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Typography Scale</label>
              <select
                value={localTheme.typographyScale}
                onChange={e => setLocalTheme({ ...localTheme, typographyScale: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-semibold text-white"
              >
                <option value="compact">Compact (High density)</option>
                <option value="normal">Normal (Balanced)</option>
                <option value="large">Large (High legibility)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Border Radius</label>
              <select
                value={localTheme.borderRadius}
                onChange={e => setLocalTheme({ ...localTheme, borderRadius: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-semibold text-white"
              >
                <option value="none">Square (0px)</option>
                <option value="sm">Subtle (4px)</option>
                <option value="md">Medium (8px)</option>
                <option value="lg">Rounded (12px)</option>
                <option value="xl">Pill / Modern (16px)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Card Shadow & Border</label>
              <select
                value={localTheme.cardStyle}
                onChange={e => setLocalTheme({ ...localTheme, cardStyle: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-semibold text-white"
              >
                <option value="bordered">Bordered (Clean crisp)</option>
                <option value="elevated">Elevated (Deep shadow)</option>
                <option value="minimal">Minimal</option>
                <option value="flat">Flat</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={handleSaveTheme}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
            >
              Apply Theme Live
            </button>
          </div>
        </div>
      )}

      {/* 3. LAYOUT & SECTIONS */}
      {activeSubTab === 'layout' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white space-y-5">
          <div>
            <h3 className="font-bold text-sm text-white">Homepage Layout & Section Ordering</h3>
            <p className="text-xs text-slate-400 mt-0.5">Control product grid density and toggle homepage sections.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Product Grid Density</label>
              <select
                value={localLayout.customer.productGridDensity}
                onChange={e => setLocalLayout({
                  ...localLayout,
                  customer: { ...localLayout.customer, productGridDensity: e.target.value as any }
                })}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-semibold text-white"
              >
                <option value="compact">Compact (2 columns on mobile, high density)</option>
                <option value="comfortable">Comfortable (Standard)</option>
                <option value="dense">Dense (Catalog power-shopper)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Header Style</label>
              <select
                value={localLayout.customer.headerDensity}
                onChange={e => setLocalLayout({
                  ...localLayout,
                  customer: { ...localLayout.customer, headerDensity: e.target.value as any }
                })}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-semibold text-white"
              >
                <option value="compact">Compact Sticky Header</option>
                <option value="normal">Standard Header</option>
              </select>
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-800">
            <label className="block text-xs font-bold text-slate-300">Section Visibility on Customer Homepage</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { key: 'showHeroBanner', label: 'Top Hero Promotional Banner' },
                { key: 'showFlashSaleSection', label: 'Flash Sale Urgency Rail' },
                { key: 'showOffersSection', label: 'Promotional Offers & Coupon Rail' },
                { key: 'showTrendingSection', label: 'Trending Products Rail' },
                { key: 'showBestsellerSection', label: 'Best Sellers Rail' },
                { key: 'showDealsSection', label: 'Discount Deals Section' },
              ].map(({ key, label }) => {
                const isChecked = (localLayout.customer as any)[key] !== false;

                return (
                  <label key={key} className="flex items-center gap-2 p-2.5 bg-slate-800/40 border border-slate-800 rounded-xl text-xs font-semibold text-slate-300 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={e => setLocalLayout({
                        ...localLayout,
                        customer: { ...localLayout.customer, [key]: e.target.checked }
                      })}
                      className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                    />
                    <span>{label}</span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={handleSaveLayout}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
            >
              Save Layout Settings
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
