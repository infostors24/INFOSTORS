import React, { useState } from 'react';
import { Smartphone, Check, Save, Download } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const AdminPwaSettingsTab: React.FC = () => {
  const { storeSettings, updateStoreSettings } = useShop();

  const [appName, setAppName] = useState(storeSettings.pwaSettings?.appName || 'INFOSTORS - Smart Gadgets');
  const [shortName, setShortName] = useState(storeSettings.pwaSettings?.appShortName || 'INFOSTORS');
  const [themeColor, setThemeColor] = useState(storeSettings.pwaSettings?.themeColor || '#020617');
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    if (updateStoreSettings) {
      updateStoreSettings({
        ...storeSettings,
        pwaSettings: {
          ...storeSettings.pwaSettings,
          appName,
          appShortName: shortName,
          themeColor,
          appIconUrl: storeSettings.pwaSettings?.appIconUrl || '/logo.svg',
          appDescription: storeSettings.pwaSettings?.appDescription || 'INFOSTORS App',
          installButtonText: storeSettings.pwaSettings?.installButtonText || 'Install App',
          installBannerText: storeSettings.pwaSettings?.installBannerText || 'Install app for faster checkout',
          bannerEnabled: storeSettings.pwaSettings?.bannerEnabled !== false,
          backgroundColor: storeSettings.pwaSettings?.backgroundColor || '#020617',
        },
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Progressive Web App (PWA) Settings</h3>
          <p className="text-xs text-slate-500">Configure mobile app install prompt, launcher branding & manifest</p>
        </div>
        <button
          onClick={handleSave}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-colors"
        >
          {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{saved ? 'Saved' : 'Save PWA Config'}</span>
        </button>
      </div>

      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Full Application Name
            </label>
            <input
              type="text"
              value={appName}
              onChange={e => setAppName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Mobile Launcher Short Name (max 12 chars)
            </label>
            <input
              type="text"
              maxLength={12}
              value={shortName}
              onChange={e => setShortName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold focus:outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Browser Theme Color
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={themeColor}
                onChange={e => setThemeColor(e.target.value)}
                className="w-8 h-8 rounded-lg cursor-pointer border-0"
              />
              <span className="font-mono text-xs">{themeColor}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
