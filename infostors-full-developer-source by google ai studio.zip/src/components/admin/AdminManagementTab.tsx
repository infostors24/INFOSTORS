import React, { useState } from 'react';
import { Users, Shield, Plus, Check, Trash2, Key, UserCheck } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

export const AdminManagementTab: React.FC = () => {
  const { adminProfile } = useShop();

  const [admins] = useState([
    {
      id: 'admin_infostors24_main',
      email: 'infostors24@gmail.com',
      mobile: '8695222581',
      fullName: 'INFOSTORS Main Administrator',
      role: 'main_admin',
      status: 'active',
    },
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-base font-bold text-slate-900 dark:text-white">Admin Team & Security Privileges</h3>
        <p className="text-xs text-slate-500">Role-based access control (RBAC) and team members</p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">System Administrators</h4>
          </div>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
          {admins.map(adm => (
            <div key={adm.id} className="py-3.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-sm">
                  {adm.fullName.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-sm text-slate-900 dark:text-white">{adm.fullName}</p>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 uppercase">
                      {adm.role.replace('_', ' ')}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">{adm.email} • {adm.mobile}</p>
                </div>
              </div>
              <span className="inline-flex items-center gap-1 text-xs text-emerald-600 font-semibold">
                <UserCheck className="w-3.5 h-3.5" /> Active
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
