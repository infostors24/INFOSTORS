import React, { useState } from 'react';
import { Tag, Plus, Trash2, Check, X, Sparkles, Calendar, AlertCircle } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { PromotionalOffer } from '../../types';

export const AdminOffersTab: React.FC = () => {
  const { offers, saveOffer, deleteOffer } = useShop();

  const [isCreating, setIsCreating] = useState(false);
  const [editingOffer, setEditingOffer] = useState<PromotionalOffer | null>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [code, setCode] = useState('');
  const [discountText, setDiscountText] = useState('₹200 Instant Off');
  const [badge, setBadge] = useState('SPECIAL DEAL');
  const [validTill, setValidTill] = useState(new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10));
  const [isActive, setIsActive] = useState(true);

  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleOpenCreate = () => {
    setEditingOffer(null);
    setTitle('Weekend Festive Bonanza');
    setDescription('Apply code on any gadget order above ₹999 to unlock instant discount.');
    setCode('FESTIVE200');
    setDiscountText('₹200 Instant Off');
    setBadge('SPECIAL DEAL');
    setValidTill(new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10));
    setIsActive(true);
    setIsCreating(true);
  };

  const handleOpenEdit = (o: PromotionalOffer) => {
    setEditingOffer(o);
    setTitle(o.title);
    setDescription(o.description);
    setCode(o.code || '');
    setDiscountText(o.discountText);
    setBadge(o.badge || 'PROMO');
    setValidTill(o.validTill.slice(0, 10));
    setIsActive(o.isActive);
    setIsCreating(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const payload: Partial<PromotionalOffer> = {
      title: title.trim(),
      description: description.trim(),
      code: code ? code.toUpperCase().trim() : undefined,
      discountText: discountText.trim(),
      badge: badge.trim(),
      validTill: new Date(validTill).toISOString(),
      isActive,
    };
    if (editingOffer) payload.id = editingOffer.id;

    const res = await saveOffer(payload);
    if (res.success) {
      setStatusMessage(editingOffer ? 'Offer updated.' : 'Offer campaign created.');
      setIsCreating(false);
      setEditingOffer(null);
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!window.confirm(`Delete offer "${name}"?`)) return;
    const res = await deleteOffer(id);
    if (res.success) {
      setStatusMessage('Offer campaign deleted.');
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white">
        <div>
          <div className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-black tracking-tight">Promotional Offers & Campaign Banners</h2>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-full font-bold">
              {offers.length} Campaigns
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Display eye-catching promotional cards and banners with copyable codes on the customer homepage.
          </p>
        </div>

        <button
          type="button"
          onClick={handleOpenCreate}
          className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Offer Banner</span>
        </button>
      </div>

      {statusMessage && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Editor Modal */}
      {isCreating && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white space-y-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="font-bold text-sm text-white">
              {editingOffer ? 'Edit Promotional Campaign' : 'Create Promotional Campaign'}
            </h3>
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="text-slate-400 hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Campaign Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Headline Discount Text *</label>
                <input
                  type="text"
                  required
                  value={discountText}
                  onChange={e => setDiscountText(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-amber-400 focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Coupon Code (Optional)</label>
                <input
                  type="text"
                  value={code}
                  onChange={e => setCode(e.target.value.toUpperCase())}
                  placeholder="e.g. EXTRA10"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-mono font-bold text-white uppercase focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Badge Tag</label>
                <input
                  type="text"
                  value={badge}
                  onChange={e => setBadge(e.target.value)}
                  placeholder="e.g. FLASH DEAL"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Valid Till Date</label>
                <input
                  type="date"
                  required
                  value={validTill}
                  onChange={e => setValidTill(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-6">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={e => setIsActive(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
                  />
                  <span>Active & Visible to Shoppers</span>
                </label>
              </div>

              <div className="col-span-full">
                <label className="block text-xs font-semibold text-slate-300 mb-1">Description / Subtitle</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:border-amber-500 outline-none resize-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold rounded-xl shadow-md"
              >
                {editingOffer ? 'Update Campaign' : 'Save Offer'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Offers Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {offers.map(o => (
          <div
            key={o.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white flex flex-col justify-between space-y-3"
          >
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded font-extrabold">
                  {o.badge}
                </span>
                <span className="text-[10px] text-slate-400">
                  Till {new Date(o.validTill).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                </span>
              </div>

              <h3 className="font-bold text-sm text-white line-clamp-1">{o.title}</h3>
              <p className="text-xs text-slate-400 line-clamp-2">{o.description}</p>
              <div className="text-base font-black text-amber-400">{o.discountText}</div>

              {o.code && (
                <div className="pt-1">
                  <span className="font-mono font-bold text-xs bg-black/40 text-blue-300 border border-dashed border-blue-400/40 px-2 py-0.5 rounded">
                    {o.code}
                  </span>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => handleOpenEdit(o)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs rounded-xl transition"
              >
                Edit
              </button>
              <button
                type="button"
                onClick={() => handleDelete(o.id, o.title)}
                className="px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-semibold text-xs rounded-xl transition"
              >
                Delete
              </button>
            </div>
          </div>
        ))}

        {offers.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-500 bg-slate-900/50 border border-slate-800 rounded-2xl">
            No promotional offer cards created yet.
          </div>
        )}
      </div>
    </div>
  );
};
