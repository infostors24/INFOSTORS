import React, { useState } from 'react';
import { BarChart3, Download, TrendingUp, Calendar, FileText, CheckCircle2 } from 'lucide-react';
import { Order, Product, StoreSettings } from '../../types';

interface AdminReportsTabProps {
  orders: Order[];
  products: Product[];
  storeSettings: StoreSettings;
}

export const AdminReportsTab: React.FC<AdminReportsTabProps> = ({
  orders,
  products,
  storeSettings,
}) => {
  const [timeRange, setTimeRange] = useState('30d');

  const totalRevenue = orders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
  const deliveredOrders = orders.filter(o => o.status === 'delivered');
  const avgOrderValue = orders.length > 0 ? Math.round(totalRevenue / orders.length) : 0;
  const gstCollected = Math.round(totalRevenue * (storeSettings.gstPercentage || 18) / 118);

  const handleExportCSV = () => {
    const headers = ['Order ID', 'Date', 'Customer Name', 'Mobile', 'Amount (INR)', 'Status', 'Payment Method'];
    const rows = orders.map(o => [
      o.id,
      new Date(o.createdAt).toLocaleDateString(),
      `"${o.shippingAddress?.fullName || o.customerName || ''}"`,
      o.customerMobile || '',
      o.totalAmount,
      o.status,
      o.paymentMethod,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `infostors_sales_report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Financial Reports & GST Sales Audit</h3>
          <p className="text-xs text-slate-500">Business performance metrics and compliance summaries</p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={timeRange}
            onChange={e => setTimeRange(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold focus:outline-none"
          >
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last Quarter</option>
            <option value="all">All Time</option>
          </select>
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-400 font-bold uppercase">Total Turnover</span>
          <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">₹{totalRevenue.toLocaleString('en-IN')}</p>
          <p className="text-[11px] text-emerald-600 font-semibold mt-1">Gross sales including taxes</p>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-400 font-bold uppercase">Average Order Value</span>
          <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">₹{avgOrderValue.toLocaleString('en-IN')}</p>
          <p className="text-[11px] text-blue-500 font-semibold mt-1">AOV per transaction</p>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-400 font-bold uppercase">Estimated GST ({storeSettings.gstPercentage || 18}%)</span>
          <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">₹{gstCollected.toLocaleString('en-IN')}</p>
          <p className="text-[11px] text-purple-500 font-semibold mt-1">GSTIN: {storeSettings.gstin || '19AAACI1234F1Z8'}</p>
        </div>
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-400 font-bold uppercase">Delivery Success</span>
          <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">
            {orders.length > 0 ? Math.round((deliveredOrders.length / orders.length) * 100) : 100}%
          </p>
          <p className="text-[11px] text-emerald-600 font-semibold mt-1">{deliveredOrders.length} orders delivered</p>
        </div>
      </div>
    </div>
  );
};
