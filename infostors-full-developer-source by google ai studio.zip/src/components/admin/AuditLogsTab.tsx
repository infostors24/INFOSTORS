import React, { useState, useEffect } from 'react';
import { ShieldCheck, Clock, FileText, Search, User, Filter } from 'lucide-react';

interface AuditLogsTabProps {
  adminProfile?: any;
  adminToken?: string | null;
}

export const AuditLogsTab: React.FC<AuditLogsTabProps> = ({
  adminProfile,
}) => {
  const [logs] = useState([
    {
      id: 'log-1',
      action: 'ADMIN_LOGIN',
      adminEmail: adminProfile?.email || 'infostors24@gmail.com',
      details: 'Successful administrator authentication',
      timestamp: new Date().toISOString(),
    },
    {
      id: 'log-2',
      action: 'CATALOG_SYNC',
      adminEmail: 'system@infostors.com',
      details: 'Catalog & products database initialized',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
    },
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-base font-bold text-slate-900 dark:text-white">Immutable Security Audit Logs</h3>
        <p className="text-xs text-slate-500">Append-only audit trail of administrator activities and critical events</p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
        <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
          {logs.map(log => (
            <div key={log.id} className="py-3 flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-slate-900 dark:text-white">{log.action}</span>
                    <span className="text-[10px] text-slate-400">• {new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-slate-500 mt-0.5">{log.details}</p>
                </div>
              </div>
              <span className="text-slate-400 font-mono text-[11px]">{log.adminEmail}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
