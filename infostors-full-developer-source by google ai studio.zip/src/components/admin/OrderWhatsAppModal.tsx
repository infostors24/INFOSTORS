import React, { useState } from 'react';
import { X, MessageCircle, Send, Copy, Check } from 'lucide-react';
import { Order, StoreSettings } from '../../types';

interface OrderWhatsAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order;
  storeSettings: StoreSettings;
}

export const OrderWhatsAppModal: React.FC<OrderWhatsAppModalProps> = ({
  isOpen,
  onClose,
  order,
  storeSettings,
}) => {
  const customerName = order.shippingAddress?.fullName || order.customerName || 'Customer';
  const defaultText = `Hi ${customerName}, thank you for your order #${order.id} with ${storeSettings.storeName || 'INFOSTORS'}! Total: ₹${order.totalAmount}. Current status: ${order.status?.toUpperCase()}.`;
  
  const [message, setMessage] = useState(defaultText);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleSend = () => {
    const phone = (order.shippingAddress?.mobile || order.customerMobile || '').replace(/[^0-9]/g, '');
    const cleanPhone = phone.startsWith('91') ? phone : `91${phone}`;
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`, '_blank');
    onClose();
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(message);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-600">
              <MessageCircle className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Send WhatsApp Update</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-3">
          <div className="text-xs text-slate-500">
            Sending to: <strong className="text-slate-900 dark:text-white">{customerName}</strong> ({order.shippingAddress?.mobile || order.customerMobile})
          </div>
          <textarea
            rows={4}
            value={message}
            onChange={e => setMessage(e.target.value)}
            className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
          <button
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Text'}</span>
          </button>
          <button
            onClick={handleSend}
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Open WhatsApp Chat</span>
          </button>
        </div>
      </div>
    </div>
  );
};
