import React, { useRef } from 'react';
import { X, Printer, Download, FileText, CheckCircle2 } from 'lucide-react';
import { Order, StoreSettings } from '../../types';

interface AdminInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order;
  storeSettings: StoreSettings;
}

export const AdminInvoiceModal: React.FC<AdminInvoiceModalProps> = ({
  isOpen,
  onClose,
  order,
  storeSettings,
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const gstRate = storeSettings.gstPercentage || 18;
  const taxableAmount = Math.round(order.totalAmount / (1 + gstRate / 100));
  const gstAmount = order.totalAmount - taxableAmount;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Tax Invoice #{order.id}</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Invoice</span>
            </button>
            <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Invoice Body */}
        <div ref={printRef} className="p-6 bg-white text-slate-900 font-sans text-xs space-y-5">
          {/* Header */}
          <div className="flex justify-between items-start border-b pb-4">
            <div>
              <h2 className="text-xl font-black tracking-tight">{storeSettings.storeName || 'INFOSTORS'}</h2>
              <p className="text-gray-500 text-[11px]">{storeSettings.tagline || 'Smart Gadgets | Better Life'}</p>
              <p className="text-gray-600 mt-1">{storeSettings.officeAddress}</p>
              <p className="text-gray-600 font-bold">GSTIN: {storeSettings.gstin || '19AAACI1234F1Z8'}</p>
            </div>
            <div className="text-right">
              <span className="inline-block px-2.5 py-1 bg-blue-100 text-blue-800 font-bold rounded uppercase">
                Tax Invoice
              </span>
              <p className="font-mono font-bold text-sm mt-1">#{order.id}</p>
              <p className="text-gray-500 text-[11px]">Date: {new Date(order.createdAt).toLocaleDateString()}</p>
            </div>
          </div>

          {/* Billed To */}
          <div className="grid grid-cols-2 gap-4 border-b pb-4">
            <div>
              <p className="font-bold text-gray-500 uppercase text-[10px]">Billed & Shipped To:</p>
              <p className="font-bold text-sm mt-0.5">{order.shippingAddress?.fullName || order.customerName}</p>
              <p>{order.shippingAddress?.address}</p>
              <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} - {order.shippingAddress?.pincode}</p>
              <p className="font-mono mt-0.5">Phone: {order.shippingAddress?.mobile || order.customerMobile}</p>
            </div>
            <div className="text-right">
              <p className="font-bold text-gray-500 uppercase text-[10px]">Payment Information:</p>
              <p className="font-bold uppercase mt-0.5">{order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Online Prepaid (Razorpay / UPI)'}</p>
              <p className="text-gray-500 text-[11px]">Status: {order.paymentStatus || 'COMPLETED'}</p>
            </div>
          </div>

          {/* Table */}
          <table className="w-full text-left">
            <thead>
              <tr className="border-b text-gray-500 font-bold uppercase text-[10px]">
                <th className="pb-2">Item Description</th>
                <th className="pb-2 text-center">Qty</th>
                <th className="pb-2 text-right">Unit Price</th>
                <th className="pb-2 text-right">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {order.items?.map((item, idx) => (
                <tr key={idx} className="py-2">
                  <td className="py-2">
                    <p className="font-bold text-gray-900">{item.product?.name}</p>
                    <p className="text-[10px] text-gray-400">SKU: {item.product?.id}</p>
                  </td>
                  <td className="py-2 text-center">{item.quantity}</td>
                  <td className="py-2 text-right">₹{item.product?.price}</td>
                  <td className="py-2 text-right font-bold">₹{item.product?.price * item.quantity}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Summary */}
          <div className="flex justify-end pt-2 border-t">
            <div className="w-64 space-y-1.5 text-right">
              <div className="flex justify-between text-gray-600">
                <span>Taxable Value:</span>
                <span>₹{taxableAmount}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>GST ({gstRate}%):</span>
                <span>₹{gstAmount}</span>
              </div>
              <div className="flex justify-between font-black text-base border-t pt-1.5 text-gray-900">
                <span>Total Amount:</span>
                <span>₹{order.totalAmount?.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button onClick={onClose} className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
