import React, { useState } from 'react';
import { Package, Search, Plus, Minus, Check, AlertTriangle, ArrowRight } from 'lucide-react';
import { Product } from '../../types';

interface AdminInventoryTabProps {
  products: Product[];
  updateProduct: (product: Product) => void;
  onNavigateProducts: () => void;
}

export const AdminInventoryTab: React.FC<AdminInventoryTabProps> = ({
  products,
  updateProduct,
  onNavigateProducts,
}) => {
  const [search, setSearch] = useState('');
  const [stockChanges, setStockChanges] = useState<Record<string, number>>({});

  const filtered = products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.category.toLowerCase().includes(search.toLowerCase())
  );

  const handleAdjust = (productId: string, delta: number) => {
    const current = stockChanges[productId] !== undefined ? stockChanges[productId] : (products.find(p => p.id === productId)?.stock || 0);
    const updated = Math.max(0, current + delta);
    setStockChanges(prev => ({ ...prev, [productId]: updated }));
  };

  const handleSave = (product: Product) => {
    const newStock = stockChanges[product.id];
    if (newStock !== undefined && newStock !== product.stock) {
      updateProduct({ ...product, stock: newStock });
      const next = { ...stockChanges };
      delete next[product.id];
      setStockChanges(next);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Warehouse Inventory & Stock Adjustments</h3>
          <p className="text-xs text-slate-500">Live stock level adjustment and replenishment</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Filter products..."
              className="pl-8 pr-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={onNavigateProducts}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
          >
            <span>Catalog</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 overflow-x-auto shadow-xs">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400">
              <th className="pb-3 font-semibold">Product</th>
              <th className="pb-3 font-semibold">Category</th>
              <th className="pb-3 font-semibold">Current Stock</th>
              <th className="pb-3 font-semibold">Adjust Stock</th>
              <th className="pb-3 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
            {filtered.map(p => {
              const currentVal = stockChanges[p.id] !== undefined ? stockChanges[p.id] : p.stock;
              const hasChanged = stockChanges[p.id] !== undefined && stockChanges[p.id] !== p.stock;
              const isLow = currentVal < 10;

              return (
                <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 flex items-center gap-2.5">
                    <img src={p.image} alt={p.name} className="w-9 h-9 object-cover rounded-lg border border-slate-200 dark:border-slate-700 shrink-0" />
                    <div className="min-w-0">
                      <p className="font-bold text-slate-900 dark:text-white truncate max-w-xs">{p.name}</p>
                      <p className="text-[10px] text-slate-400">SKU: {p.id}</p>
                    </div>
                  </td>
                  <td className="py-3 text-slate-500 capitalize">{p.category}</td>
                  <td className="py-3">
                    <span className={`px-2 py-0.5 rounded-full font-bold text-[11px] ${
                      isLow ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-400' : 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200'
                    }`}>
                      {p.stock} units {isLow && '⚠️'}
                    </span>
                  </td>
                  <td className="py-3">
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleAdjust(p.id, -1)}
                        className="p-1 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="font-mono font-bold w-12 text-center text-sm">{currentVal}</span>
                      <button
                        onClick={() => handleAdjust(p.id, 1)}
                        className="p-1 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleAdjust(p.id, 10)}
                        className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400"
                      >
                        +10
                      </button>
                    </div>
                  </td>
                  <td className="py-3 text-right">
                    {hasChanged && (
                      <button
                        onClick={() => handleSave(p)}
                        className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-xs"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Save</span>
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
