import React, { useState } from 'react';
import { RotateCcw, Check, X, IndianRupee, Truck, ShieldCheck, AlertCircle, RefreshCw } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { ReturnRequest, RefundRecord } from '../../types';

export const AdminReturnsTab: React.FC = () => {
  const { returns, refunds, updateReturnStatus, processRefund, updateRefundStatus } = useShop();

  const [activeSubTab, setActiveSubTab] = useState<'returns' | 'refunds'>('returns');
  const [selectedReturn, setSelectedReturn] = useState<ReturnRequest | null>(null);
  const [adminNotes, setAdminNotes] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Refund processing modal state
  const [isRefundModalOpen, setIsRefundModalOpen] = useState(false);
  const [refundOrderId, setRefundOrderId] = useState('');
  const [refundCustomerId, setRefundCustomerId] = useState('');
  const [refundAmount, setRefundAmount] = useState(0);
  const [refundMethod, setRefundMethod] = useState<'wallet' | 'original_payment' | 'manual'>('wallet');

  const handleUpdateReturn = async (id: string, newStatus: string) => {
    const res = await updateReturnStatus(id, newStatus, adminNotes);
    if (res.success) {
      setStatusMessage(`Return status updated to ${newStatus}.`);
      setSelectedReturn(null);
      setAdminNotes('');
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  const handleInitiateRefundFromReturn = (ret: ReturnRequest) => {
    const totalItemValue = ret.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    setRefundOrderId(ret.orderId);
    setRefundCustomerId(ret.customerId);
    setRefundAmount(totalItemValue);
    setRefundMethod('wallet');
    setIsRefundModalOpen(true);
  };

  const handleProcessRefundSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (refundAmount <= 0) return;

    const res = await processRefund({
      orderId: refundOrderId,
      customerId: refundCustomerId,
      amount: refundAmount,
      method: refundMethod,
      status: 'completed',
    });

    if (res.success) {
      setStatusMessage(`Refund of ₹${refundAmount} processed successfully.`);
      setIsRefundModalOpen(false);
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white">
        <div>
          <div className="flex items-center gap-2">
            <RotateCcw className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-black tracking-tight">Returns & Refunds Management</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Review customer return requests, schedule reverse pickups, and issue refunds directly to customer wallets or payment source.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => setActiveSubTab('returns')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                activeSubTab === 'returns'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Return Requests ({returns.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveSubTab('refunds')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                activeSubTab === 'refunds'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Refund Ledger ({refunds.length})
            </button>
          </div>
        </div>
      </div>

      {statusMessage && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-xl flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Returns List */}
      {activeSubTab === 'returns' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-[11px] uppercase font-bold text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Order / Return ID</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Items / Reason</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {returns.length > 0 ? (
                  returns.map(ret => (
                    <tr key={ret.id} className="hover:bg-slate-800/40 transition">
                      <td className="py-3 px-4">
                        <div className="font-mono font-bold text-blue-400">{ret.orderId}</div>
                        <div className="text-[10px] text-slate-500">Req: {ret.id}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-bold text-white">{ret.customerName}</div>
                        <div className="text-[10px] text-slate-400">{ret.customerPhone}</div>
                      </td>

                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-semibold text-slate-200">
                          {ret.items.map(i => `${i.name} (x${i.quantity})`).join(', ')}
                        </div>
                        <div className="text-[11px] text-amber-300 mt-0.5">
                          Reason: {ret.reason}
                        </div>
                        {ret.description && (
                          <div className="text-[10px] text-slate-400 italic">"{ret.description}"</div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-[11px] text-slate-400">
                        {new Date(ret.createdAt).toLocaleDateString('en-IN', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </td>

                      <td className="py-3 px-4">
                        <span
                          className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase ${
                            ret.status === 'completed'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : ret.status === 'approved'
                              ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                              : ret.status === 'pickup_scheduled'
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              : ret.status === 'rejected'
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              : 'bg-slate-700 text-slate-300'
                          }`}
                        >
                          {ret.status.replace('_', ' ')}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right space-x-1.5">
                        {ret.status === 'requested' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateReturn(ret.id, 'approved')}
                            className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-[11px] transition cursor-pointer"
                          >
                            Approve
                          </button>
                        )}
                        {ret.status === 'approved' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateReturn(ret.id, 'pickup_scheduled')}
                            className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg text-[11px] transition cursor-pointer"
                          >
                            Schedule Pickup
                          </button>
                        )}
                        {ret.status === 'pickup_scheduled' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateReturn(ret.id, 'returned')}
                            className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-lg text-[11px] transition cursor-pointer"
                          >
                            Mark Received
                          </button>
                        )}
                        {ret.status === 'returned' && (
                          <button
                            type="button"
                            onClick={() => handleInitiateRefundFromReturn(ret)}
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-[11px] transition cursor-pointer flex items-center gap-1 inline-flex"
                          >
                            <IndianRupee className="w-3 h-3" />
                            <span>Issue Refund</span>
                          </button>
                        )}
                        {ret.status === 'requested' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateReturn(ret.id, 'rejected')}
                            className="px-2 py-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-bold rounded-lg text-[11px] transition cursor-pointer"
                          >
                            Reject
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      No customer return requests submitted yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Refunds Ledger */}
      {activeSubTab === 'refunds' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-[11px] uppercase font-bold text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Refund ID / Order</th>
                  <th className="py-3 px-4">Customer ID</th>
                  <th className="py-3 px-4">Amount</th>
                  <th className="py-3 px-4">Method</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {refunds.length > 0 ? (
                  refunds.map(ref => (
                    <tr key={ref.id} className="hover:bg-slate-800/40 transition">
                      <td className="py-3 px-4 font-mono font-bold text-white">
                        <div>{ref.id}</div>
                        <div className="text-[10px] text-blue-400 font-normal">Order: {ref.orderId}</div>
                      </td>

                      <td className="py-3 px-4 font-mono text-slate-300">
                        {ref.customerId}
                      </td>

                      <td className="py-3 px-4 font-black text-emerald-400 text-sm">
                        ₹{ref.amount.toLocaleString('en-IN')}
                      </td>

                      <td className="py-3 px-4 capitalize font-semibold text-slate-300">
                        {ref.method.replace('_', ' ')}
                      </td>

                      <td className="py-3 px-4 text-[11px] text-slate-400">
                        {new Date(ref.createdAt).toLocaleDateString('en-IN', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </td>

                      <td className="py-3 px-4">
                        <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          {ref.status}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      No refunds processed yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Refund Modal */}
      {isRefundModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white max-w-md w-full space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <IndianRupee className="w-4 h-4 text-emerald-400" />
                <span>Issue Customer Refund</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsRefundModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleProcessRefundSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Order ID</label>
                <input
                  type="text"
                  readOnly
                  value={refundOrderId}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-mono font-bold text-slate-300"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Refund Amount (₹) *</label>
                <input
                  type="number"
                  required
                  min={1}
                  value={refundAmount}
                  onChange={e => setRefundAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-emerald-400 text-base"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Refund Method</label>
                <select
                  value={refundMethod}
                  onChange={e => setRefundMethod(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-semibold text-white"
                >
                  <option value="wallet">Customer Store Wallet (Instant)</option>
                  <option value="original_payment">Original Payment Gateway</option>
                  <option value="manual">Manual Bank Transfer / Cash</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsRefundModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md"
                >
                  Confirm & Process Refund
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
