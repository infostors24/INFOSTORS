import React, { useState } from 'react';
import { MessageCircle, Check, Save, Phone, Sparkles } from 'lucide-react';
import { StoreSettings } from '../../types';

interface AdminWhatsAppNotificationsTabProps {
  storeSettings: StoreSettings;
  updateStoreSettings?: (settings: StoreSettings) => void;
}

export const AdminWhatsAppNotificationsTab: React.FC<AdminWhatsAppNotificationsTabProps> = ({
  storeSettings,
  updateStoreSettings,
}) => {
  const [businessNumber, setBusinessNumber] = useState(
    storeSettings.whatsappNotificationSettings?.businessNumber || '+919477839200'
  );
  const [autoPrompt, setAutoPrompt] = useState(
    storeSettings.whatsappNotificationSettings?.autoPromptOnStatusChange !== false
  );
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    if (updateStoreSettings) {
      updateStoreSettings({
        ...storeSettings,
        whatsappNotificationSettings: {
          ...storeSettings.whatsappNotificationSettings,
          businessNumber,
          autoPromptOnStatusChange: autoPrompt,
          enabledTypes: storeSettings.whatsappNotificationSettings?.enabledTypes || {
            order_confirmed: true,
            order_processing: true,
            order_dispatched: true,
            out_for_delivery: true,
            order_delivered: true,
            order_cancelled: true,
            payment_received: true,
          },
          templates: storeSettings.whatsappNotificationSettings?.templates || {
            order_confirmed: {
              title: 'Order Confirmed',
              body: 'Hi {{customer_name}}, thank you for shopping with INFOSTORS! Your order #{{order_id}} has been confirmed.',
            },
            order_processing: {
              title: 'Order Processing',
              body: 'Hi {{customer_name}}, your order #{{order_id}} is being packed and prepared for dispatch.',
            },
            order_dispatched: {
              title: 'Order Dispatched',
              body: 'Hi {{customer_name}}, your order #{{order_id}} has been shipped with {{courier_partner}}. Tracking ID: {{tracking_id}}.',
            },
            out_for_delivery: {
              title: 'Out for Delivery',
              body: 'Hi {{customer_name}}, your order #{{order_id}} is out for delivery today.',
            },
            order_delivered: {
              title: 'Order Delivered',
              body: 'Hi {{customer_name}}, your order #{{order_id}} has been successfully delivered. Enjoy your smart gadgets!',
            },
            order_cancelled: {
              title: 'Order Cancelled',
              body: 'Hi {{customer_name}}, your order #{{order_id}} has been cancelled.',
            },
            payment_received: {
              title: 'Payment Received',
              body: 'Hi {{customer_name}}, payment of ₹{{amount}} for order #{{order_id}} has been received.',
            },
          },
        },
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">WhatsApp Order Notification Engine</h3>
          <p className="text-xs text-slate-500">Automated buyer notification templates and direct customer updates</p>
        </div>
        <button
          onClick={handleSave}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-colors"
        >
          {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          <span>{saved ? 'Saved' : 'Save Changes'}</span>
        </button>
      </div>

      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              WhatsApp Business Mobile
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={businessNumber}
                onChange={e => setBusinessNumber(e.target.value)}
                placeholder="+919477839200"
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">Auto-Prompt on Status Change</p>
              <p className="text-[11px] text-slate-500">Prompt to send WhatsApp message when order status changes</p>
            </div>
            <input
              type="checkbox"
              checked={autoPrompt}
              onChange={e => setAutoPrompt(e.target.checked)}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Notification Templates</h4>
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60">
              <span className="text-xs font-bold text-blue-600 dark:text-blue-400">Order Confirmed</span>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                "Hi &#123;&#123;customer_name&#125;&#125;, thank you for shopping with INFOSTORS! Your order #&#123;&#123;order_id&#125;&#125; has been confirmed."
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60">
              <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">Dispatched / Shipped</span>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                "Hi &#123;&#123;customer_name&#125;&#125;, your order #&#123;&#123;order_id&#125;&#125; has been shipped with &#123;&#123;courier_partner&#125;&#125;. Tracking ID: &#123;&#123;tracking_id&#125;&#125;."
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
