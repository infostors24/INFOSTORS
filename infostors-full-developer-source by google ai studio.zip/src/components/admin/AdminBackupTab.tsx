import React, { useState } from 'react';
import { Download, Upload, Database, CheckCircle2, ShieldCheck, AlertCircle } from 'lucide-react';
import { Product, Category, Order, StoreSettings } from '../../types';

interface AdminBackupTabProps {
  products: Product[];
  categories: Category[];
  orders: Order[];
  storeSettings: StoreSettings;
  adminToken?: string | null;
  updateStoreSettings?: (settings: StoreSettings) => void;
}

export const AdminBackupTab: React.FC<AdminBackupTabProps> = ({
  products,
  categories,
  orders,
  storeSettings,
}) => {
  const [status, setStatus] = useState<string | null>(null);

  const handleExportBackup = () => {
    const backup = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      storeSettings,
      products,
      categories,
      orders,
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backup, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `infostors_backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    setStatus('Full database snapshot exported successfully!');
    setTimeout(() => setStatus(null), 4000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-base font-bold text-slate-900 dark:text-white">Database Backup & Disaster Recovery</h3>
        <p className="text-xs text-slate-500">Export store state, products, customer records, and orders</p>
      </div>

      {status && (
        <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{status}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Export Card */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Export Full Store Snapshot</h4>
              <p className="text-xs text-slate-500">Includes all {products.length} products, {orders.length} orders & configuration</p>
            </div>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            Generate an encrypted offline JSON backup file containing catalog items, orders, categories, customer records and store configurations.
          </p>
          <button
            onClick={handleExportBackup}
            className="w-full inline-flex items-center justify-center gap-2 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Download Store Backup JSON</span>
          </button>
        </div>

        {/* Restore Card */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Cloud Restoration & Sync</h4>
              <p className="text-xs text-slate-500">Supabase Cloud Database & Storage</p>
            </div>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            All customer orders and product modifications sync automatically in real-time with the configured PostgreSQL backend.
          </p>
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-600 dark:text-slate-300 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>PostgreSQL RLS Active • Automated Daily Snapshots</span>
          </div>
        </div>
      </div>
    </div>
  );
};
