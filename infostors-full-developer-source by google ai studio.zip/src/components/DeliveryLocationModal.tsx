import React, { useState } from 'react';
import { X, MapPin, Check, Search } from 'lucide-react';

interface DeliveryLocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLocation?: { pincode?: string; city?: string; state?: string } | null;
  onSaveLocation: (loc: { pincode: string; city: string; state: string }) => void;
}

export const DeliveryLocationModal: React.FC<DeliveryLocationModalProps> = ({
  isOpen,
  onClose,
  currentLocation,
  onSaveLocation,
}) => {
  const [pincode, setPincode] = useState(currentLocation?.pincode || '');
  const [city, setCity] = useState(currentLocation?.city || 'Kolkata');
  const [state, setState] = useState(currentLocation?.state || 'West Bengal');

  if (!isOpen) return null;

  const popularCities = [
    { city: 'Kolkata', state: 'West Bengal', pincode: '700084' },
    { city: 'Mumbai', state: 'Maharashtra', pincode: '400001' },
    { city: 'Bengaluru', state: 'Karnataka', pincode: '560001' },
    { city: 'New Delhi', state: 'Delhi', pincode: '110001' },
    { city: 'Hyderabad', state: 'Telangana', pincode: '500001' },
    { city: 'Chennai', state: 'Tamil Nadu', pincode: '600001' },
  ];

  const handleSave = () => {
    onSaveLocation({
      pincode: pincode.trim() || '700084',
      city: city.trim() || 'Kolkata',
      state: state.trim() || 'West Bengal',
    });
    onClose();
  };

  const handleSelectPopular = (item: typeof popularCities[0]) => {
    setPincode(item.pincode);
    setCity(item.city);
    setState(item.state);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Select Delivery Location</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Check delivery speed & options</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Enter 6-digit Pincode</label>
            <div className="relative">
              <input
                type="text"
                maxLength={6}
                value={pincode}
                onChange={e => setPincode(e.target.value.replace(/\D/g, ''))}
                placeholder="e.g. 700084"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">City</label>
              <input
                type="text"
                value={city}
                onChange={e => setCity(e.target.value)}
                placeholder="City"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">State</label>
              <input
                type="text"
                value={state}
                onChange={e => setState(e.target.value)}
                placeholder="State"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none"
              />
            </div>
          </div>

          <div>
            <span className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Popular Cities</span>
            <div className="grid grid-cols-2 gap-2">
              {popularCities.map(item => (
                <button
                  key={item.city}
                  type="button"
                  onClick={() => handleSelectPopular(item)}
                  className={`flex items-center justify-between p-2 rounded-xl border text-xs text-left transition-colors ${
                    city === item.city
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 font-bold'
                      : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <span>{item.city}</span>
                  {city === item.city && <Check className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-md transition-colors"
          >
            Apply Location
          </button>
        </div>
      </div>
    </div>
  );
};
