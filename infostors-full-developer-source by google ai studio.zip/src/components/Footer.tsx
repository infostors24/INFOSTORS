import React from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  CreditCard,
  MessageCircle
} from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { InfostorsLogo } from './InfostorsLogo';

export const Footer: React.FC = () => {
  const { storeSettings, setPolicyModal } = useShop();

  return (
    <footer className="w-full bg-slate-900 text-slate-300 border-t border-slate-800 transition-colors duration-200">
      {/* Top Value Proposition Grid */}
      <div className="border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Free Express Delivery</h4>
              <p className="text-xs text-slate-400">On all orders above ₹499</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">7 Days Replacement</h4>
              <p className="text-xs text-slate-400">Hassle-free doorstep pickup</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">100% Genuine Products</h4>
              <p className="text-xs text-slate-400">Directly from verified brands</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Secure Payments</h4>
              <p className="text-xs text-slate-400">UPI, Cards, NetBanking, COD</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand Info */}
        <div className="space-y-4">
          <InfostorsLogo className="h-10 w-auto" />
          <p className="text-xs text-slate-400 leading-relaxed">
            {storeSettings.tagline || 'Smart Gadgets | Better Life'}. Your trusted Indian destination for premium electronic gear, audio, chargers, and smart living gadgets.
          </p>
          <div className="pt-2 flex items-center gap-2">
            <a
              href={storeSettings.whatsappUrl || 'https://wa.me/919477839200'}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30 transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp Help</span>
            </a>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Customer Care</h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button 
                onClick={() => setPolicyModal('shipping')}
                className="hover:text-blue-400 transition-colors text-left"
              >
                Shipping & Delivery Policy
              </button>
            </li>
            <li>
              <button 
                onClick={() => setPolicyModal('returns')}
                className="hover:text-blue-400 transition-colors text-left"
              >
                Return & Refund Policy
              </button>
            </li>
            <li>
              <button 
                onClick={() => setPolicyModal('warranty')}
                className="hover:text-blue-400 transition-colors text-left"
              >
                Warranty & Guarantee
              </button>
            </li>
            <li>
              <button 
                onClick={() => setPolicyModal('terms')}
                className="hover:text-blue-400 transition-colors text-left"
              >
                Terms of Service
              </button>
            </li>
            <li>
              <button 
                onClick={() => setPolicyModal('privacy')}
                className="hover:text-blue-400 transition-colors text-left"
              >
                Privacy Policy
              </button>
            </li>
          </ul>
        </div>

        {/* Categories */}
        <div>
          <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Top Categories</h4>
          <ul className="space-y-2 text-xs text-slate-400">
            <li>Audio & Earbuds</li>
            <li>Fast Chargers & GaN</li>
            <li>RGB Smart Flow Lights</li>
            <li>Deep Tissue Massagers</li>
            <li>Smart Home Security</li>
          </ul>
        </div>

        {/* Contact Info */}
        <div className="space-y-3">
          <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Support & Contact</h4>
          <div className="flex items-start gap-2.5 text-xs text-slate-400">
            <MapPin className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            <span>{storeSettings.officeAddress || 'INFOSTORS HQ, Garia station road, Kolkata 700084, India'}</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs text-slate-400">
            <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{storeSettings.helpline || '+91 94778 39200 (Toll Free / WhatsApp)'}</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs text-slate-400">
            <Mail className="w-4 h-4 text-indigo-400 shrink-0" />
            <span>{storeSettings.email || 'contactinfostors@gmail.com'}</span>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-slate-800/80 bg-slate-950/60 py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} {storeSettings.storeName || 'INFOSTORS'} Enterprises Pvt Ltd. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>GSTIN: {storeSettings.gstin || '19AAACI1234F1Z8'}</span>
            <span>•</span>
            <span>CIN: U52100WB2026PTC254120</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
