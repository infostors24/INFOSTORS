import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, ShieldCheck, Zap, Truck, RotateCcw } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const HeroBanner: React.FC = () => {
  const { setSelectedCategory, setSelectedSection } = useShop();

  const slides = [
    {
      badge: '⚡ FLASH SALE LIVE',
      title: 'Upgrade Your Digital Lifestyle',
      highlight: 'Up to 60% OFF',
      subtitle: 'Premium wireless earbuds, 65W GaN fast chargers, and smart living gadgets engineered for the future.',
      cta: 'Shop Best Deals',
      section: 'deals' as const,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=1200&auto=format&fit=crop&q=80',
    },
    {
      badge: '✨ NEW LAUNCH',
      title: 'Atmospheric RGB Flow Bars',
      highlight: 'Sound Reactive 16M Colors',
      subtitle: 'Transform your battlestation or entertainment center with intelligent rhythm-sync lighting.',
      cta: 'Explore RGB Lights',
      section: 'new' as const,
      category: 'rgb-lights',
      image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1200&auto=format&fit=crop&q=80',
    },
  ];

  const [activeSlide, setActiveSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide(prev => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const current = slides[activeSlide];

  return (
    <div className="relative w-full overflow-hidden bg-slate-900 text-white">
      <div className="relative max-w-7xl mx-auto px-4 py-8 sm:py-12 md:py-16 flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="flex-1 space-y-4 max-w-xl text-center md:text-left z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-600/30 text-blue-300 border border-blue-500/30">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>{current.badge}</span>
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight leading-tight">
            {current.title} <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">{current.highlight}</span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            {current.subtitle}
          </p>

          <div className="pt-2 flex flex-wrap items-center justify-center md:justify-start gap-3">
            <button
              onClick={() => {
                if (current.category) {
                  setSelectedCategory(current.category);
                } else {
                  setSelectedSection(current.section);
                }
                const el = document.getElementById('products-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-lg shadow-blue-600/30 hover:shadow-blue-600/50 active:scale-95 transition-all"
            >
              <span>{current.cta}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                setSelectedSection('all');
                setSelectedCategory('all');
                const el = document.getElementById('products-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-sm bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-700/60 active:scale-95 transition-all"
            >
              All Products
            </button>
          </div>

          {/* Quick value badges */}
          <div className="pt-4 grid grid-cols-3 gap-2 text-[11px] text-slate-400 border-t border-slate-800/80">
            <div className="flex items-center gap-1.5 justify-center md:justify-start">
              <Truck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span>Free Delivery &gt;₹499</span>
            </div>
            <div className="flex items-center gap-1.5 justify-center md:justify-start">
              <RotateCcw className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span>7 Days Return</span>
            </div>
            <div className="flex items-center gap-1.5 justify-center md:justify-start">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>100% Genuine</span>
            </div>
          </div>
        </div>

        {/* Hero Visual Card */}
        <div className="relative w-full md:w-1/2 max-w-md h-56 sm:h-72 md:h-80 rounded-2xl overflow-hidden shadow-2xl border border-slate-700/50 group">
          <img
            src={current.image}
            alt={current.title}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-4">
            <div className="flex items-center gap-2">
              {slides.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActiveSlide(i)}
                  className={`h-2 rounded-full transition-all ${
                    i === activeSlide ? 'w-6 bg-blue-500' : 'w-2 bg-slate-500/60'
                  }`}
                  aria-label={`Slide ${i + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
