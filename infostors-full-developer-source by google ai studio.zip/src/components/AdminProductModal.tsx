import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Edit3, 
  Check, 
  Sparkles, 
  Package, 
  FolderPlus, 
  Truck, 
  Settings, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  Phone, 
  Mail, 
  ExternalLink,
  Search,
  Save,
  RotateCcw,
  Upload,
  Image as ImageIcon,
  Sliders,
  User,
  LogOut,
  AlertCircle,
  CreditCard,
  Eye,
  EyeOff,
  Key,
  Copy,
  ShieldCheck,
  Zap,
  Smartphone,
  Banknote,
  Percent,
  FileText,
  Building2,
  RefreshCw,
  Table,
  Users,
  Printer,
  MessageCircle,
  Ban,
  LayoutDashboard,
  BarChart3,
  Database,
  Boxes,
  Download,
  Menu,
  Lock,
  ChevronRight,
  Tag,
  Flame,
  Star,
  Store,
  Globe,
  Palette,
} from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { Product, Category, PackageStatus, StoreSettings, PaymentSettingsInfo, AdminRole, Order } from '../types';
import { InfostorsLogo } from './InfostorsLogo';
import { parseApiResponse } from '../utils/safeApi';
import { AdminManagementTab } from './admin/AdminManagementTab';
import { AdminPwaSettingsTab } from './admin/AdminPwaSettingsTab';
import { DeleteRequestsTab } from './admin/DeleteRequestsTab';
import { AuditLogsTab } from './admin/AuditLogsTab';
import { ShippingLabelModal } from './ShippingLabelModal';
import { DeleteRequestModal } from './admin/DeleteRequestModal';
import { AdminDashboardTab } from './admin/AdminDashboardTab';
import { AdminInventoryTab } from './admin/AdminInventoryTab';
import { AdminReportsTab } from './admin/AdminReportsTab';
import { AdminBackupTab } from './admin/AdminBackupTab';
import { AdminWhatsAppNotificationsTab } from './admin/AdminWhatsAppNotificationsTab';
import { OrderWhatsAppModal } from './admin/OrderWhatsAppModal';
import { CustomerMessageModal } from './admin/CustomerMessageModal';
import { AdminInvoiceModal } from './admin/AdminInvoiceModal';
import { AdminCouponsTab } from './admin/AdminCouponsTab';
import { AdminFlashSalesTab } from './admin/AdminFlashSalesTab';
import { AdminReviewsTab } from './admin/AdminReviewsTab';
import { AdminReturnsTab } from './admin/AdminReturnsTab';
import { AdminVendorsTab } from './admin/AdminVendorsTab';
import { AdminOffersTab } from './admin/AdminOffersTab';
import { AdminIntegrationsTab } from './admin/AdminIntegrationsTab';
import { AdminThemeLayoutTab } from './admin/AdminThemeLayoutTab';

const GST_STATE_OPTIONS = [
  '19 - West Bengal',
  '27 - Maharashtra',
  '07 - Delhi',
  '29 - Karnataka',
  '33 - Tamil Nadu',
  '09 - Uttar Pradesh',
  '24 - Gujarat',
  '06 - Haryana',
  '03 - Punjab',
  '08 - Rajasthan',
  '10 - Bihar',
  '20 - Jharkhand',
  '21 - Odisha',
  '23 - Madhya Pradesh',
  '22 - Chhattisgarh',
  '36 - Telangana',
  '37 - Andhra Pradesh',
  '32 - Kerala',
  '30 - Goa',
  '18 - Assam',
  '02 - Himachal Pradesh',
  '05 - Uttarakhand',
  '01 - Jammu and Kashmir',
  '04 - Chandigarh',
];

export interface AdminProductModalProps {
  isStandalone?: boolean;
}

export const AdminProductModal: React.FC<AdminProductModalProps> = ({ isStandalone = false }) => {
  const {
    isAdminOpen,
    setIsAdminOpen,
    products,
    categories,
    orders,
    storeSettings,
    addProduct,
    updateProduct,
    deleteProduct,
    addCategory,
    updateCategory,
    deleteCategory,
    updateOrderStatus,
    updateStoreSettings,
    adminProfile,
    adminToken,
    isAdminAuthenticated,
    adminGoogleLogin,
    adminEmailPasswordLogin,
    adminLogout,
    fetchAdminList,
    createAdmin,
    modifyAdmin,
    removeAdmin,
    coupons,
    flashSales,
    reviews,
    returns,
    vendors,
    offers,
  } = useShop();

  // Active Admin tab
  const [activeTab, setActiveTab] = useState<
    | 'dashboard'
    | 'products'
    | 'categories'
    | 'inventory'
    | 'orders'
    | 'customers'
    | 'admins'
    | 'settings'
    | 'whatsapp'
    | 'pwa'
    | 'payments'
    | 'reports'
    | 'backup'
    | 'delete_requests'
    | 'audit_logs'
    | 'coupons'
    | 'flash_sales'
    | 'reviews'
    | 'returns'
    | 'vendors'
    | 'offers'
    | 'integrations'
    | 'theme_layout'
  >('dashboard');
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  const handleSelectTab = (tabId: typeof activeTab) => {
    setActiveTab(tabId);
    if (tabId === 'products') {
      setIsCreatingProduct(false);
      setEditingProduct(null);
    } else if (tabId === 'categories') {
      setIsCreatingCategory(false);
      setEditingCategory(null);
    } else if (tabId === 'settings') {
      setSettingsForm({ ...storeSettings });
    }
    setIsMobileNavOpen(false);
  };

  // WhatsApp Order Update Modal State
  const [selectedWhatsAppOrder, setSelectedWhatsAppOrder] = useState<Order | null>(null);

  // Inventory Management State
  const [inventorySearchQuery, setInventorySearchQuery] = useState('');
  const [inventoryFilter, setInventoryFilter] = useState<'all' | 'low' | 'out' | 'in'>('all');
  const [stockEditMessage, setStockEditMessage] = useState<string | null>(null);

  // Backup & Restore State
  const [backupSuccessMessage, setBackupSuccessMessage] = useState<string | null>(null);
  const [backupErrorMessage, setBackupErrorMessage] = useState<string | null>(null);

  // Shipping Label Modal State (4x6 with Barcode + Data Matrix)
  const [selectedShippingLabelOrder, setSelectedShippingLabelOrder] = useState<any | null>(null);

  // Tax Invoice Modal State
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);

  // Customer Direct Message Modal State (Section 17)
  const [selectedMessageCustomer, setSelectedMessageCustomer] = useState<any | null>(null);

  // Multi-Party Delete Request Modal State
  const [deleteRequestTarget, setDeleteRequestTarget] = useState<{
    type: 'order' | 'customer';
    id: string;
    summary: string;
  } | null>(null);

  // Dispatch & Courier Partner Modal State
  const [dispatchModalOrder, setDispatchModalOrder] = useState<any | null>(null);
  const [dispatchCourierInput, setDispatchCourierInput] = useState('Delhivery Express');
  const [dispatchTrackingInput, setDispatchTrackingInput] = useState('');
  const [dispatchLoading, setDispatchLoading] = useState(false);

  // Admin Login States
  const [adminLoginMode, setAdminLoginMode] = useState<'google' | 'password'>('google');
  const [adminEmailInput, setAdminEmailInput] = useState('');
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [adminMobileInput, setAdminMobileInput] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);
  const [adminLoginError, setAdminLoginError] = useState('');
  const [adminLoginLoading, setAdminLoginLoading] = useState(false);
  const [testGoogleEmail, setTestGoogleEmail] = useState('');

  // Order Search & Status Filter States
  const [orderSearchQuery, setOrderSearchQuery] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<'all' | 'received' | 'dispatched' | 'delivered' | 'cancelled'>('all');

  // Filtered Orders Calculation
  const filteredOrders = React.useMemo(() => {
    return orders.filter(o => {
      const q = orderSearchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        o.orderId.toLowerCase().includes(q) ||
        (o.customer?.fullName || '').toLowerCase().includes(q) ||
        (o.customer?.phone || '').includes(q) ||
        (o.customer?.city || '').toLowerCase().includes(q) ||
        (o.customer?.state || '').toLowerCase().includes(q) ||
        (o.trackingId || '').toLowerCase().includes(q);

      const isCancelled = o.orderStatus === 'cancelled' || (o.resolution || '').toLowerCase().includes('cancel');
      const matchesStatus =
        orderStatusFilter === 'all' ||
        (orderStatusFilter === 'cancelled' && isCancelled) ||
        (orderStatusFilter !== 'cancelled' && !isCancelled && o.status === orderStatusFilter);

      return matchesSearch && matchesStatus;
    });
  }, [orders, orderSearchQuery, orderStatusFilter]);

  // Route URL synchronization for Admin Portal (/admin/login & /admin/dashboard)
  useEffect(() => {
    if (!isStandalone) return;
    try {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      if (isAdminAuthenticated) {
        if (path === '/admin' || path === '/admin/login' || path.startsWith('/admin/login')) {
          window.history.replaceState(null, '', '/admin/dashboard');
        } else if (hash === '#admin' || hash === '#/admin' || hash === '#/admin/login') {
          window.history.replaceState(null, '', '#/admin/dashboard');
        }
      } else {
        if (path === '/admin' || path === '/admin/dashboard' || path.startsWith('/admin/dashboard')) {
          window.history.replaceState(null, '', '/admin/login');
        } else if (hash === '#admin' || hash === '#/admin' || hash === '#/admin/dashboard') {
          window.history.replaceState(null, '', '#/admin/login');
        }
      }
    } catch (_) {}
  }, [isAdminAuthenticated, isStandalone]);

  // Payment Gateway Settings State
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettingsInfo | null>(null);
  const [paymentForm, setPaymentForm] = useState({
    keyId: '',
    keySecret: '',
    webhookSecret: '',
    isActive: true,
    environment: 'test' as 'test' | 'live',
  });
  const [showKeySecret, setShowKeySecret] = useState(false);
  const [showWebhookSecret, setShowWebhookSecret] = useState(false);
  const [isLoadingPaymentSettings, setIsLoadingPaymentSettings] = useState(false);
  const [isSavingPaymentSettings, setIsSavingPaymentSettings] = useState(false);
  const [paymentSaveMessage, setPaymentSaveMessage] = useState<string | null>(null);
  const [paymentErrorMessage, setPaymentErrorMessage] = useState<string | null>(null);
  const [testConnectionStatus, setTestConnectionStatus] = useState<{ loading: boolean; message?: string; success?: boolean } | null>(null);
  const [copiedWebhookUrl, setCopiedWebhookUrl] = useState(false);

  // Fetch payment settings when Payments tab becomes active
  useEffect(() => {
    if (activeTab === 'payments' && isAdminAuthenticated && adminToken) {
      setIsLoadingPaymentSettings(true);
      fetch('/api/admin/payments/razorpay', {
        headers: { Authorization: `Bearer ${adminToken}` },
      })
        .then(res => parseApiResponse(res))
        .then(result => {
          if (result.ok && result.data) {
            const data = result.data;
            const settingsData = data.settings || data;
            setPaymentSettings(settingsData);
            setPaymentForm({
              keyId: settingsData.rawKeyId || settingsData.keyId || '',
              keySecret: '', // Keep blank unless updating
              webhookSecret: '',
              isActive: settingsData.isActive ?? true,
              environment: settingsData.environment || settingsData.mode || 'test',
            });
          } else if (result.errorMessage) {
            setPaymentErrorMessage(result.errorMessage);
          }
        })
        .catch(err => {
          console.error('Payment settings load error:', err);
          setPaymentErrorMessage(err?.message || 'Failed to load payment configuration.');
        })
        .finally(() => setIsLoadingPaymentSettings(false));
    }
  }, [activeTab, isAdminAuthenticated, adminToken]);

  // Customers Tab State
  const [adminCustomers, setAdminCustomers] = useState<any[]>([]);
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const [isLoadingCustomers, setIsLoadingCustomers] = useState(false);

  // Fetch customers when Customers tab becomes active
  useEffect(() => {
    if (activeTab === 'customers' && isAdminAuthenticated && adminToken) {
      setIsLoadingCustomers(true);
      fetch('/api/admin/customers', {
        headers: { Authorization: `Bearer ${adminToken}` },
      })
        .then(res => parseApiResponse(res))
        .then(result => {
          if (result.ok && result.data?.customers) {
            setAdminCustomers(result.data.customers);
          }
        })
        .catch(err => console.error('Customers load error:', err))
        .finally(() => setIsLoadingCustomers(false));
    }
  }, [activeTab, isAdminAuthenticated, adminToken]);

  // Product states
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isCreatingProduct, setIsCreatingProduct] = useState(false);
  const [productSearch, setProductSearch] = useState('');
  const [productImages, setProductImages] = useState<string[]>([
    'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&auto=format&fit=crop&q=80',
    '',
    '',
    '',
  ]);
  const [formData, setFormData] = useState<Partial<Product>>({
    name: '',
    category: 'electronics',
    brand: 'INFOSTORS',
    price: 999,
    originalPrice: 1999,
    discount: 50,
    stock: 25,
    rating: 4.8,
    reviewsCount: 150,
    image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&auto=format&fit=crop&q=80',
    shortDescription: '',
    description: '',
    features: ['High durability build', '1 Year Warranty included'],
    isTrending: false,
    isBestseller: false,
    isNewArrival: true,
    isDeal: false,
    badge: 'NEW',
    warranty: '1 Year Warranty',
  });

  // Category states
  const [isCreatingCategory, setIsCreatingCategory] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [categoryToDeleteId, setCategoryToDeleteId] = useState<string | null>(null);
  const [orderActionFeedback, setOrderActionFeedback] = useState<{ orderId: string; type: 'success' | 'error'; message: string } | null>(null);
  const [categoryFormData, setCategoryFormData] = useState<Category>({
    id: '',
    name: '',
    emoji: '📦',
    description: '',
    bannerImage: '',
  });

  // Settings state
  const [settingsForm, setSettingsForm] = useState<StoreSettings>({ ...storeSettings });
  const [settingsSavedMessage, setSettingsSavedMessage] = useState(false);
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [settingsErrorMessage, setSettingsErrorMessage] = useState<string | null>(null);
  const logoFileInputRef = useRef<HTMLInputElement | null>(null);
  const [logoFileName, setLogoFileName] = useState<string>('');

  useEffect(() => {
    setSettingsForm({ ...storeSettings });
  }, [storeSettings, isAdminOpen]);

  const handleLogoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      setSettingsErrorMessage('Please choose an image file under 5MB');
      return;
    }
    setLogoFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        setSettingsForm(prev => ({ ...prev, logoUrl: result }));
      }
    };
    reader.readAsDataURL(file);
  };

  // --- Product Handlers ---
  const handleStartCreateProduct = () => {
    setIsCreatingProduct(true);
    setEditingProduct(null);
    setProductImages([
      'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&auto=format&fit=crop&q=80',
      '',
      '',
      '',
    ]);
    setFormData({
      id: `inf-${Date.now().toString().slice(-4)}`,
      name: '',
      category: categories.find(c => c.id !== 'all')?.id || 'electronics',
      brand: 'INFOSTORS',
      price: 1299,
      originalPrice: 2499,
      discount: 48,
      stock: 30,
      rating: 4.8,
      reviewsCount: 120,
      image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&auto=format&fit=crop&q=80',
      shortDescription: 'Modern smart product for everyday use with high reliability.',
      description: 'Engineered with premium materials and high efficiency internals to deliver everyday convenience and long lasting reliability.',
      features: ['Long lasting battery', 'Compact portable design', '1 Year Warranty'],
      isTrending: true,
      isBestseller: false,
      isNewArrival: true,
      isDeal: false,
      badge: 'NEW ARRIVAL',
      warranty: '1 Year Warranty',
    });
  };

  const handleStartEditProduct = (product: Product) => {
    setEditingProduct(product);
    setIsCreatingProduct(false);
    setFormData({ ...product });
    const existingList = product.images && product.images.length > 0
      ? product.images
      : [product.image];
    setProductImages([
      existingList[0] || product.image || '',
      existingList[1] || '',
      existingList[2] || '',
      existingList[3] || '',
    ]);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name?.trim()) return;

    const discountCalculated = formData.originalPrice && formData.price
      ? Math.round(((formData.originalPrice - formData.price) / formData.originalPrice) * 100)
      : formData.discount || 0;

    // Filter valid non-empty images
    const validImages = productImages
      .map(url => (url || '').trim())
      .filter(url => url.length > 0);

    const primaryImage = validImages[0] || formData.image || 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&auto=format&fit=crop&q=80';

    const productPayload: Product = {
      id: formData.id || `inf-${Date.now().toString().slice(-4)}`,
      name: formData.name || 'Untitled Product',
      category: formData.category || 'electronics',
      brand: formData.brand || 'INFOSTORS',
      price: Number(formData.price) || 999,
      originalPrice: Number(formData.originalPrice) || 1999,
      discount: discountCalculated,
      stock: Number(formData.stock) || 10,
      rating: Number(formData.rating) || 4.8,
      reviewsCount: Number(formData.reviewsCount) || 50,
      image: primaryImage,
      images: validImages.length > 0 ? validImages : [primaryImage],
      shortDescription: formData.shortDescription || '',
      description: formData.description || '',
      features: formData.features && formData.features.length > 0 ? formData.features : ['Quality inspected'],
      isTrending: Boolean(formData.isTrending),
      isBestseller: Boolean(formData.isBestseller),
      isNewArrival: Boolean(formData.isNewArrival),
      isDeal: Boolean(formData.isDeal),
      badge: formData.badge || '',
      warranty: formData.warranty || '1 Year Warranty',
    };

    if (editingProduct) {
      updateProduct(productPayload);
    } else {
      addProduct(productPayload);
    }

    setIsCreatingProduct(false);
    setEditingProduct(null);
  };

  // --- Category Handlers ---
  const handleStartCreateCategory = () => {
    setIsCreatingCategory(true);
    setEditingCategory(null);
    setCategoryFormData({
      id: '',
      name: '',
      emoji: '✨',
      description: 'Handpicked products crafted for daily utility.',
      bannerImage: 'https://images.unsplash.com/photo-1550009158-9ebf69173e03?w=800&auto=format&fit=crop&q=80',
    });
  };

  const handleStartEditCategory = (cat: Category) => {
    setEditingCategory(cat);
    setIsCreatingCategory(false);
    setCategoryFormData({ ...cat });
  };

  const handleSaveCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!categoryFormData.name.trim()) return;

    // Generate or clean ID slug
    const cleanId = categoryFormData.id.trim()
      ? categoryFormData.id.toLowerCase().replace(/[^a-z0-9-]/g, '-')
      : categoryFormData.name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-');

    const newCategory: Category = {
      ...categoryFormData,
      id: cleanId,
    };

    if (editingCategory) {
      updateCategory(newCategory);
    } else {
      addCategory(newCategory);
    }

    setIsCreatingCategory(false);
    setEditingCategory(null);
  };

  // --- Settings Handlers ---
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);
    setSettingsSavedMessage(false);
    setSettingsErrorMessage(null);
    try {
      const res = await updateStoreSettings(settingsForm);
      if (res && res.success) {
        setSettingsSavedMessage(true);
        setTimeout(() => setSettingsSavedMessage(false), 3500);
      } else if (res && res.error) {
        setSettingsErrorMessage(res.error);
      } else {
        setSettingsSavedMessage(true);
        setTimeout(() => setSettingsSavedMessage(false), 3500);
      }
    } catch (err: any) {
      setSettingsErrorMessage(err.message || 'Failed to save settings.');
    } finally {
      setIsSavingSettings(false);
    }
  };

  // --- Payment Gateway Handlers ---
  const handleSavePaymentSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminToken) return;
    setIsSavingPaymentSettings(true);
    setPaymentSaveMessage(null);
    setPaymentErrorMessage(null);

    try {
      const res = await fetch('/api/admin/payments/razorpay', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify(paymentForm),
      });

      const { ok, data, errorMessage } = await parseApiResponse(res);
      if (!ok || !data || data.success === false) {
        throw new Error(errorMessage || data?.error || 'Failed to save Razorpay configuration');
      }

      const settingsData = data.settings || data;
      setPaymentSettings(settingsData);
      setPaymentSaveMessage(data.message || 'Razorpay credentials saved and encrypted at rest!');
      setPaymentForm(prev => ({ ...prev, keySecret: '', webhookSecret: '' }));
      setTimeout(() => setPaymentSaveMessage(null), 4000);
    } catch (err: any) {
      setPaymentErrorMessage(err?.message || 'Error updating payment credentials');
    } finally {
      setIsSavingPaymentSettings(false);
    }
  };

  const handleTestPaymentConnection = async () => {
    if (!adminToken) return;
    setTestConnectionStatus({ loading: true });
    try {
      const res = await fetch('/api/admin/payments/razorpay/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({
          keyId: paymentForm.keyId || undefined,
          keySecret: paymentForm.keySecret || undefined,
        }),
      });
      const { ok, data, errorMessage } = await parseApiResponse(res);
      if (!ok || !data || data.success === false) {
        throw new Error(errorMessage || data?.error || 'API connection test failed');
      }
      setTestConnectionStatus({ loading: false, success: true, message: data.message || 'Razorpay connection successful' });
    } catch (err: any) {
      setTestConnectionStatus({ loading: false, success: false, message: err?.message || 'API connection test failed' });
    }
  };

  const handleCopyWebhookUrl = () => {
    const url = `${window.location.origin}/api/payments/razorpay/webhook`;
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(url);
      setCopiedWebhookUrl(true);
      setTimeout(() => setCopiedWebhookUrl(false), 2000);
    }
  };

  // Submit Delete Request Handler (Admins can submit, Main Admin approves)
  const handleSubmitDeleteRequest = async (reason: string): Promise<boolean> => {
    if (!deleteRequestTarget) return false;
    try {
      const res = await fetch('/api/admin/delete-requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken || 'admin-session'}`,
        },
        body: JSON.stringify({
          targetType: deleteRequestTarget.type,
          targetId: deleteRequestTarget.id,
          targetSummary: deleteRequestTarget.summary,
          reason,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        alert(`Delete request for ${deleteRequestTarget.type.toUpperCase()} #${deleteRequestTarget.id} submitted successfully and queued for Main Administrator review.`);
        setDeleteRequestTarget(null);
        return true;
      } else {
        alert(data.error || 'Failed to submit delete request.');
        return false;
      }
    } catch (err: any) {
      alert(err?.message || 'Network error submitting request.');
      return false;
    }
  };

  // Dispatch / Courier Partner Update Handler
  const handleSaveDispatchDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dispatchModalOrder) return;
    setDispatchLoading(true);

    try {
      const res = await fetch(`/api/admin/orders/${dispatchModalOrder.orderId}/dispatch`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken || 'admin-session'}`,
        },
        body: JSON.stringify({
          courierPartner: dispatchCourierInput,
          trackingId: dispatchTrackingInput,
          orderStatus: 'shipped',
        }),
      });

      const data = await res.json();
      if (res.ok) {
        updateOrderStatus(dispatchModalOrder.orderId, 'dispatched', {
          courierPartner: dispatchCourierInput,
          trackingId: dispatchTrackingInput,
        });
        setDispatchModalOrder(null);
        alert(`Order #${dispatchModalOrder.orderId} dispatch details updated with ${dispatchCourierInput} (${dispatchTrackingInput}).`);
      } else {
        alert(data.error || 'Failed to update dispatch details.');
      }
    } catch (err: any) {
      alert(err?.message || 'Error updating dispatch details.');
    } finally {
      setDispatchLoading(false);
    }
  };

  // Filter products for the list
  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.category.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.id.toLowerCase().includes(productSearch.toLowerCase())
  );

  // Active Tab Metadata for Topbar & Breadcrumbs (declared before any returns)
  const activeTabMeta = useMemo(() => {
    switch (activeTab) {
      case 'dashboard':
        return { title: 'Dashboard Overview', subtitle: 'Real-time sales KPIs, order pipeline, and quick operational actions', icon: LayoutDashboard };
      case 'products':
        return { title: 'Products Catalog', subtitle: `Manage ${products.length} products, pricing, stock, variants, and descriptions`, icon: Package };
      case 'categories':
        return { title: 'Categories Directory', subtitle: `Organize storefront into ${categories.length} product collections`, icon: FolderPlus };
      case 'inventory':
        return { title: 'Inventory Management', subtitle: 'Stock monitoring, low-stock alerts, and fast inline quantity adjustments', icon: Boxes };
      case 'orders':
        return { title: 'Orders & Dispatch Manager', subtitle: `Process ${orders.length} orders, generate 4×6 thermal labels, and assign tracking`, icon: Truck };
      case 'customers':
        return { title: 'Customer Directory', subtitle: `View ${adminCustomers.length} registered accounts, order histories, and private messaging`, icon: User };
      case 'payments':
        return { title: 'Payment Gateway', subtitle: 'Configure Razorpay API credentials, environment modes, and Cash on Delivery', icon: CreditCard };
      case 'settings':
        return { title: 'Store Settings & GST', subtitle: 'Branding, helpline, tax profile, state GSTIN, and 4×6 label customization', icon: Settings };
      case 'whatsapp':
        return { title: 'WhatsApp & Notifications', subtitle: 'Automated shipment alerts, WhatsApp customer messaging, and template engine', icon: MessageCircle };
      case 'pwa':
        return { title: 'App Install & PWA', subtitle: 'Progressive Web App installation prompt, home-screen manifest, and APK settings', icon: Smartphone };
      case 'reports':
        return { title: 'Reports & Tax Analytics', subtitle: 'Revenue summaries, GST tax breakdown, and instant order CSV export', icon: BarChart3 };
      case 'backup':
        return { title: 'Backup & Data Tools', subtitle: 'Export master JSON snapshots, database restore, and health validation', icon: Database };
      case 'admins':
        return { title: 'Admin Team & Roles', subtitle: 'Staff administration, role permissions (Main Admin vs Sub-Admin), and security', icon: Users };
      case 'delete_requests':
        return { title: 'Delete Requests & Approvals', subtitle: 'Enterprise multi-party authorization workflow for permanent record removal', icon: ShieldCheck };
      case 'audit_logs':
        return { title: 'Security Audit Logs', subtitle: 'Chronological event logging of administrative operations and status changes', icon: FileText };
      case 'coupons':
        return { title: 'Coupons & Discount Engine', subtitle: `Manage ${coupons.length} promotional coupon codes, cart rules, and limits`, icon: Tag };
      case 'flash_sales':
        return { title: 'Flash Sales & Urgency Drops', subtitle: `Manage ${flashSales.length} high-discount limited-time flash drop campaigns`, icon: Flame };
      case 'reviews':
        return { title: 'Customer Reviews Moderation', subtitle: `Moderate and approve ${reviews.length} product buyer ratings & testimonials`, icon: Star };
      case 'returns':
        return { title: 'Returns & Refund Requests', subtitle: `Process ${returns.length} return requests, pickups, and wallet credits`, icon: RotateCcw };
      case 'vendors':
        return { title: 'Multi-Vendor Marketplace', subtitle: `Manage ${vendors.length} vendor partner stores, rates, and commissions`, icon: Store };
      case 'offers':
        return { title: 'Promotional Offers & Banners', subtitle: `Configure ${offers.length} homepage deal cards and campaign copy`, icon: Sparkles };
      case 'integrations':
        return { title: 'Enterprise Integrations & APIs', subtitle: 'Automate Delhivery courier, WhatsApp Cloud API, and transactional email', icon: Globe };
      case 'theme_layout':
        return { title: 'Theme, Layout & Features', subtitle: 'Dark/light mode, brand palette, typography, grid density, and feature toggles', icon: Palette };
      default:
        return { title: 'Admin Console', subtitle: 'INFOSTORS Enterprise Administration', icon: LayoutDashboard };
    }
  }, [activeTab, products.length, categories.length, orders.length, adminCustomers.length, coupons.length, flashSales.length, reviews.length, returns.length, vendors.length, offers.length]);

  // Guard: Do not render if Admin modal is not open (unless running in standalone Admin mode)
  if (!isAdminOpen && !isStandalone) return null;

  // Admin Security Portal Gatekeeper: Restricted to Authorized Accounts
  if (!isAdminAuthenticated) {
    return (
      <div className={isStandalone ? "min-h-screen bg-slate-950 flex items-center justify-center p-4 selection:bg-blue-600 selection:text-white" : "fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200"}>
        <div 
          className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col"
          id="admin-security-login-modal"
        >
          {/* Header */}
          <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900 text-white">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center shadow-md shadow-blue-500/30">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <h2 className="font-extrabold text-sm text-white">Admin Security Portal</h2>
                <p className="text-[10px] text-slate-400">Authorized Personnel Only • Primary & Sub Admins</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 bg-blue-500/20 border border-blue-400/30 text-blue-300 px-2.5 py-1 rounded-full text-[11px] font-bold">
              <Lock className="w-3 h-3 text-blue-400" />
              <span>Restricted Access</span>
            </div>
          </div>

          <div className="p-6 space-y-4">
            {/* Visual Icon */}
            <div className="text-center space-y-1">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-600 flex items-center justify-center mx-auto shadow-inner">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-base text-slate-900">Admin Sign In</h3>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Authentication required to access store configuration, order management, and administrative controls.
              </p>
            </div>

            {/* Mode Switcher */}
            <div className="flex p-1 bg-slate-100 rounded-xl">
              <button
                type="button"
                onClick={() => {
                  setAdminLoginMode('google');
                  setAdminLoginError('');
                }}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  adminLoginMode === 'google'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Google Sign In</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setAdminLoginMode('password');
                  setAdminLoginError('');
                }}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  adminLoginMode === 'password'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Key className="w-3.5 h-3.5" />
                <span>Email & Password</span>
              </button>
            </div>

            {/* Error Alert: ACCESS DENIED Notice */}
            {adminLoginError && (
              <div 
                className="p-3.5 bg-rose-50 border border-rose-300 text-rose-900 text-xs rounded-xl flex items-start gap-2.5 animate-in fade-in"
                id="admin-login-error-alert"
              >
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
                <div className="space-y-0.5">
                  <p className="font-bold leading-tight">{adminLoginError}</p>
                  <p className="text-[11px] text-rose-700">
                    If you require administrative privileges, please request access from the Main Administrator (infostors24@gmail.com).
                  </p>
                </div>
              </div>
            )}

            {/* Mode 1: Google Sign In */}
            {adminLoginMode === 'google' && (
              <div className="space-y-4">
                <div className="p-3 bg-blue-50 border border-blue-200/80 rounded-xl text-xs space-y-1">
                  <span className="font-bold text-blue-950 block">Primary Authorized Admin Account:</span>
                  <div className="flex items-center gap-1.5 font-mono text-[11px] text-blue-900 font-bold bg-white px-2 py-1 rounded border border-blue-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>infostors24@gmail.com</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={async () => {
                    setAdminLoginLoading(true);
                    setAdminLoginError('');
                    const res = await adminGoogleLogin({
                      email: 'infostors24@gmail.com',
                      name: 'INFOSTORS Admin',
                    });
                    setAdminLoginLoading(false);
                    if (!res.success) {
                      setAdminLoginError(res.error || 'Access Denied — This Google account is not authorized as an Admin.');
                    }
                  }}
                  disabled={adminLoginLoading}
                  className="w-full py-3 px-4 bg-white hover:bg-slate-50 text-slate-800 font-bold text-xs rounded-xl border border-slate-300 shadow-xs flex items-center justify-center gap-3 cursor-pointer transition-all hover:shadow-md disabled:opacity-50"
                  id="btn-admin-continue-google"
                >
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>{adminLoginLoading ? 'Verifying with Google...' : 'Continue with Google (infostors24@gmail.com)'}</span>
                </button>

                {/* Test Account Denial Input */}
                <div className="pt-2 border-t border-slate-100">
                  <span className="text-[11px] font-semibold text-slate-500 block mb-1">
                    Verify unauthorized access denial:
                  </span>
                  <div className="flex gap-2">
                    <input
                      type="email"
                      placeholder="e.g. other.user@gmail.com"
                      value={testGoogleEmail}
                      onChange={e => setTestGoogleEmail(e.target.value)}
                      className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-rose-400"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        const testEmail = testGoogleEmail.trim() || 'unauthorized.user@gmail.com';
                        setAdminLoginLoading(true);
                        setAdminLoginError('');
                        const res = await adminGoogleLogin({
                          email: testEmail,
                          name: 'Unauthorized User',
                        });
                        setAdminLoginLoading(false);
                        if (!res.success) {
                          setAdminLoginError(res.error || 'Access Denied — This Google account is not authorized as an Admin.');
                        }
                      }}
                      className="px-3 py-2 bg-slate-100 hover:bg-rose-50 hover:text-rose-700 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 transition-colors cursor-pointer"
                    >
                      Test Denial
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Mode 2: Email & Password */}
            {adminLoginMode === 'password' && (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!adminEmailInput.trim()) {
                    setAdminLoginError('Please enter your authorized admin email or mobile number.');
                    return;
                  }
                  if (!adminPasswordInput) {
                    setAdminLoginError('Please enter your administrator password.');
                    return;
                  }
                  setAdminLoginLoading(true);
                  setAdminLoginError('');
                  const res = await adminEmailPasswordLogin({
                    email: adminEmailInput.trim(),
                    identifier: adminEmailInput.trim(),
                    password: adminPasswordInput,
                    mobile: adminMobileInput.trim() || undefined,
                  });
                  setAdminLoginLoading(false);
                  if (!res.success) {
                    setAdminLoginError(res.error || 'Access Denied — Invalid credentials or unauthorized account.');
                  }
                }}
                className="space-y-3.5 text-xs"
              >
                <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-2xl space-y-1.5">
                  <div className="font-extrabold text-blue-950 text-xs">Administrator sign-in</div>
                  <p className="text-[11px] text-blue-900 leading-relaxed">Use your authorized administrator credentials. Passwords are never displayed, embedded, or auto-filled in the application.</p>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Admin Email or Mobile *</label>
                  <input
                    type="text"
                    required
                    placeholder="infostors24@gmail.com or 8695222581"
                    value={adminEmailInput}
                    onChange={e => setAdminEmailInput(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl outline-none focus:border-blue-500 font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Password *</label>
                  <div className="relative">
                    <input
                      type={showAdminPassword ? 'text' : 'password'}
                      required
                      placeholder="Enter administrator password"
                      value={adminPasswordInput}
                      onChange={e => setAdminPasswordInput(e.target.value)}
                      className="w-full pl-3 pr-10 py-2 border border-slate-300 rounded-xl outline-none focus:border-blue-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowAdminPassword(!showAdminPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    Registered Mobile (Optional 2FA verification)
                  </label>
                  <input
                    type="tel"
                    placeholder="e.g. 8695222581"
                    maxLength={10}
                    value={adminMobileInput}
                    onChange={e => setAdminMobileInput(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl outline-none focus:border-blue-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={adminLoginLoading}
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs cursor-pointer transition-colors disabled:opacity-50"
                >
                  {adminLoginLoading ? 'Authenticating...' : 'Sign In as Admin'}
                </button>
              </form>
            )}

            {/* Enterprise Security Footer */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span className="text-[11px] font-medium">INFOSTORS Enterprise Administration</span>
              <span className="font-mono text-[10px] text-slate-400 font-bold bg-slate-100 px-2 py-0.5 rounded">v5.2 Secure</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const NAV_SECTIONS = [
    {
      title: 'Analytics & Overview',
      items: [
        { id: 'dashboard' as const, label: 'Dashboard', icon: LayoutDashboard },
        { id: 'reports' as const, label: 'Reports & Tax', icon: BarChart3 },
      ],
    },
    {
      title: 'Catalog & Inventory',
      items: [
        { id: 'products' as const, label: 'Products', icon: Package, count: products.length },
        { id: 'categories' as const, label: 'Categories', icon: FolderPlus, count: categories.length },
        { id: 'inventory' as const, label: 'Inventory', icon: Boxes, alert: products.some(p => p.stock < 5) },
      ],
    },
    {
      title: 'Orders & Customers',
      items: [
        { id: 'orders' as const, label: 'Orders & Dispatch', icon: Truck, count: orders.length },
        { id: 'customers' as const, label: 'Customers', icon: User, count: adminCustomers.length },
        { id: 'payments' as const, label: 'Payment Gateway', icon: CreditCard, alert: paymentSettings?.isConfigured },
      ],
    },
    {
      title: 'Marketing & Sales',
      items: [
        { id: 'coupons' as const, label: 'Coupons & Discounts', icon: Tag, count: coupons.length },
        { id: 'flash_sales' as const, label: 'Flash Sales', icon: Flame, pulse: flashSales.some(f => f.isActive) },
        { id: 'offers' as const, label: 'Promotional Offers', icon: Sparkles, count: offers.length },
        { id: 'reviews' as const, label: 'Reviews Moderation', icon: Star, count: reviews.length },
        { id: 'returns' as const, label: 'Returns & Refunds', icon: RotateCcw, alert: returns.some(r => r.status === 'requested') },
        { id: 'vendors' as const, label: 'Vendors (Multi-Store)', icon: Store, count: vendors.length },
      ],
    },
    {
      title: 'Storefront & Design',
      items: [
        { id: 'theme_layout' as const, label: 'Theme & Features', icon: Palette },
        { id: 'integrations' as const, label: 'APIs & Logistics', icon: Globe },
        { id: 'settings' as const, label: 'Store Settings & GST', icon: Settings },
        { id: 'pwa' as const, label: 'App Install / PWA', icon: Smartphone },
      ],
    },
    {
      title: 'Operations & Alerts',
      items: [
        { id: 'whatsapp' as const, label: 'WhatsApp & Alerts', icon: MessageCircle, pulse: true },
      ],
    },
    {
      title: 'Security & Control',
      items: [
        { id: 'admins' as const, label: 'Manage Admins', icon: Users },
        { id: 'delete_requests' as const, label: 'Delete Requests', icon: ShieldCheck },
        { id: 'audit_logs' as const, label: 'Audit Logs', icon: FileText },
        { id: 'backup' as const, label: 'Backup & Data Tools', icon: Database },
      ],
    },
  ];

  const QUICK_TABS = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'orders' as const, label: 'Orders', icon: Truck, count: orders.length },
    { id: 'products' as const, label: 'Products', icon: Package, count: products.length },
    { id: 'inventory' as const, label: 'Inventory', icon: Boxes },
    { id: 'customers' as const, label: 'Customers', icon: User },
    { id: 'whatsapp' as const, label: 'WhatsApp', icon: MessageCircle },
    { id: 'settings' as const, label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen h-screen w-full bg-slate-950 text-slate-100 flex flex-col antialiased selection:bg-blue-600 selection:text-white overflow-hidden">
      
      {/* ================= MOBILE SLIDE-OVER DRAWER ================= */}
      {isMobileNavOpen && (
        <div className="fixed inset-0 z-50 lg:hidden bg-slate-950/80 backdrop-blur-xs flex animate-in fade-in duration-200">
          <div className="w-72 max-w-[85vw] bg-slate-950 text-slate-200 h-full flex flex-col border-r border-slate-800 shadow-2xl p-4 space-y-4 animate-in slide-in-from-left duration-250 select-none">
            {/* Mobile Drawer Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-white tracking-tight">INFOSTORS</h3>
                  <p className="text-[10px] text-slate-400">Enterprise Administration</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsMobileNavOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Admin Profile Card in Drawer */}
            <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800/80 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs border border-blue-500/30 shrink-0">
                {adminProfile?.email?.charAt(0).toUpperCase() || 'A'}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold text-white truncate">{adminProfile?.email || 'infostors24@gmail.com'}</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-[10px] text-emerald-400 font-medium capitalize">
                    {adminProfile?.role === 'main_admin' ? 'Primary Main Admin' : 'Admin'}
                  </span>
                </div>
              </div>
            </div>

            {/* Mobile Nav Links */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-1">
              {NAV_SECTIONS.map((section, sIdx) => (
                <div key={sIdx} className="space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-2">
                    {section.title}
                  </p>
                  <div className="space-y-0.5">
                    {section.items.map((item) => {
                      const Icon = item.icon;
                      const isActive = activeTab === item.id;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => handleSelectTab(item.id)}
                          className={`w-full px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition cursor-pointer ${
                            isActive
                              ? 'bg-blue-600 text-white shadow-xs'
                              : 'text-slate-300 hover:text-white hover:bg-slate-900'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                            <span className="truncate">{item.label}</span>
                          </div>
                          {'count' in item && typeof item.count === 'number' && (
                            <span className={`text-[10px] font-extrabold px-1.5 py-0.2 rounded-full ${
                              isActive ? 'bg-blue-700 text-white' : 'bg-slate-800 text-slate-300'
                            }`}>
                              {item.count}
                            </span>
                          )}
                          {'alert' in item && item.alert && (
                            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse shrink-0" />
                          )}
                          {'pulse' in item && item.pulse && (
                            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            {/* Mobile Drawer Logout */}
            <div className="pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={adminLogout}
                className="w-full py-2 px-3 text-xs font-bold text-rose-300 hover:text-white hover:bg-rose-600/30 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout Admin</span>
              </button>
            </div>
          </div>
          <div className="flex-1" onClick={() => setIsMobileNavOpen(false)} />
        </div>
      )}

      {/* ================= MAIN LAYOUT FRAME ================= */}
      <div className="flex-1 flex flex-col lg:flex-row h-full overflow-hidden">
        
        {/* ================= DESKTOP SIDEBAR ================= */}
        <aside className="hidden lg:flex w-64 xl:w-72 bg-slate-950 text-slate-300 border-r border-slate-800 flex-col shrink-0 h-full select-none">
          {/* Logo & Brand */}
          <div className="p-4 xl:p-5 border-b border-slate-800/80 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/25 shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h1 className="font-black text-sm xl:text-base text-white tracking-tight">INFOSTORS</h1>
                <span className="text-[9px] font-bold bg-blue-500/20 text-blue-300 border border-blue-400/20 px-1.5 py-0.2 rounded">PRO</span>
              </div>
              <p className="text-[10.5px] text-slate-400 truncate">Ecommerce Administration</p>
            </div>
          </div>

          {/* Admin User Profile Pill */}
          <div className="px-4 py-3 mx-3 my-2.5 bg-slate-900/90 rounded-2xl border border-slate-800/90 flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-blue-600/30 text-blue-400 font-bold flex items-center justify-center text-xs border border-blue-500/30 shrink-0">
              {adminProfile?.email?.charAt(0).toUpperCase() || 'A'}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-white truncate">{adminProfile?.email || 'infostors24@gmail.com'}</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-[10px] text-emerald-400 font-medium capitalize truncate">
                  {adminProfile?.role === 'main_admin' ? 'Primary Main Admin' : 'Administrator'}
                </span>
              </div>
            </div>
          </div>

          {/* Categorized Navigation Menu */}
          <nav className="flex-1 overflow-y-auto px-3 py-2 space-y-4 pr-1.5" aria-label="Admin Navigation">
            {NAV_SECTIONS.map((section, sIdx) => (
              <div key={sIdx} className="space-y-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-2.5">
                  {section.title}
                </p>
                <div className="space-y-0.5">
                  {section.items.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleSelectTab(item.id)}
                        className={`w-full px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition cursor-pointer ${
                          isActive
                            ? 'bg-blue-600 text-white shadow-sm'
                            : 'text-slate-300 hover:text-white hover:bg-slate-900'
                        }`}
                        id={`admin-nav-${item.id}`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                          <span className="truncate">{item.label}</span>
                        </div>
                        {'count' in item && typeof item.count === 'number' && (
                          <span className={`text-[10px] font-extrabold px-1.5 py-0.2 rounded-full ${
                            isActive ? 'bg-blue-700 text-white' : 'bg-slate-800 text-slate-300'
                          }`}>
                            {item.count}
                          </span>
                        )}
                        {'alert' in item && item.alert && (
                          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse shrink-0" />
                        )}
                        {'pulse' in item && item.pulse && (
                          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </nav>

          {/* Sidebar Footer Status & Logout */}
          <div className="p-3 border-t border-slate-800/80 space-y-2">
            <div className="p-2 bg-slate-900/60 rounded-xl border border-slate-800/60 flex items-center justify-between text-[10px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span>Primary Database</span>
              </span>
              <span className="font-mono text-emerald-400 font-bold">Online</span>
            </div>

            <button
              type="button"
              onClick={adminLogout}
              className="w-full py-2 px-3 text-xs font-bold text-rose-300 hover:text-white hover:bg-rose-600/30 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
              title="Logout Admin"
              id="btn-admin-logout"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout Admin Session</span>
            </button>
          </div>
        </aside>

        {/* ================= MAIN CONTENT WORKSPACE ================= */}
        <main className="flex-1 flex flex-col min-w-0 bg-slate-100/70 overflow-hidden">
          
          {/* Top Bar Header */}
          <header className="bg-slate-900 text-white px-3 sm:px-6 py-2.5 sm:py-3 border-b border-slate-800 flex items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              {/* Mobile Menu Toggle Button */}
              <button
                type="button"
                onClick={() => setIsMobileNavOpen(true)}
                className="p-1.5 -ml-1 text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl lg:hidden transition cursor-pointer"
                title="Open Navigation Menu"
                aria-label="Open Navigation Menu"
              >
                <Menu className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-blue-600/30 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/20">
                  <activeTabMeta.icon className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h2 className="font-extrabold text-xs sm:text-sm text-white tracking-tight truncate">
                    {activeTabMeta.title}
                  </h2>
                  <p className="text-[10px] sm:text-[11px] text-slate-400 truncate hidden sm:block">
                    {activeTabMeta.subtitle}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Status Pill & Mobile Logout */}
            <div className="flex items-center gap-2 shrink-0">
              <div className="hidden md:flex items-center gap-2 text-xs">
                <span className="font-mono text-[11px] bg-slate-800 text-slate-300 px-2 py-1 rounded-lg border border-slate-700">
                  📦 {products.length} Products
                </span>
                <span className="font-mono text-[11px] bg-slate-800 text-slate-300 px-2 py-1 rounded-lg border border-slate-700">
                  🚚 {orders.length} Orders
                </span>
              </div>

              <div className="hidden sm:flex items-center gap-1.5 bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 px-2.5 py-1 rounded-full text-xs font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="truncate max-w-[140px]">{adminProfile?.email || 'infostors24@gmail.com'}</span>
              </div>

              <button
                type="button"
                onClick={adminLogout}
                className="p-1.5 sm:px-2.5 sm:py-1 text-xs font-bold text-rose-300 hover:text-white hover:bg-rose-600/30 rounded-xl transition flex items-center gap-1 cursor-pointer"
                title="Logout"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </header>

          {/* Quick-Action Chips for Small Screens / Mobile (< lg) */}
          <div className="lg:hidden bg-slate-900 border-b border-slate-800 px-3 py-1.5 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
            {QUICK_TABS.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => handleSelectTab(tab.id)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap flex items-center gap-1 transition cursor-pointer ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/60'
                  }`}
                >
                  <Icon className="w-3 h-3" />
                  <span>{tab.label}</span>
                  {'count' in tab && typeof tab.count === 'number' && (
                    <span className="text-[9px] font-extrabold px-1 rounded-full bg-slate-950/40">
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Tab Content Body (Scrollable, full height, responsive) */}
          <div className="flex-1 overflow-y-auto p-3 sm:p-5 lg:p-6 space-y-5 min-w-0">

          {/* ==================== TAB 0: DASHBOARD ==================== */}
          {activeTab === 'dashboard' && (
            <AdminDashboardTab
              orders={orders}
              products={products}
              categories={categories}
              customers={adminCustomers}
              storeSettings={storeSettings}
              paymentSettings={paymentSettings}
              onNavigateTab={(tab) => {
                setActiveTab(tab);
                setIsCreatingProduct(false);
                setEditingProduct(null);
              }}
              onSelectShippingLabel={(order) => setSelectedShippingLabelOrder(order)}
              onSelectInvoice={(order) => setSelectedInvoiceOrder(order)}
              onOpenDispatchModal={(order) => {
                setDispatchModalOrder(order);
                setDispatchCourierInput(order.courierPartner || 'Delhivery Express');
                setDispatchTrackingInput(order.trackingId || '');
              }}
              onOpenWhatsAppModal={(order) => setSelectedWhatsAppOrder(order)}
            />
          )}

          {/* ==================== TAB: INVENTORY ==================== */}
          {activeTab === 'inventory' && (
            <AdminInventoryTab
              products={products}
              updateProduct={updateProduct}
              onNavigateProducts={() => {
                setActiveTab('products');
                setIsCreatingProduct(false);
                setEditingProduct(null);
              }}
            />
          )}

          {/* ==================== TAB 1: PRODUCTS ==================== */}
          {activeTab === 'products' && (
            <div>
              {!isCreatingProduct && !editingProduct ? (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="relative flex-1 max-w-md">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={productSearch}
                        onChange={e => setProductSearch(e.target.value)}
                        placeholder="Search products by name, category or ID..."
                        className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    <button
                      onClick={handleStartCreateProduct}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add New Product</span>
                    </button>
                  </div>

                  <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 bg-white shadow-xs">
                    {filteredProducts.map(p => (
                      <div key={p.id} className="p-3.5 flex items-center justify-between gap-4 hover:bg-slate-50 transition-colors">
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={p.image}
                            alt=""
                            className="w-12 h-12 object-contain bg-slate-50 rounded-lg border border-slate-200 p-1 shrink-0"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-xs text-slate-900 truncate">
                                {p.name}
                              </span>
                              {p.badge && (
                                <span className="text-[9px] bg-blue-50 text-blue-700 font-bold px-1.5 py-0.2 rounded border border-blue-200">
                                  {p.badge}
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-500 flex flex-wrap items-center gap-2 mt-0.5">
                              <span className="capitalize font-medium text-slate-600">{p.category}</span>
                              <span>•</span>
                              <span className="font-bold text-slate-900">₹{p.price}</span>
                              <span className="line-through text-slate-400">₹{p.originalPrice}</span>
                              <span>•</span>
                              <span className="text-emerald-700 font-semibold">{p.stock} in stock</span>
                              <span>•</span>
                              <span className="text-slate-400 font-mono text-[10px]">ID: {p.id}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            onClick={() => handleStartEditProduct(p)}
                            className="p-2 text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                            title="Edit product"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => deleteProduct(p.id)}
                            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Delete product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                /* Product Edit / Add Form */
                <form onSubmit={handleSaveProduct} className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <h3 className="font-bold text-sm text-slate-900">
                      {editingProduct ? `Edit: ${editingProduct.name}` : 'Add New Product to INFOSTORS'}
                    </h3>
                    <button
                      type="button"
                      onClick={() => {
                        setIsCreatingProduct(false);
                        setEditingProduct(null);
                      }}
                      className="text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Product Title *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name || ''}
                        onChange={e => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                        placeholder="e.g. UltraFast GaN 100W Laptop Charger"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Category *
                      </label>
                      <select
                        value={formData.category}
                        onChange={e => setFormData({ ...formData, category: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                      >
                        {categories.filter(c => c.id !== 'all').map(cat => (
                          <option key={cat.id} value={cat.id}>
                            {cat.emoji} {cat.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Brand Name
                      </label>
                      <input
                        type="text"
                        value={formData.brand || ''}
                        onChange={e => setFormData({ ...formData, brand: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Selling Price (₹) *
                      </label>
                      <input
                        type="number"
                        required
                        value={formData.price || ''}
                        onChange={e => setFormData({ ...formData, price: Number(e.target.value) })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Original MRP (₹) *
                      </label>
                      <input
                        type="number"
                        required
                        value={formData.originalPrice || ''}
                        onChange={e => setFormData({ ...formData, originalPrice: Number(e.target.value) })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Available Stock Count
                      </label>
                      <input
                        type="number"
                        value={formData.stock || 20}
                        onChange={e => setFormData({ ...formData, stock: Number(e.target.value) })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Badge Label (e.g. BESTSELLER, 40% OFF)
                      </label>
                      <input
                        type="text"
                        value={formData.badge || ''}
                        onChange={e => setFormData({ ...formData, badge: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    {/* 4 Product Image URL Fields with Open Link */}
                    <div className="sm:col-span-2 space-y-3.5 p-4 bg-slate-50/90 rounded-2xl border border-slate-200" id="admin-product-images-panel">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-2.5 border-b border-slate-200">
                        <div>
                          <label className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                            <ImageIcon className="w-4 h-4 text-blue-600" />
                            <span>Product Image URLs (4 Image Slots with Open Link)</span>
                          </label>
                          <span className="text-[11px] text-slate-500 block mt-0.5">
                            Provide image links for product gallery. If only 2 images are provided, only those 2 images will be shown and empty image boxes are completely hidden.
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 self-start sm:self-auto">
                          <span className="text-[11px] font-bold text-blue-700 bg-blue-100/70 border border-blue-200 px-2.5 py-0.5 rounded-full shrink-0">
                            {productImages.filter(u => u && u.trim().length > 0).length} of 4 images set
                          </span>
                        </div>
                      </div>

                      {/* 4 Image URL Input Slots */}
                      <div className="space-y-2.5">
                        {[
                          { index: 0, label: 'Image 1 URL (Primary / Main Display)', required: true, placeholder: 'https://images.unsplash.com/... (Main product photo)' },
                          { index: 1, label: 'Image 2 URL (Gallery Angle 2 - Optional)', required: false, placeholder: 'https://images.unsplash.com/... (Side view / perspective)' },
                          { index: 2, label: 'Image 3 URL (Gallery Angle 3 - Optional)', required: false, placeholder: 'https://images.unsplash.com/... (Close-up / feature view)' },
                          { index: 3, label: 'Image 4 URL (Gallery Angle 4 - Optional)', required: false, placeholder: 'https://images.unsplash.com/... (Packaging / accessories)' },
                        ].map(slot => {
                          const currentUrl = productImages[slot.index] || '';
                          const isFilled = currentUrl.trim().length > 0;

                          return (
                            <div key={slot.index} className="space-y-1">
                              <div className="flex items-center justify-between">
                                <label className="text-[11px] font-semibold text-slate-700">
                                  {slot.label} {slot.required && <span className="text-rose-500">*</span>}
                                </label>
                                {isFilled ? (
                                  <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-1">
                                    <Check className="w-3 h-3" />
                                    Link Ready
                                  </span>
                                ) : (
                                  <span className="text-[10px] text-slate-400">
                                    {slot.required ? 'Required' : 'Empty (hidden in gallery)'}
                                  </span>
                                )}
                              </div>

                              <div className="flex items-center gap-2">
                                {/* Thumbnail preview if URL is provided */}
                                <div className="w-9 h-9 rounded-lg border border-slate-200 bg-white flex items-center justify-center overflow-hidden shrink-0 shadow-2xs">
                                  {isFilled ? (
                                    <img
                                      src={currentUrl.trim()}
                                      alt=""
                                      className="w-full h-full object-contain"
                                      onError={e => {
                                        (e.currentTarget as HTMLElement).style.display = 'none';
                                      }}
                                    />
                                  ) : (
                                    <ImageIcon className="w-4 h-4 text-slate-300" />
                                  )}
                                </div>

                                {/* URL Input */}
                                <input
                                  type="url"
                                  value={currentUrl}
                                  onChange={e => {
                                    const next = [...productImages];
                                    next[slot.index] = e.target.value;
                                    setProductImages(next);
                                  }}
                                  placeholder={slot.placeholder}
                                  className="flex-1 px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 shadow-2xs font-mono"
                                  id={`admin-image-url-input-${slot.index + 1}`}
                                />

                                {/* Open Link Option */}
                                {isFilled ? (
                                  <a
                                    href={currentUrl.trim()}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="px-3 py-2 text-xs font-bold rounded-xl border flex items-center gap-1.5 transition-all shrink-0 bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200 hover:border-blue-300 shadow-2xs cursor-pointer active:scale-95"
                                    title={`Open ${slot.label} in new browser tab`}
                                    id={`admin-open-link-btn-${slot.index + 1}`}
                                  >
                                    <ExternalLink className="w-3.5 h-3.5" />
                                    <span className="hidden sm:inline">Open Link</span>
                                  </a>
                                ) : (
                                  <span
                                    className="px-3 py-2 text-xs font-bold rounded-xl border flex items-center gap-1.5 transition-all shrink-0 bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed opacity-50"
                                    title="Enter a URL first to open link"
                                    id={`admin-open-link-btn-${slot.index + 1}`}
                                  >
                                    <ExternalLink className="w-3.5 h-3.5" />
                                    <span className="hidden sm:inline">Open Link</span>
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Display ONLY provided images (if only 2 images are provided, display only those 2 images and hide empty image boxes) */}
                      <div className="pt-3 border-t border-slate-200">
                        <div className="flex items-center justify-between text-[11px] mb-2">
                          <span className="font-bold text-slate-700 flex items-center gap-1">
                            <span>Live Gallery Display</span>
                            <span className="text-slate-400 font-normal">
                              ({productImages.filter(u => u && u.trim().length > 0).length} active image{productImages.filter(u => u && u.trim().length > 0).length === 1 ? '' : 's'})
                            </span>
                          </span>
                          <span className="text-[10px] text-slate-500 font-medium">
                            Empty image boxes are automatically hidden
                          </span>
                        </div>

                        {productImages.filter(u => u && u.trim().length > 0).length > 0 ? (
                          <div className="flex items-center gap-3 overflow-x-auto pb-1" id="admin-gallery-previews">
                            {productImages
                              .map((url, origIdx) => ({ url: (url || '').trim(), origIdx }))
                              .filter(item => item.url.length > 0)
                              .map((item) => (
                                <div
                                  key={item.origIdx}
                                  className="relative group w-20 h-20 rounded-xl border-2 border-blue-500/30 bg-white p-1 shadow-2xs shrink-0 flex flex-col items-center justify-center overflow-hidden"
                                >
                                  <img
                                    src={item.url}
                                    alt={`Image ${item.origIdx + 1}`}
                                    className="w-full h-full object-contain"
                                    onError={e => {
                                      (e.currentTarget as HTMLElement).style.opacity = '0.3';
                                    }}
                                  />
                                  <span className="absolute bottom-1 left-1 right-1 text-center bg-slate-900/85 backdrop-blur-xs text-white text-[9px] font-bold py-0.5 rounded px-1 truncate">
                                    {item.origIdx === 0 ? 'Primary' : `Image ${item.origIdx + 1}`}
                                  </span>

                                  {/* Quick Open Link Overlay Button */}
                                  <a
                                    href={item.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="absolute inset-0 bg-blue-900/75 text-white opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center gap-0.5 transition-opacity cursor-pointer p-1"
                                    title="Open link in new tab"
                                  >
                                    <ExternalLink className="w-3.5 h-3.5" />
                                    <span className="text-[9px] font-bold">Open Link</span>
                                  </a>
                                </div>
                              ))}
                          </div>
                        ) : (
                          <div className="text-[11px] text-slate-400 italic py-2 px-3 bg-white/60 rounded-xl border border-dashed border-slate-200 text-center">
                            No image URLs entered yet. Enter at least one image URL above.
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Short Description
                      </label>
                      <input
                        type="text"
                        value={formData.shortDescription || ''}
                        onChange={e => setFormData({ ...formData, shortDescription: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Full Description
                      </label>
                      <textarea
                        rows={3}
                        value={formData.description || ''}
                        onChange={e => setFormData({ ...formData, description: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    {/* Flags */}
                    <div className="sm:col-span-2 flex flex-wrap gap-4 pt-1 text-xs">
                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.isTrending || false}
                          onChange={e => setFormData({ ...formData, isTrending: e.target.checked })}
                          className="accent-blue-600"
                        />
                        <span>🔥 Trending</span>
                      </label>

                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.isBestseller || false}
                          onChange={e => setFormData({ ...formData, isBestseller: e.target.checked })}
                          className="accent-blue-600"
                        />
                        <span>⭐ Best Seller</span>
                      </label>

                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.isNewArrival || false}
                          onChange={e => setFormData({ ...formData, isNewArrival: e.target.checked })}
                          className="accent-blue-600"
                        />
                        <span>🆕 New Arrival</span>
                      </label>

                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.isDeal || false}
                          onChange={e => setFormData({ ...formData, isDeal: e.target.checked })}
                          className="accent-blue-600"
                        />
                        <span>💥 Deal of the Day</span>
                      </label>
                    </div>
                  </div>

                  <div className="pt-4 flex justify-end gap-2 border-t border-slate-200">
                    <button
                      type="button"
                      onClick={() => {
                        setIsCreatingProduct(false);
                        setEditingProduct(null);
                      }}
                      className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
                    >
                      Save Product
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* ==================== TAB 2: CATEGORIES (Add More Categories Option) ==================== */}
          {activeTab === 'categories' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">
                    Store Categories Management
                  </h3>
                  <p className="text-xs text-slate-500">
                    Add new categories, edit names, icons and organize your catalog
                  </p>
                </div>

                {!isCreatingCategory && !editingCategory && (
                  <button
                    onClick={handleStartCreateCategory}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add New Category</span>
                  </button>
                )}
              </div>

              {/* Form to Add / Edit Category */}
              {(isCreatingCategory || editingCategory) ? (
                <form onSubmit={handleSaveCategory} className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                    <h4 className="text-xs font-bold text-slate-900 flex items-center gap-2">
                      <FolderPlus className="w-4 h-4 text-blue-600" />
                      <span>{editingCategory ? `Edit Category: ${editingCategory.name}` : 'Add More Category Option'}</span>
                    </h4>
                    <button
                      type="button"
                      onClick={() => {
                        setIsCreatingCategory(false);
                        setEditingCategory(null);
                      }}
                      className="text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Category Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={categoryFormData.name}
                        onChange={e => {
                          const val = e.target.value;
                          setCategoryFormData(prev => ({
                            ...prev,
                            name: val,
                            id: editingCategory ? prev.id : val.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-'),
                          }));
                        }}
                        placeholder="e.g. Smart Watches & Wearables"
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Category Identifier (Slug / ID) *
                      </label>
                      <input
                        type="text"
                        required
                        disabled={editingCategory?.id === 'all'}
                        value={categoryFormData.id}
                        onChange={e => setCategoryFormData({ ...categoryFormData, id: e.target.value })}
                        placeholder="e.g. smart-watches"
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500 disabled:opacity-50"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Category Icon / Emoji
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={categoryFormData.emoji}
                          onChange={e => setCategoryFormData({ ...categoryFormData, emoji: e.target.value })}
                          placeholder="⌚"
                          className="w-16 px-3 py-2 text-base text-center bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500"
                        />
                        <span className="text-[11px] text-slate-500">
                          Paste any emoji (e.g. ⌚, 🎮, 🔊, 💡, 🍳)
                        </span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Banner / Representative Image URL
                      </label>
                      <input
                        type="url"
                        value={categoryFormData.bannerImage || ''}
                        onChange={e => setCategoryFormData({ ...categoryFormData, bannerImage: e.target.value })}
                        placeholder="https://images.unsplash.com/..."
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Category Description
                      </label>
                      <input
                        type="text"
                        value={categoryFormData.description}
                        onChange={e => setCategoryFormData({ ...categoryFormData, description: e.target.value })}
                        placeholder="Brief summary of items in this category"
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsCreatingCategory(false);
                        setEditingCategory(null);
                      }}
                      className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{editingCategory ? 'Update Category' : 'Save Category'}</span>
                    </button>
                  </div>
                </form>
              ) : null}

              {/* Categories List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {categories.map(cat => {
                  const productCount = cat.id === 'all' 
                    ? products.length 
                    : products.filter(p => p.category === cat.id).length;

                  return (
                    <div 
                      key={cat.id} 
                      className="bg-white border border-slate-200 rounded-2xl p-4 flex items-center justify-between gap-3 shadow-xs hover:border-slate-300 transition-all"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-xl shrink-0 border border-slate-200/80">
                          {cat.emoji}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-slate-900 truncate">
                              {cat.name}
                            </span>
                            {cat.id === 'all' && (
                              <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-semibold">
                                System
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500 truncate">
                            {cat.description || 'No description provided'}
                          </p>
                          <div className="text-[10px] text-blue-600 font-semibold mt-0.5">
                            {productCount} product{productCount !== 1 ? 's' : ''} • ID: <code className="text-slate-500 font-mono">{cat.id}</code>
                          </div>
                        </div>
                      </div>

                      {cat.id !== 'all' && (
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => handleStartEditCategory(cat)}
                            className="p-1.5 text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                            title="Edit Category"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          {categoryToDeleteId === cat.id ? (
                            <div className="flex items-center gap-1 bg-rose-50 p-0.5 rounded-lg border border-rose-200 animate-in fade-in">
                              <button
                                type="button"
                                onClick={() => {
                                  deleteCategory(cat.id);
                                  setCategoryToDeleteId(null);
                                }}
                                className="px-2 py-0.5 text-[10px] font-bold bg-rose-600 text-white rounded cursor-pointer hover:bg-rose-700"
                              >
                                Delete
                              </button>
                              <button
                                type="button"
                                onClick={() => setCategoryToDeleteId(null)}
                                className="px-1.5 py-0.5 text-[10px] font-semibold text-slate-500 hover:text-slate-700 cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setCategoryToDeleteId(cat.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title="Delete Category"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ==================== TAB 3: ORDERS & PACKAGE STATUS (Received - Dispatched - Delivered) ==================== */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">
                    Customer Orders & Package Status Dispatcher
                  </h3>
                  <p className="text-xs text-slate-500">
                    Control shipment lifecycle: <strong>Received → Dispatched → Delivered</strong> or <strong>Cancelled / Void</strong>
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full border border-blue-200">
                    {filteredOrders.length} of {orders.length} Orders
                  </span>
                </div>
              </div>

              {/* Order Search & Status Filter Controls */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-2.5">
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Search by Order ID, customer name, phone, city, or tracking ID..."
                      value={orderSearchQuery}
                      onChange={e => setOrderSearchQuery(e.target.value)}
                      className="w-full pl-9 pr-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    />
                    {orderSearchQuery && (
                      <button
                        type="button"
                        onClick={() => setOrderSearchQuery('')}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
                      >
                        ×
                      </button>
                    )}
                  </div>
                  <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
                    {(['all', 'received', 'dispatched', 'delivered', 'cancelled'] as const).map(statusKey => (
                      <button
                        key={statusKey}
                        type="button"
                        onClick={() => setOrderStatusFilter(statusKey)}
                        className={`px-3 py-1 rounded-lg text-xs font-bold capitalize transition-all cursor-pointer whitespace-nowrap ${
                          orderStatusFilter === statusKey
                            ? 'bg-blue-600 text-white shadow-xs'
                            : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                        }`}
                      >
                        {statusKey === 'all' ? 'All' : statusKey}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {orders.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <Package className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-bold text-slate-700">No Orders in Store Yet</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    When customers check out, their orders appear here for status tracking
                  </p>
                </div>
              ) : filteredOrders.length === 0 ? (
                <div className="text-center py-10 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <Search className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-bold text-slate-700">No matching orders found</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Try clearing your search query or status filter
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setOrderSearchQuery('');
                      setOrderStatusFilter('all');
                    }}
                    className="mt-3 text-xs font-bold text-blue-600 hover:text-blue-700 bg-white border border-blue-200 px-3 py-1 rounded-lg shadow-xs cursor-pointer"
                  >
                    Reset Filters
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredOrders.map(order => (
                    <div
                      key={order.orderId}
                      className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-xs"
                    >
                      {/* Order Header */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-black text-sm text-slate-900">
                              #{order.orderId}
                            </span>
                            <span className="text-slate-300">•</span>
                            <span className="text-xs text-slate-500">
                              {new Date(order.date).toLocaleString('en-IN', {
                                day: 'numeric',
                                month: 'short',
                                year: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>

                            {/* Payment Method Badge */}
                            {order.paymentMethod === 'razorpay' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-full">
                                <CreditCard className="w-3 h-3" />
                                Razorpay
                              </span>
                            ) : order.paymentMethod === 'upi' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                                <Smartphone className="w-3 h-3" />
                                UPI
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
                                <Banknote className="w-3 h-3" />
                                COD
                              </span>
                            )}

                            {/* Payment Status Badge */}
                            {order.paymentStatus === 'paid' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-black text-emerald-800 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-full">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                PAID
                              </span>
                            ) : order.paymentStatus === 'failed' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-800 bg-rose-100 border border-rose-300 px-2 py-0.5 rounded-full">
                                FAILED
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-800 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-full">
                                PENDING
                              </span>
                            )}
                          </div>

                          <div className="text-xs text-slate-700 mt-1 flex items-center gap-2 flex-wrap">
                            <span>Customer: <strong>{order.customer.fullName}</strong> ({order.customer.phone}) • {order.customer.city}, {order.customer.state}</span>
                            {order.razorpayPaymentId && (
                              <span className="font-mono text-[10px] text-slate-500 bg-slate-50 border border-slate-200 px-1.5 py-0.5 rounded">
                                Pay ID: {order.razorpayPaymentId}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Status selector buttons */}
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[11px] font-semibold text-slate-400 mr-1">
                            Set Status:
                          </span>

                          <button
                            onClick={() => updateOrderStatus(order.orderId, 'received')}
                            className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                              order.status === 'received'
                                ? 'bg-blue-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            📥 Received
                          </button>

                          <button
                            onClick={() => updateOrderStatus(order.orderId, 'dispatched')}
                            className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                              order.status === 'dispatched'
                                ? 'bg-amber-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            🚚 Dispatched
                          </button>

                          <button
                            onClick={() => updateOrderStatus(order.orderId, 'delivered')}
                            className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                              order.status === 'delivered'
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            ✓ Delivered
                          </button>

                          {/* Cancel Invalid / Test / Spam Order */}
                          <button
                            type="button"
                            onClick={() => {
                              const reason = window.prompt(
                                `Enter cancellation / void reason for Order #${order.orderId} (e.g., Fake order, Duplicate entry, Spam bot, Customer requested cancellation):`,
                                'Cancelled / Voided by Administrator'
                              );
                              if (reason) {
                                updateOrderStatus(order.orderId, 'received', {
                                  resolution: `CANCELLED: ${reason.trim()}`
                                });
                                setOrderActionFeedback({
                                  orderId: order.orderId,
                                  type: 'success',
                                  message: `Order #${order.orderId} marked as Cancelled (${reason.trim()}).`
                                });
                              }
                            }}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 flex items-center gap-1"
                            title="Cancel / Void this order and record reason"
                          >
                            <Ban className="w-3.5 h-3.5 text-rose-500" />
                            <span>Cancel</span>
                          </button>

                          {/* Customer WhatsApp Notification */}
                          <button
                            type="button"
                            onClick={() => setSelectedWhatsAppOrder(order)}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-300 flex items-center gap-1"
                            title="Send professional WhatsApp update to customer"
                          >
                            <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                            <span>WhatsApp</span>
                          </button>

                          {/* 4x6 Thermal Shipping Label with Barcode & Data Matrix */}
                          <button
                            type="button"
                            onClick={() => setSelectedShippingLabelOrder(order)}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200 flex items-center gap-1"
                            title="Generate 4x6 Thermal Shipping Label with Code 128 Barcode & Data Matrix"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Label (4×6)</span>
                          </button>

                          {/* GST Tax Invoice */}
                          <button
                            type="button"
                            onClick={() => setSelectedInvoiceOrder(order)}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-300 flex items-center gap-1"
                            title="Generate & Print GST Tax Invoice"
                          >
                            <FileText className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Invoice</span>
                          </button>

                          {/* Courier Partner & Tracking Update */}
                          <button
                            type="button"
                            onClick={() => {
                              setDispatchModalOrder(order);
                              setDispatchCourierInput(order.courierPartner || 'Delhivery Express');
                              setDispatchTrackingInput(order.trackingId || `TRK${order.orderId.replace(/\D/g, '').slice(-8)}IN`);
                            }}
                            className="px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300 flex items-center gap-1"
                            title="Update Courier Partner and Tracking Number"
                          >
                            <Truck className="w-3.5 h-3.5" />
                            <span>Courier</span>
                          </button>

                          {/* Request Deletion (Multi-Party Safe Workflow) */}
                          <button
                            type="button"
                            onClick={() => setDeleteRequestTarget({
                              type: 'order',
                              id: order.orderId,
                              summary: `${order.customer.fullName} - ₹${order.totalAmount} (${order.paymentMethod.toUpperCase()})`,
                            })}
                            className="px-2 py-1 rounded-lg text-xs font-bold cursor-pointer transition-all bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 flex items-center gap-1"
                            title="Submit deletion request for Main Admin approval"
                          >
                            <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                            <span>Delete</span>
                          </button>
                        </div>
                      </div>

                      {/* Order Action Feedback Banner */}
                      {orderActionFeedback && orderActionFeedback.orderId === order.orderId && (
                        <div
                          className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between gap-2 animate-in fade-in ${
                            orderActionFeedback.type === 'success'
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                              : 'bg-rose-50 border-rose-200 text-rose-800'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {orderActionFeedback.type === 'success' ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                            ) : (
                              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                            )}
                            <span>{orderActionFeedback.message}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setOrderActionFeedback(null)}
                            className="text-slate-400 hover:text-slate-600 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}

                      {/* 3-Step Live Visual Pipeline */}
                      <div className="bg-slate-50 rounded-xl p-3 border border-slate-100">
                        <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
                          <div className={`flex flex-col items-center gap-1 ${
                            order.status === 'received' || order.status === 'dispatched' || order.status === 'delivered'
                              ? 'text-blue-700 font-bold'
                              : 'text-slate-400'
                          }`}>
                            <div className="w-5 h-5 rounded-full bg-blue-600 text-white text-[10px] flex items-center justify-center">
                              ✓
                            </div>
                            <span>1. Received</span>
                          </div>

                          <div className={`flex flex-col items-center gap-1 ${
                            order.status === 'dispatched' || order.status === 'delivered'
                              ? 'text-amber-700 font-bold'
                              : 'text-slate-400'
                          }`}>
                            <div className={`w-5 h-5 rounded-full text-[10px] flex items-center justify-center ${
                              order.status === 'dispatched' || order.status === 'delivered'
                                ? 'bg-amber-600 text-white'
                                : 'bg-slate-200 text-slate-500'
                            }`}>
                              {order.status === 'delivered' ? '✓' : '2'}
                            </div>
                            <span>2. Dispatched</span>
                          </div>

                          <div className={`flex flex-col items-center gap-1 ${
                            order.status === 'delivered'
                              ? 'text-emerald-700 font-bold'
                              : 'text-slate-400'
                          }`}>
                            <div className={`w-5 h-5 rounded-full text-[10px] flex items-center justify-center ${
                              order.status === 'delivered'
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-200 text-slate-500'
                            }`}>
                              {order.status === 'delivered' ? '✓' : '3'}
                            </div>
                            <span>3. Delivered</span>
                          </div>
                        </div>
                      </div>

                      {/* Order Items preview */}
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs pt-1">
                        <div className="flex items-center gap-2 overflow-x-auto">
                          {order.items.map(it => (
                            <span 
                              key={it.product.id}
                              className="bg-slate-100 px-2 py-1 rounded-md text-[11px] text-slate-700 whitespace-nowrap"
                            >
                              {it.quantity}x {it.product.name}
                            </span>
                          ))}
                        </div>
                        <div className="font-black text-slate-900 text-sm">
                          Total: ₹{order.totalAmount.toLocaleString('en-IN')}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ==================== TAB 4: STORE & APP SETTINGS ==================== */}
          {activeTab === 'settings' && (
            <form onSubmit={handleSaveSettings} className="space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">
                    Store & Brand Identity Configuration
                  </h3>
                  <p className="text-xs text-slate-500">
                    Modify store logo, contact info, helpline, office address, and delivery thresholds across the application
                  </p>
                </div>

                {settingsSavedMessage && (
                  <div className="flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl font-bold animate-in fade-in">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Settings Updated!</span>
                  </div>
                )}
              </div>

              {/* Brand Logo & Visual Identity Customization Card */}
              <div className="bg-gradient-to-br from-blue-50/80 via-slate-50 to-indigo-50/50 border border-blue-200/90 rounded-2xl p-4 sm:p-5 space-y-4 shadow-xs">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs shrink-0">
                      <ImageIcon className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 flex items-center gap-2 flex-wrap">
                        <span>Store Brand Logo</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          settingsForm.logoUrl 
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-300' 
                            : 'bg-blue-50 text-blue-700 border-blue-300'
                        }`}>
                          {settingsForm.logoUrl ? '✓ Custom Logo Active' : 'Default Master Vector Logo'}
                        </span>
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Upload your business logo or paste an image link. Updates Header, Footer, and Modals instantly.
                      </p>
                    </div>
                  </div>

                  {settingsForm.logoUrl && (
                    <button
                      type="button"
                      onClick={() => {
                        setSettingsForm(prev => ({ ...prev, logoUrl: '' }));
                        setLogoFileName('');
                      }}
                      className="px-2.5 py-1.5 text-xs font-bold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-xl border border-rose-200 transition-colors flex items-center gap-1.5 cursor-pointer"
                      title="Revert back to default built-in vector logo"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Reset to Default Logo</span>
                    </button>
                  )}
                </div>

                {/* Dual Live Preview: Header (Light) & Footer (Dark) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Preview on Light (Header Simulator) */}
                  <div className="bg-white border border-slate-200 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-xs min-h-[110px]">
                    <div className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 mb-2">
                      Header Preview (Light Canvas)
                    </div>
                    <div className="h-16 flex items-center justify-center max-w-full overflow-hidden p-1">
                      {settingsForm.logoUrl ? (
                        <img
                          src={settingsForm.logoUrl}
                          alt="Store Logo Preview"
                          className="h-full w-auto max-w-[260px] object-contain"
                          onError={() => {}}
                        />
                      ) : (
                        <InfostorsLogo className="h-14 w-auto max-w-[260px]" />
                      )}
                    </div>
                  </div>

                  {/* Preview on Dark (Footer Simulator) */}
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-xs min-h-[110px]">
                    <div className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 mb-2">
                      Footer Preview (Dark Canvas)
                    </div>
                    <div className="h-16 flex items-center justify-center max-w-full overflow-hidden p-1">
                      {settingsForm.logoUrl ? (
                        <img
                          src={settingsForm.logoUrl}
                          alt="Store Logo Preview"
                          className="h-full w-auto max-w-[260px] object-contain"
                          onError={() => {}}
                        />
                      ) : (
                        <InfostorsLogo className="h-14 w-auto max-w-[260px]" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Upload and URL input */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  {/* Option A: Upload File */}
                  <div className="bg-white border border-slate-200/90 rounded-xl p-3 space-y-2">
                    <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Upload className="w-3.5 h-3.5 text-blue-600" />
                      <span>Upload Logo Image</span>
                    </label>
                    <p className="text-[10px] text-slate-500">
                      Choose an image from your computer or phone (PNG with transparent background, JPG, SVG, WebP).
                    </p>
                    <input
                      type="file"
                      ref={logoFileInputRef}
                      onChange={handleLogoFileUpload}
                      accept="image/png,image/jpeg,image/webp,image/svg+xml,image/gif"
                      className="hidden"
                      id="logo-file-input"
                    />
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => logoFileInputRef.current?.click()}
                        className="flex-1 py-2 px-3 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Browse / Upload File</span>
                      </button>
                    </div>
                    {logoFileName && (
                      <div className="text-[10px] text-emerald-600 font-semibold truncate flex items-center gap-1 pt-1">
                        <Check className="w-3 h-3 shrink-0" />
                        <span>Loaded: {logoFileName}</span>
                      </div>
                    )}
                  </div>

                  {/* Option B: Enter Image URL */}
                  <div className="bg-white border border-slate-200/90 rounded-xl p-3 space-y-2">
                    <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
                      <span>Or Enter Logo Image URL</span>
                    </label>
                    <p className="text-[10px] text-slate-500">
                      Provide a direct web link to your online hosted logo image.
                    </p>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="url"
                        value={settingsForm.logoUrl?.startsWith('data:') ? '' : (settingsForm.logoUrl || '')}
                        onChange={e => {
                          setSettingsForm(prev => ({ ...prev, logoUrl: e.target.value }));
                          setLogoFileName('');
                        }}
                        placeholder="https://example.com/logo.png"
                        className="flex-1 px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                      />
                      {settingsForm.logoUrl && !settingsForm.logoUrl.startsWith('data:') && (
                        <button
                          type="button"
                          onClick={() => setSettingsForm(prev => ({ ...prev, logoUrl: '' }))}
                          className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
                          title="Clear URL"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Logo Display Size Controls */}
                <div className="bg-white border border-slate-200/90 rounded-xl p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-blue-600" />
                      <span>Header Logo Display Height</span>
                    </label>
                    <span className="text-xs font-extrabold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-lg border border-blue-200/60">
                      {settingsForm.headerLogoHeight || 72}px
                    </span>
                  </div>

                  <div className="flex items-center gap-3 flex-wrap sm:flex-nowrap">
                    <input
                      type="range"
                      min={44}
                      max={110}
                      step={2}
                      value={settingsForm.headerLogoHeight || 72}
                      onChange={e => setSettingsForm(prev => ({ ...prev, headerLogoHeight: Number(e.target.value) }))}
                      className="flex-1 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                    />
                    <div className="flex items-center gap-1 shrink-0">
                      {[
                        { label: 'Compact', val: 54 },
                        { label: 'Standard', val: 72 },
                        { label: 'Large', val: 90 },
                        { label: 'Extra Large', val: 108 }
                      ].map(preset => (
                        <button
                          key={preset.label}
                          type="button"
                          onClick={() => setSettingsForm(prev => ({ ...prev, headerLogoHeight: preset.val }))}
                          className={`px-2 py-1 text-[10px] font-bold rounded-lg border transition-colors cursor-pointer ${
                            (settingsForm.headerLogoHeight || 72) === preset.val
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Store Name & Slogan */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Store Name
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsForm.storeName}
                    onChange={e => setSettingsForm({ ...settingsForm, storeName: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Store Tagline / Slogan
                  </label>
                  <input
                    type="text"
                    value={settingsForm.tagline}
                    onChange={e => setSettingsForm({ ...settingsForm, tagline: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>

                {/* Helpline & Email */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Helpline / Toll Free / WhatsApp Phone
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsForm.helpline}
                    onChange={e => setSettingsForm({ ...settingsForm, helpline: e.target.value })}
                    placeholder="+91 94778 39200 (Toll Free / WhatsApp)"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Official Support Email
                  </label>
                  <input
                    type="email"
                    required
                    value={settingsForm.email}
                    onChange={e => setSettingsForm({ ...settingsForm, email: e.target.value })}
                    placeholder="contactinfostors@gmail.com"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>

                {/* Office Address */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Corporate Headquarters Address
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={settingsForm.officeAddress}
                    onChange={e => setSettingsForm({ ...settingsForm, officeAddress: e.target.value })}
                    placeholder="INFOSTORS Headquarters, Garia station road, Kolkata 700084, India"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>

                {/* Social Links */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    WhatsApp URL
                  </label>
                  <input
                    type="url"
                    value={settingsForm.whatsapp}
                    onChange={e => setSettingsForm({ ...settingsForm, whatsapp: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Instagram URL
                  </label>
                  <input
                    type="url"
                    value={settingsForm.instagram}
                    onChange={e => setSettingsForm({ ...settingsForm, instagram: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Facebook URL
                  </label>
                  <input
                    type="url"
                    value={settingsForm.facebook}
                    onChange={e => setSettingsForm({ ...settingsForm, facebook: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    YouTube URL
                  </label>
                  <input
                    type="url"
                    value={settingsForm.youtube}
                    onChange={e => setSettingsForm({ ...settingsForm, youtube: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>

                {/* Announcement Bar & Return Window */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Top Announcement Bar Message
                  </label>
                  <input
                    type="text"
                    value={settingsForm.announcement}
                    onChange={e => setSettingsForm({ ...settingsForm, announcement: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Return / Guarantee Policy Period
                  </label>
                  <input
                    type="text"
                    value={settingsForm.returnWindow}
                    onChange={e => setSettingsForm({ ...settingsForm, returnWindow: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                  />
                </div>
              </div>

              {/* ======================================================== */}
              {/* SECTION 1: DELIVERY CHARGE CONFIGURATION (EDIT OPTION)   */}
              {/* ======================================================== */}
              <div className="p-4 sm:p-5 bg-gradient-to-br from-blue-50/50 via-white to-indigo-50/30 border border-blue-200/80 rounded-2xl space-y-4 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-blue-100">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
                      <Truck className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 tracking-wide uppercase">
                        Delivery Charge & Shipping Policy
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Edit standard shipping fee and configure free delivery threshold across India
                      </p>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                    <Truck className="w-3 h-3" />
                    Standard: ₹{settingsForm.standardDeliveryCharge ?? 49}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Delivery Charge Edit Input */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-slate-800">
                      Standard Delivery Charge (₹) *
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">₹</span>
                      <input
                        type="number"
                        min="0"
                        step="1"
                        required
                        value={settingsForm.standardDeliveryCharge ?? 49}
                        onChange={e => setSettingsForm({
                          ...settingsForm,
                          standardDeliveryCharge: Math.max(0, Number(e.target.value) || 0),
                        })}
                        placeholder="49"
                        className="w-full pl-7 pr-3 py-2 text-xs font-bold text-slate-900 bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                        id="admin-delivery-charge-input"
                      />
                    </div>
                    <p className="text-[10px] text-slate-500">
                      Amount charged when an order does not qualify for free shipping. Set to 0 for storewide 100% Free Shipping.
                    </p>
                    {/* Quick Presets for Delivery Charge */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      <span className="text-[10px] text-slate-400 self-center">Presets:</span>
                      {[
                        { label: '₹0 (Free)', val: 0 },
                        { label: '₹40', val: 40 },
                        { label: '₹49 (Standard)', val: 49 },
                        { label: '₹70', val: 70 },
                        { label: '₹99 (Express)', val: 99 },
                      ].map(preset => (
                        <button
                          key={preset.val}
                          type="button"
                          onClick={() => setSettingsForm({ ...settingsForm, standardDeliveryCharge: preset.val })}
                          className={`px-2 py-0.5 text-[10px] font-semibold rounded-lg border transition-all cursor-pointer ${
                            (settingsForm.standardDeliveryCharge ?? 49) === preset.val
                              ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                              : 'bg-white text-slate-600 border-slate-200 hover:border-blue-300'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Free Delivery Threshold Configuration */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-semibold text-slate-800">
                        Free Delivery Threshold (₹)
                      </label>
                      <label className="inline-flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settingsForm.enableFreeDeliveryThreshold ?? true}
                          onChange={e => setSettingsForm({
                            ...settingsForm,
                            enableFreeDeliveryThreshold: e.target.checked,
                          })}
                          className="sr-only peer"
                          id="admin-free-threshold-toggle"
                        />
                        <div className="w-7 h-4 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-emerald-600 relative"></div>
                        <span className="text-[10px] font-medium text-slate-600">
                          {settingsForm.enableFreeDeliveryThreshold ?? true ? 'Active' : 'Disabled'}
                        </span>
                      </label>
                    </div>

                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">₹</span>
                      <input
                        type="number"
                        min="0"
                        step="1"
                        disabled={!(settingsForm.enableFreeDeliveryThreshold ?? true)}
                        value={settingsForm.freeDeliveryMin ?? 499}
                        onChange={e => setSettingsForm({
                          ...settingsForm,
                          freeDeliveryMin: Math.max(0, Number(e.target.value) || 0),
                        })}
                        placeholder="499"
                        className={`w-full pl-7 pr-3 py-2 text-xs font-bold rounded-xl outline-none border transition-colors ${
                          (settingsForm.enableFreeDeliveryThreshold ?? true)
                            ? 'bg-white text-slate-900 border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100'
                            : 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                        }`}
                        id="admin-free-threshold-input"
                      />
                    </div>
                    <p className="text-[10px] text-slate-500">
                      Orders with subtotal greater than or equal to this amount automatically receive FREE Delivery.
                    </p>

                    {/* Quick Presets for Threshold */}
                    {(settingsForm.enableFreeDeliveryThreshold ?? true) && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        <span className="text-[10px] text-slate-400 self-center">Presets:</span>
                        {[
                          { label: '₹299', val: 299 },
                          { label: '₹499 (Standard)', val: 499 },
                          { label: '₹799', val: 799 },
                          { label: '₹999', val: 999 },
                        ].map(preset => (
                          <button
                            key={preset.val}
                            type="button"
                            onClick={() => setSettingsForm({ ...settingsForm, freeDeliveryMin: preset.val })}
                            className={`px-2 py-0.5 text-[10px] font-semibold rounded-lg border transition-all cursor-pointer ${
                              (settingsForm.freeDeliveryMin ?? 499) === preset.val
                                ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                                : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300'
                            }`}
                          >
                            {preset.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Live Delivery Rule Simulation Banner */}
                <div className="p-3 bg-white/90 border border-blue-100 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px]">
                  <div className="flex items-center gap-2 text-slate-700">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>
                      <strong>Active Rule:</strong>{' '}
                      {(settingsForm.standardDeliveryCharge ?? 49) === 0 ? (
                        <span className="text-emerald-700 font-bold">100% Free Shipping on all orders across India</span>
                      ) : (settingsForm.enableFreeDeliveryThreshold ?? true) ? (
                        <>
                          Orders ₹{settingsForm.freeDeliveryMin ?? 499}+ get <span className="text-emerald-700 font-bold">FREE Delivery</span>; below that is <span className="text-blue-700 font-bold">₹{settingsForm.standardDeliveryCharge ?? 49}</span>.
                        </>
                      ) : (
                        <>
                          Flat <span className="text-blue-700 font-bold">₹{settingsForm.standardDeliveryCharge ?? 49}</span> shipping on every order (No free threshold).
                        </>
                      )}
                    </span>
                  </div>
                  <span className="text-[10px] font-medium text-slate-400 shrink-0">
                    Calculated automatically at checkout
                  </span>
                </div>
              </div>

              {/* ======================================================== */}
              {/* SECTION 2: FULL PROFILE GST CONFIGURATION (ON / OFF)     */}
              {/* ======================================================== */}
              <div className={`p-4 sm:p-5 rounded-2xl border transition-all space-y-4 shadow-sm ${
                settingsForm.gstEnabled
                  ? 'bg-gradient-to-br from-emerald-50/40 via-white to-teal-50/30 border-emerald-300'
                  : 'bg-slate-50/80 border-slate-200'
              }`}>
                {/* Header & Master GST ON/OFF Toggle */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center shadow-md transition-colors ${
                      settingsForm.gstEnabled ? 'bg-emerald-600 text-white shadow-emerald-500/20' : 'bg-slate-400 text-white'
                    }`}>
                      <Percent className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-slate-900 tracking-wide uppercase">
                          Full Profile GST & Tax Billing
                        </h4>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider ${
                          settingsForm.gstEnabled
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-slate-200 text-slate-600'
                        }`}>
                          {settingsForm.gstEnabled ? '● GST Active' : '○ GST Off'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Turn GST on/off and configure official GSTIN, registered entity, tax rates, and invoicing
                      </p>
                    </div>
                  </div>

                  {/* Master ON/OFF Switch */}
                  <label className="inline-flex items-center gap-2.5 px-3 py-1.5 bg-white border border-slate-200 rounded-xl shadow-xs cursor-pointer hover:border-emerald-300 transition-colors">
                    <input
                      type="checkbox"
                      checked={Boolean(settingsForm.gstEnabled)}
                      onChange={e => setSettingsForm({ ...settingsForm, gstEnabled: e.target.checked })}
                      className="sr-only peer"
                      id="admin-gst-master-toggle"
                    />
                    <div className="w-9 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600 relative"></div>
                    <span className="text-xs font-bold text-slate-800">
                      {settingsForm.gstEnabled ? 'GST Enabled (ON)' : 'GST Disabled (OFF)'}
                    </span>
                  </label>
                </div>

                {/* GST Disabled Explanatory Notice */}
                {!settingsForm.gstEnabled && (
                  <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-start gap-2.5 text-xs text-slate-600">
                    <AlertCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-slate-800">GST is currently turned OFF</p>
                      <p className="text-[11px] text-slate-500 mt-0.5 leading-normal">
                        Your store operates as exempt or non-GST registered. No GST will be added to cart totals, and no GSTIN will be printed on customer receipts. Toggle the switch above to ON whenever you wish to enable GST billing.
                      </p>
                    </div>
                  </div>
                )}

                {/* Full Profile Fields (Visible and Editable) */}
                <div className={`space-y-4 ${settingsForm.gstEnabled ? 'opacity-100' : 'opacity-60 pointer-events-none'}`}>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                    {/* GSTIN (GST Identification Number) */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        GSTIN (15 Digits) *
                      </label>
                      <input
                        type="text"
                        maxLength={15}
                        value={settingsForm.gstin || ''}
                        onChange={e => setSettingsForm({ ...settingsForm, gstin: e.target.value.toUpperCase().trim() })}
                        placeholder="19AAACI1234F1Z8"
                        className="w-full px-3 py-2 text-xs font-mono font-bold tracking-wider bg-white border border-slate-300 rounded-xl outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 uppercase"
                        id="admin-gstin-input"
                      />
                      <div className="flex items-center justify-between text-[10px] mt-1">
                        <span className="text-slate-400">e.g. 19AAACI1234F1Z8</span>
                        {(settingsForm.gstin || '').length === 15 ? (
                          <span className="text-emerald-600 font-bold flex items-center gap-0.5">
                            <Check className="w-3 h-3" /> 15 Digits Valid
                          </span>
                        ) : (
                          <span className="text-slate-400">
                            {(settingsForm.gstin || '').length}/15 chars
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Business Legal Entity Name */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Business Legal Entity Name
                      </label>
                      <input
                        type="text"
                        value={settingsForm.businessLegalName || ''}
                        onChange={e => setSettingsForm({ ...settingsForm, businessLegalName: e.target.value })}
                        placeholder="INFOSTORS ENTERPRISES PRIVATE LIMITED"
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                        id="admin-legal-name-input"
                      />
                      <p className="text-[10px] text-slate-400 mt-1">As registered with Ministry of Corporate Affairs / GST</p>
                    </div>

                    {/* Registered Trade / Brand Name */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Trade / Brand Name
                      </label>
                      <input
                        type="text"
                        value={settingsForm.tradeName || ''}
                        onChange={e => setSettingsForm({ ...settingsForm, tradeName: e.target.value })}
                        placeholder="INFOSTORS"
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                        id="admin-trade-name-input"
                      />
                      <p className="text-[10px] text-slate-400 mt-1">Commercial store brand name</p>
                    </div>

                    {/* GST State / Jurisdiction */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        GST State & Jurisdiction
                      </label>
                      <select
                        value={settingsForm.gstState || '19 - West Bengal'}
                        onChange={e => setSettingsForm({ ...settingsForm, gstState: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                        id="admin-gst-state-select"
                      >
                        {GST_STATE_OPTIONS.map(st => (
                          <option key={st} value={st}>{st}</option>
                        ))}
                      </select>
                      <p className="text-[10px] text-slate-400 mt-1">State of principal place of business</p>
                    </div>

                    {/* GST Percentage (%) */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Applicable GST Rate (%)
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          min="0"
                          max="100"
                          step="0.5"
                          value={settingsForm.gstPercentage ?? 18}
                          onChange={e => setSettingsForm({
                            ...settingsForm,
                            gstPercentage: Math.max(0, Math.min(100, Number(e.target.value) || 0)),
                          })}
                          placeholder="18"
                          className="w-full pr-8 pl-3 py-2 text-xs font-bold text-slate-900 bg-white border border-slate-300 rounded-xl outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                          id="admin-gst-rate-input"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">%</span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {[0, 5, 12, 18, 28].map(rate => (
                          <button
                            key={rate}
                            type="button"
                            onClick={() => setSettingsForm({ ...settingsForm, gstPercentage: rate })}
                            className={`px-1.5 py-0.5 text-[10px] font-semibold rounded-md border cursor-pointer transition-all ${
                              (settingsForm.gstPercentage ?? 18) === rate
                                ? 'bg-emerald-600 text-white border-emerald-600'
                                : 'bg-white text-slate-600 border-slate-200 hover:border-emerald-300'
                            }`}
                          >
                            {rate}%{rate === 18 ? ' (Std)' : ''}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Tax Calculation Pricing Mode (Inclusive vs Exclusive) */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Tax Calculation Mode
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        <button
                          type="button"
                          onClick={() => setSettingsForm({ ...settingsForm, gstType: 'inclusive' })}
                          className={`p-2 text-left rounded-xl border transition-all cursor-pointer ${
                            (settingsForm.gstType || 'inclusive') === 'inclusive'
                              ? 'bg-emerald-50 border-emerald-400 text-emerald-900 shadow-xs'
                              : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                          }`}
                        >
                          <div className="text-[11px] font-bold">Inclusive</div>
                          <div className="text-[9px] text-slate-500 leading-tight">Price includes GST (Standard MRP)</div>
                        </button>
                        <button
                          type="button"
                          onClick={() => setSettingsForm({ ...settingsForm, gstType: 'exclusive' })}
                          className={`p-2 text-left rounded-xl border transition-all cursor-pointer ${
                            settingsForm.gstType === 'exclusive'
                              ? 'bg-emerald-50 border-emerald-400 text-emerald-900 shadow-xs'
                              : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                          }`}
                        >
                          <div className="text-[11px] font-bold">Exclusive</div>
                          <div className="text-[9px] text-slate-500 leading-tight">GST added extra at checkout</div>
                        </button>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-1">
                        {(settingsForm.gstType || 'inclusive') === 'inclusive'
                          ? 'Customer pays retail price; tax breakdown is extracted for the bill.'
                          : 'Tax is calculated and added as an additional fee upon checkout.'}
                      </p>
                    </div>
                  </div>

                  {/* Additional GST Checkbox Options */}
                  <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 border-t border-emerald-100">
                    <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={settingsForm.showGstinOnInvoice ?? true}
                        onChange={e => setSettingsForm({ ...settingsForm, showGstinOnInvoice: e.target.checked })}
                        className="w-4 h-4 text-emerald-600 rounded-md border-slate-300 focus:ring-emerald-500 cursor-pointer"
                        id="admin-show-gstin-toggle"
                      />
                      <span>Print GSTIN and Tax breakdown on invoices & receipts</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={settingsForm.allowCustomerB2bGst ?? true}
                        onChange={e => setSettingsForm({ ...settingsForm, allowCustomerB2bGst: e.target.checked })}
                        className="w-4 h-4 text-emerald-600 rounded-md border-slate-300 focus:ring-emerald-500 cursor-pointer"
                        id="admin-allow-b2b-toggle"
                      />
                      <span>Allow B2B buyers to input their GSTIN during checkout (Input Tax Credit)</span>
                    </label>
                  </div>

                  {/* Live GST Simulation Preview */}
                  {settingsForm.gstEnabled && (
                    <div className="p-3 bg-white/90 border border-emerald-200 rounded-xl space-y-1.5 text-[11px]">
                      <div className="flex items-center justify-between font-bold text-slate-800">
                        <span className="flex items-center gap-1 text-emerald-800">
                          <FileText className="w-3.5 h-3.5" /> Sample Bill Calculation Preview (Order of ₹1,000)
                        </span>
                        <span className="text-[10px] text-slate-400 font-normal">
                          Mode: {settingsForm.gstType === 'exclusive' ? 'Exclusive (Extra)' : 'Inclusive (Inside MRP)'}
                        </span>
                      </div>
                      {settingsForm.gstType === 'exclusive' ? (
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-slate-600 pt-1">
                          <div className="bg-slate-50 p-1.5 rounded-lg">Product Subtotal: <strong className="text-slate-900">₹1,000</strong></div>
                          <div className="bg-slate-50 p-1.5 rounded-lg">GST ({settingsForm.gstPercentage ?? 18}%): <strong className="text-emerald-700">+₹{Math.round((1000 * (settingsForm.gstPercentage ?? 18)) / 100)}</strong></div>
                          <div className="bg-slate-50 p-1.5 rounded-lg">Delivery: <strong className="text-slate-900">{1000 >= (settingsForm.freeDeliveryMin ?? 499) && (settingsForm.enableFreeDeliveryThreshold ?? true) ? 'FREE' : `₹${settingsForm.standardDeliveryCharge ?? 49}`}</strong></div>
                          <div className="bg-emerald-50 p-1.5 rounded-lg border border-emerald-200">Customer Pays: <strong className="text-emerald-800">₹{1000 + Math.round((1000 * (settingsForm.gstPercentage ?? 18)) / 100) + (1000 >= (settingsForm.freeDeliveryMin ?? 499) && (settingsForm.enableFreeDeliveryThreshold ?? true) ? 0 : (settingsForm.standardDeliveryCharge ?? 49))}</strong></div>
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-slate-600 pt-1">
                          <div className="bg-slate-50 p-1.5 rounded-lg">Retail MRP: <strong className="text-slate-900">₹1,000</strong></div>
                          <div className="bg-slate-50 p-1.5 rounded-lg">Taxable Value: <strong className="text-slate-900">₹{(1000 / (1 + (settingsForm.gstPercentage ?? 18) / 100)).toFixed(2)}</strong></div>
                          <div className="bg-slate-50 p-1.5 rounded-lg">GST Component: <strong className="text-emerald-700">₹{(1000 - 1000 / (1 + (settingsForm.gstPercentage ?? 18) / 100)).toFixed(2)}</strong></div>
                          <div className="bg-emerald-50 p-1.5 rounded-lg border border-emerald-200">Customer Pays: <strong className="text-emerald-800">₹{1000 + (1000 >= (settingsForm.freeDeliveryMin ?? 499) && (settingsForm.enableFreeDeliveryThreshold ?? true) ? 0 : (settingsForm.standardDeliveryCharge ?? 49))}</strong></div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* SECTION: AUTHENTICATION, OTP & GUEST BROWSING POLICIES */}
              <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-4 shadow-sm">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-xs sm:text-sm text-slate-900">
                        Customer Authentication & Security Governance
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Configure guest browsing, purchase login requirements, and OTP verification switches
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    Secure Policy Active
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800">Free Guest Browsing</span>
                      <span className="text-[10px] font-extrabold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">ALWAYS ON</span>
                    </div>
                    <p className="text-[10px] text-slate-500">
                      Visitors browse catalog, categories, specifications, and add items to cart freely without requiring login.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800">Login Before Real Purchase</span>
                      <span className="text-[10px] font-extrabold bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">ENFORCED</span>
                    </div>
                    <p className="text-[10px] text-slate-500">
                      Guests can click Buy Now/Checkout, and their cart is preserved through signin/signup before order placement.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5 sm:col-span-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs font-bold text-slate-800">Optional OTP Verification (SMS / Email)</span>
                        <p className="text-[10px] text-slate-500">
                          Toggle between standard Password authentication and OTP verification. Currently OFF to avoid third-party SMS costs.
                        </p>
                      </div>
                      <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-slate-200 text-slate-700">
                        OFF (Email/Mobile Password Active)
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION: 4x6 THERMAL SHIPPING LABELS, PRIVACY & BRANDING CONTROLS */}
              <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-4 shadow-sm">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                      <Printer className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-xs sm:text-sm text-slate-900">
                        4×6" Thermal Shipping Label, Privacy & Branding Settings
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Configure privacy defaults, logo display, pickup location, and thermal label specifications
                      </p>
                    </div>
                  </div>
                </div>

                {/* Sub-section 1: Privacy & Field Visibility Toggles */}
                <div className="space-y-2">
                  <span className="text-[11px] font-bold text-slate-800 uppercase tracking-wider block">
                    Printed Document Privacy & Field Controls
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 text-xs">
                    {/* Customer Email Toggle (Default OFF for Privacy) */}
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                      <div>
                        <span className="font-bold text-slate-900 block">Show Customer Email</span>
                        <span className="text-[10px] text-slate-500">Default OFF for customer privacy</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={settingsForm.shippingLabelSettings?.showCustomerEmail ?? false}
                        onChange={(e) => {
                          const checked = e.target.checked;
                          setSettingsForm(prev => ({
                            ...prev,
                            shippingLabelSettings: {
                              ...(prev.shippingLabelSettings || {
                                showCustomerMobile: true,
                                showPickupLocation: true,
                                showPickupContact: true,
                                showCourierPartner: true,
                                showTrackingId: true,
                                showOrderId: true,
                                showPaymentMethod: true,
                                showProductDetails: true,
                                showPrices: true,
                                showBarcode: true,
                                showDataMatrix: true,
                              }),
                              showCustomerEmail: checked,
                            }
                          }));
                        }}
                        className="rounded text-blue-600 w-4 h-4 cursor-pointer"
                      />
                    </div>

                    {/* Customer Mobile Toggle */}
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                      <div>
                        <span className="font-bold text-slate-900 block">Show Customer Mobile</span>
                        <span className="text-[10px] text-slate-500">Required for courier delivery calls</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={settingsForm.shippingLabelSettings?.showCustomerMobile ?? true}
                        onChange={(e) => {
                          const checked = e.target.checked;
                          setSettingsForm(prev => ({
                            ...prev,
                            shippingLabelSettings: {
                              ...(prev.shippingLabelSettings || {
                                showCustomerEmail: false,
                                showPickupLocation: true,
                                showPickupContact: true,
                                showCourierPartner: true,
                                showTrackingId: true,
                                showOrderId: true,
                                showPaymentMethod: true,
                                showProductDetails: true,
                                showPrices: true,
                                showBarcode: true,
                                showDataMatrix: true,
                              }),
                              showCustomerMobile: checked,
                            }
                          }));
                        }}
                        className="rounded text-blue-600 w-4 h-4 cursor-pointer"
                      />
                    </div>

                    {/* Show Pickup / Shipper Location */}
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                      <div>
                        <span className="font-bold text-slate-900 block">Show Pickup Location</span>
                        <span className="text-[10px] text-slate-500">Print return warehouse address</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={settingsForm.shippingLabelSettings?.showPickupLocation ?? true}
                        onChange={(e) => {
                          const checked = e.target.checked;
                          setSettingsForm(prev => ({
                            ...prev,
                            shippingLabelSettings: {
                              ...(prev.shippingLabelSettings || {
                                showCustomerEmail: false,
                                showCustomerMobile: true,
                                showPickupContact: true,
                                showCourierPartner: true,
                                showTrackingId: true,
                                showOrderId: true,
                                showPaymentMethod: true,
                                showProductDetails: true,
                                showPrices: true,
                                showBarcode: true,
                                showDataMatrix: true,
                              }),
                              showPickupLocation: checked,
                            }
                          }));
                        }}
                        className="rounded text-blue-600 w-4 h-4 cursor-pointer"
                      />
                    </div>

                    {/* Show Pickup Contact */}
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                      <div>
                        <span className="font-bold text-slate-900 block">Show Pickup Contact</span>
                        <span className="text-[10px] text-slate-500">Print warehouse helpline</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={settingsForm.shippingLabelSettings?.showPickupContact ?? true}
                        onChange={(e) => {
                          const checked = e.target.checked;
                          setSettingsForm(prev => ({
                            ...prev,
                            shippingLabelSettings: {
                              ...(prev.shippingLabelSettings || {
                                showCustomerEmail: false,
                                showCustomerMobile: true,
                                showPickupLocation: true,
                                showCourierPartner: true,
                                showTrackingId: true,
                                showOrderId: true,
                                showPaymentMethod: true,
                                showProductDetails: true,
                                showPrices: true,
                                showBarcode: true,
                                showDataMatrix: true,
                              }),
                              showPickupContact: checked,
                            }
                          }));
                        }}
                        className="rounded text-blue-600 w-4 h-4 cursor-pointer"
                      />
                    </div>

                    {/* Auto-generate PDF after Finalize */}
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                      <div>
                        <span className="font-bold text-slate-900 block">Auto-Download PDF</span>
                        <span className="text-[10px] text-slate-500">Prompt download after finalize</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={settingsForm.shippingLabelSettings?.autoPdfAfterFinalize ?? false}
                        onChange={(e) => {
                          const checked = e.target.checked;
                          setSettingsForm(prev => ({
                            ...prev,
                            shippingLabelSettings: {
                              ...(prev.shippingLabelSettings || {
                                showCustomerEmail: false,
                                showCustomerMobile: true,
                                showPickupLocation: true,
                                showPickupContact: true,
                                showCourierPartner: true,
                                showTrackingId: true,
                                showOrderId: true,
                                showPaymentMethod: true,
                                showProductDetails: true,
                                showPrices: true,
                                showBarcode: true,
                                showDataMatrix: true,
                              }),
                              autoPdfAfterFinalize: checked,
                            }
                          }));
                        }}
                        className="rounded text-blue-600 w-4 h-4 cursor-pointer"
                      />
                    </div>

                    {/* Show Logo on 4x6 Label */}
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                      <div>
                        <span className="font-bold text-slate-900 block">Show Brand Logo</span>
                        <span className="text-[10px] text-slate-500">Display logo on thermal label</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={settingsForm.shippingLabelSettings?.branding?.showOnLabel ?? true}
                        onChange={(e) => {
                          const checked = e.target.checked;
                          setSettingsForm(prev => ({
                            ...prev,
                            shippingLabelSettings: {
                              ...(prev.shippingLabelSettings || {
                                showCustomerEmail: false,
                                showCustomerMobile: true,
                                showPickupLocation: true,
                                showPickupContact: true,
                                showCourierPartner: true,
                                showTrackingId: true,
                                showOrderId: true,
                                showPaymentMethod: true,
                                showProductDetails: true,
                                showPrices: true,
                                showBarcode: true,
                                showDataMatrix: true,
                              }),
                              branding: {
                                ...(prev.shippingLabelSettings?.branding || {
                                  logoEnabled: true,
                                  showOnInvoice: true,
                                  alignment: 'left',
                                  size: 'medium',
                                }),
                                showOnLabel: checked,
                              }
                            }
                          }));
                        }}
                        className="rounded text-blue-600 w-4 h-4 cursor-pointer"
                      />
                    </div>
                  </div>
                </div>

                {/* Sub-section 2: Editable Pickup / Sender Location Fields */}
                <div className="space-y-2 pt-2 border-t border-slate-200">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-blue-600" />
                    <span className="text-[11px] font-bold text-slate-800 uppercase tracking-wider">
                      Pickup / Sender Warehouse Details
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 text-xs">
                    <div>
                      <label className="text-[10px] font-bold text-slate-500 block mb-1">Company / Hub Name</label>
                      <input
                        type="text"
                        value={settingsForm.shippingLabelSettings?.pickupLocation?.companyName || 'INFOSTORS Logistics Hub'}
                        onChange={(e) => {
                          const val = e.target.value;
                          setSettingsForm(prev => ({
                            ...prev,
                            shippingLabelSettings: {
                              ...(prev.shippingLabelSettings || {
                                showCustomerEmail: false,
                                showCustomerMobile: true,
                                showPickupLocation: true,
                                showPickupContact: true,
                                showCourierPartner: true,
                                showTrackingId: true,
                                showOrderId: true,
                                showPaymentMethod: true,
                                showProductDetails: true,
                                showPrices: true,
                                showBarcode: true,
                                showDataMatrix: true,
                              }),
                              pickupLocation: {
                                ...(prev.shippingLabelSettings?.pickupLocation || {
                                  companyName: 'INFOSTORS Logistics Hub',
                                  address: 'Garia Station Road, Near Metro Gate 2',
                                  city: 'Kolkata',
                                  state: 'West Bengal',
                                  pincode: '700084',
                                  contactNumber: '+91 94778 39200',
                                }),
                                companyName: val,
                              }
                            }
                          }));
                        }}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-500 block mb-1">Street Address</label>
                      <input
                        type="text"
                        value={settingsForm.shippingLabelSettings?.pickupLocation?.address || 'Garia Station Road, Near Metro Gate 2'}
                        onChange={(e) => {
                          const val = e.target.value;
                          setSettingsForm(prev => ({
                            ...prev,
                            shippingLabelSettings: {
                              ...(prev.shippingLabelSettings || {
                                showCustomerEmail: false,
                                showCustomerMobile: true,
                                showPickupLocation: true,
                                showPickupContact: true,
                                showCourierPartner: true,
                                showTrackingId: true,
                                showOrderId: true,
                                showPaymentMethod: true,
                                showProductDetails: true,
                                showPrices: true,
                                showBarcode: true,
                                showDataMatrix: true,
                              }),
                              pickupLocation: {
                                ...(prev.shippingLabelSettings?.pickupLocation || {
                                  companyName: 'INFOSTORS Logistics Hub',
                                  address: 'Garia Station Road, Near Metro Gate 2',
                                  city: 'Kolkata',
                                  state: 'West Bengal',
                                  pincode: '700084',
                                  contactNumber: '+91 94778 39200',
                                }),
                                address: val,
                              }
                            }
                          }));
                        }}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-500 block mb-1">City & State</label>
                      <input
                        type="text"
                        value={`${settingsForm.shippingLabelSettings?.pickupLocation?.city || 'Kolkata'}, ${settingsForm.shippingLabelSettings?.pickupLocation?.state || 'West Bengal'}`}
                        onChange={(e) => {
                          const val = e.target.value;
                          const parts = val.split(',');
                          const city = parts[0]?.trim() || 'Kolkata';
                          const state = parts[1]?.trim() || 'West Bengal';
                          setSettingsForm(prev => ({
                            ...prev,
                            shippingLabelSettings: {
                              ...(prev.shippingLabelSettings || {
                                showCustomerEmail: false,
                                showCustomerMobile: true,
                                showPickupLocation: true,
                                showPickupContact: true,
                                showCourierPartner: true,
                                showTrackingId: true,
                                showOrderId: true,
                                showPaymentMethod: true,
                                showProductDetails: true,
                                showPrices: true,
                                showBarcode: true,
                                showDataMatrix: true,
                              }),
                              pickupLocation: {
                                ...(prev.shippingLabelSettings?.pickupLocation || {
                                  companyName: 'INFOSTORS Logistics Hub',
                                  address: 'Garia Station Road, Near Metro Gate 2',
                                  city: 'Kolkata',
                                  state: 'West Bengal',
                                  pincode: '700084',
                                  contactNumber: '+91 94778 39200',
                                }),
                                city,
                                state,
                              }
                            }
                          }));
                        }}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-500 block mb-1">PIN Code</label>
                      <input
                        type="text"
                        value={settingsForm.shippingLabelSettings?.pickupLocation?.pincode || '700084'}
                        onChange={(e) => {
                          const val = e.target.value;
                          setSettingsForm(prev => ({
                            ...prev,
                            shippingLabelSettings: {
                              ...(prev.shippingLabelSettings || {
                                showCustomerEmail: false,
                                showCustomerMobile: true,
                                showPickupLocation: true,
                                showPickupContact: true,
                                showCourierPartner: true,
                                showTrackingId: true,
                                showOrderId: true,
                                showPaymentMethod: true,
                                showProductDetails: true,
                                showPrices: true,
                                showBarcode: true,
                                showDataMatrix: true,
                              }),
                              pickupLocation: {
                                ...(prev.shippingLabelSettings?.pickupLocation || {
                                  companyName: 'INFOSTORS Logistics Hub',
                                  address: 'Garia Station Road, Near Metro Gate 2',
                                  city: 'Kolkata',
                                  state: 'West Bengal',
                                  pincode: '700084',
                                  contactNumber: '+91 94778 39200',
                                }),
                                pincode: val,
                              }
                            }
                          }));
                        }}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-500 block mb-1">Pickup Contact Number</label>
                      <input
                        type="text"
                        value={settingsForm.shippingLabelSettings?.pickupLocation?.contactNumber || '+91 94778 39200'}
                        onChange={(e) => {
                          const val = e.target.value;
                          setSettingsForm(prev => ({
                            ...prev,
                            shippingLabelSettings: {
                              ...(prev.shippingLabelSettings || {
                                showCustomerEmail: false,
                                showCustomerMobile: true,
                                showPickupLocation: true,
                                showPickupContact: true,
                                showCourierPartner: true,
                                showTrackingId: true,
                                showOrderId: true,
                                showPaymentMethod: true,
                                showProductDetails: true,
                                showPrices: true,
                                showBarcode: true,
                                showDataMatrix: true,
                              }),
                              pickupLocation: {
                                ...(prev.shippingLabelSettings?.pickupLocation || {
                                  companyName: 'INFOSTORS Logistics Hub',
                                  address: 'Garia Station Road, Near Metro Gate 2',
                                  city: 'Kolkata',
                                  state: 'West Bengal',
                                  pincode: '700084',
                                  contactNumber: '+91 94778 39200',
                                }),
                                contactNumber: val,
                              }
                            }
                          }));
                        }}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 outline-none focus:bg-white focus:border-blue-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Sub-section 3: Barcode Specs Card */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-2 border-t border-slate-200">
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[10px] font-bold uppercase text-slate-400 block">Label Dimension</span>
                    <strong className="text-slate-900 text-xs">4×6 Inch (100mm × 150mm)</strong>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Direct thermal sticker format</span>
                  </div>

                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[10px] font-bold uppercase text-slate-400 block">1D Barcode</span>
                    <strong className="text-slate-900 text-xs">Code 128 (Order ID)</strong>
                    <span className="text-[10px] text-emerald-600 font-semibold block mt-0.5">✓ Dynamic bwip-js vector</span>
                  </div>

                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[10px] font-bold uppercase text-slate-400 block">2D Matrix</span>
                    <strong className="text-slate-900 text-xs">Data Matrix (Tracking ID)</strong>
                    <span className="text-[10px] text-emerald-600 font-semibold block mt-0.5">✓ High density courier scan</span>
                  </div>
                </div>
              </div>

              {/* Sticky Action Footer for Settings */}
              <div className="sticky bottom-0 bg-white/95 backdrop-blur-xs -mx-3.5 -mb-3.5 sm:-mx-6 sm:-mb-6 p-3 sm:p-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 shadow-lg z-10">
                <div className="flex-1 min-w-[200px]">
                  {settingsSavedMessage && (
                    <div className="text-emerald-700 text-xs font-semibold flex items-center gap-1.5 animate-in fade-in" id="settings-saved-banner">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Store settings, delivery rules & GST profile saved!</span>
                    </div>
                  )}
                  {settingsErrorMessage && (
                    <div className="text-rose-700 text-xs font-semibold flex items-center gap-1.5 animate-in fade-in" id="settings-error-banner">
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>{settingsErrorMessage}</span>
                    </div>
                  )}
                  {!settingsSavedMessage && !settingsErrorMessage && (
                    <span className="text-[11px] text-slate-500">
                      Changes apply instantly to checkout, cart totals, and storefront.
                    </span>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isSavingSettings}
                  className="w-full sm:w-auto px-6 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-500/20 cursor-pointer flex items-center justify-center gap-1.5 transition-all"
                  id="admin-save-all-store-settings-btn"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSavingSettings ? 'Saving Settings...' : 'Save All Store Settings'}</span>
                </button>
              </div>
            </form>
          )}

          {/* ==================== TAB: PWA & APP INSTALL ==================== */}
          {activeTab === 'pwa' && (
            <AdminPwaSettingsTab />
          )}

          {/* ==================== TAB 5: CUSTOMERS ==================== */}
          {activeTab === 'customers' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={customerSearchQuery}
                    onChange={e => setCustomerSearchQuery(e.target.value)}
                    placeholder="Search customers by name, email, or mobile number..."
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                    id="admin-search-customers"
                  />
                </div>
                <div className="text-xs font-semibold text-slate-500 flex items-center gap-2">
                  <span>Total Registered:</span>
                  <span className="font-extrabold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200">
                    {adminCustomers.length} Customers
                  </span>
                </div>
              </div>

              {isLoadingCustomers ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  Loading customer accounts...
                </div>
              ) : adminCustomers.length === 0 ? (
                <div className="py-12 text-center bg-slate-50 border border-slate-200 rounded-2xl p-6">
                  <User className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-bold text-slate-700">No Customers Registered Yet</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Customers who register on the storefront will appear here. Passwords are securely hashed with bcrypt and never visible.
                  </p>
                </div>
              ) : (
                <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 bg-white shadow-xs">
                  {/* Table Header */}
                  <div className="bg-slate-50 px-4 py-2.5 grid grid-cols-12 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    <div className="col-span-12 sm:col-span-4">Customer</div>
                    <div className="hidden sm:block sm:col-span-4">Contact Info</div>
                    <div className="hidden sm:block sm:col-span-2">Joined Date</div>
                    <div className="col-span-12 sm:col-span-2 sm:text-right">Orders</div>
                  </div>

                  {/* Customer Rows */}
                  {adminCustomers
                    .filter(c =>
                      c.fullName?.toLowerCase().includes(customerSearchQuery.toLowerCase()) ||
                      c.email?.toLowerCase().includes(customerSearchQuery.toLowerCase()) ||
                      c.mobile?.includes(customerSearchQuery)
                    )
                    .map(cust => {
                      const customerOrders = orders.filter(
                        o => o.customerId === cust.id || (o.customer?.email && o.customer.email.toLowerCase() === cust.email?.toLowerCase())
                      );

                      return (
                        <div key={cust.id} className="px-4 py-3 grid grid-cols-12 items-center text-xs hover:bg-slate-50/80 transition-colors gap-2 sm:gap-0">
                          <div className="col-span-12 sm:col-span-4 flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center shrink-0 text-xs">
                              {cust.fullName ? cust.fullName.charAt(0).toUpperCase() : 'U'}
                            </div>
                            <div className="min-w-0">
                              <p className="font-bold text-slate-900 truncate">{cust.fullName}</p>
                              <span className="text-[10px] font-mono text-slate-400">{cust.id}</span>
                            </div>
                          </div>

                          <div className="col-span-12 sm:col-span-4 min-w-0">
                            <p className="text-slate-800 truncate font-medium">{cust.email}</p>
                            <p className="text-[11px] text-slate-500">+91 {cust.mobile}</p>
                          </div>

                          <div className="hidden sm:block sm:col-span-2 text-slate-500 text-[11px]">
                            {cust.createdAt
                              ? new Date(cust.createdAt).toLocaleDateString('en-IN', {
                                  day: 'numeric',
                                  month: 'short',
                                  year: 'numeric',
                                })
                              : 'Recently'}
                          </div>

                          <div className="col-span-12 sm:col-span-2 sm:text-right flex items-center justify-end gap-1.5">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold ${
                              customerOrders.length > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                            }`}>
                              {customerOrders.length} {customerOrders.length === 1 ? 'order' : 'orders'}
                            </span>
                            <button
                              type="button"
                              onClick={() => setSelectedMessageCustomer(cust)}
                              className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                              title="Send Private Offer / Direct Message to Customer"
                            >
                              <MessageCircle className="w-3.5 h-3.5 text-blue-600" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteRequestTarget({
                                type: 'customer',
                                id: cust.id,
                                summary: `${cust.fullName} (${cust.email || cust.mobile})`,
                              })}
                              className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title="Request Customer Account Deletion (Main Admin Approval Required)"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          )}

          {/* ==================== TAB: ADMIN ACCESS & ROLE MANAGEMENT ==================== */}
          {activeTab === 'admins' && (
            <AdminManagementTab />
          )}

          {/* ==================== TAB 6: RAZORPAY PAYMENT GATEWAY CONFIGURATION ==================== */}
          {activeTab === 'payments' && (
            <div className="space-y-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200">
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-900 flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-blue-600" />
                    <span>Razorpay Payment Gateway Settings</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Configure official Razorpay API credentials, Webhook secret, and toggle between Test & Live environments.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 border ${
                    paymentSettings?.isConfigured
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      : 'bg-amber-50 text-amber-800 border-amber-200'
                  }`}>
                    <span className={`w-2 h-2 rounded-full ${
                      paymentSettings?.isConfigured ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
                    }`} />
                    {paymentSettings?.isConfigured ? 'Gateway Configured' : 'Credentials Not Configured'}
                  </span>
                </div>
              </div>

              {/* Status & Diagnostics Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-1">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Active Environment
                  </span>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-black uppercase ${
                      paymentForm.environment === 'live'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-amber-500 text-white'
                    }`}>
                      {paymentForm.environment} Mode
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 pt-1">
                    {paymentForm.environment === 'live' 
                      ? 'Processes real customer payments' 
                      : 'Use Razorpay test cards & UPI handles for simulation'}
                  </p>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-1">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Security Encryption
                  </span>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 mt-1">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>AES-256-CBC Encrypted</span>
                  </div>
                  <p className="text-[11px] text-slate-500 pt-1">
                    Secrets are encrypted at rest and never returned over public APIs.
                  </p>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-1">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Key ID Preview
                  </span>
                  <div className="font-mono text-xs font-bold text-slate-800 truncate mt-1">
                    {paymentSettings?.keyId || 'None configured'}
                  </div>
                  <p className="text-[11px] text-slate-500 pt-1">
                    Public Key ID used in checkout.
                  </p>
                </div>
              </div>

              {/* Success / Error Alerts */}
              {paymentSaveMessage && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-2xl text-xs flex items-center gap-2.5 animate-in fade-in">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span className="font-semibold">{paymentSaveMessage}</span>
                </div>
              )}

              {paymentErrorMessage && (
                <div className="p-4 bg-rose-50 border border-rose-200 text-rose-900 rounded-2xl text-xs flex items-center gap-2.5 animate-in fade-in">
                  <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                  <span className="font-semibold">{paymentErrorMessage}</span>
                </div>
              )}

              {/* Credentials Configuration Form */}
              <form onSubmit={handleSavePaymentSettings} className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-5 shadow-xs">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Key className="w-4 h-4 text-blue-600" />
                    <span>API Keys & Secrets</span>
                  </h4>
                  <span className="text-[11px] text-slate-500">
                    Find these in your <a href="https://dashboard.razorpay.com/#/app/keys" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline font-semibold">Razorpay Dashboard → Settings → API Keys</a>
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Environment Selector */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      Gateway Environment *
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                        paymentForm.environment === 'test'
                          ? 'border-blue-600 bg-blue-50/50 shadow-xs ring-2 ring-blue-500/20'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}>
                        <input
                          type="radio"
                          name="environment"
                          value="test"
                          checked={paymentForm.environment === 'test'}
                          onChange={() => setPaymentForm({ ...paymentForm, environment: 'test' })}
                          className="accent-blue-600"
                        />
                        <div>
                          <p className="font-bold text-xs text-slate-900">Test Mode</p>
                          <p className="text-[10px] text-slate-500">For safe development & test transactions</p>
                        </div>
                      </label>

                      <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                        paymentForm.environment === 'live'
                          ? 'border-emerald-600 bg-emerald-50/50 shadow-xs ring-2 ring-emerald-500/20'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}>
                        <input
                          type="radio"
                          name="environment"
                          value="live"
                          checked={paymentForm.environment === 'live'}
                          onChange={() => setPaymentForm({ ...paymentForm, environment: 'live' })}
                          className="accent-emerald-600"
                        />
                        <div>
                          <p className="font-bold text-xs text-slate-900">Live Production Mode</p>
                          <p className="text-[10px] text-slate-500">Accept real money from verified customers</p>
                        </div>
                      </label>
                    </div>
                  </div>

                  {/* Key ID */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Razorpay Key ID *
                    </label>
                    <input
                      type="text"
                      value={paymentForm.keyId}
                      onChange={e => setPaymentForm({ ...paymentForm, keyId: e.target.value.trim() })}
                      placeholder={paymentForm.environment === 'test' ? 'rzp_test_xxxxxxxxxxxxxx' : 'rzp_live_xxxxxxxxxxxxxx'}
                      className="w-full px-3.5 py-2.5 text-xs font-mono bg-slate-50 border border-slate-300 focus:bg-white focus:border-blue-500 rounded-xl outline-none transition-colors"
                      id="input-razorpay-key-id"
                    />
                    <p className="text-[11px] text-slate-500 mt-1">
                      Starts with <code className="font-mono text-slate-700">rzp_test_</code> or <code className="font-mono text-slate-700">rzp_live_</code>.
                    </p>
                  </div>

                  {/* Key Secret */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Razorpay Key Secret *
                    </label>
                    <div className="relative">
                      <input
                        type={showKeySecret ? 'text' : 'password'}
                        value={paymentForm.keySecret}
                        onChange={e => setPaymentForm({ ...paymentForm, keySecret: e.target.value.trim() })}
                        placeholder={paymentSettings?.hasKeySecret ? '•••••••••••••••• (Leave blank to keep existing)' : 'Enter Razorpay Key Secret'}
                        className="w-full pl-3.5 pr-10 py-2.5 text-xs font-mono bg-slate-50 border border-slate-300 focus:bg-white focus:border-blue-500 rounded-xl outline-none transition-colors"
                        id="input-razorpay-key-secret"
                      />
                      <button
                        type="button"
                        onClick={() => setShowKeySecret(!showKeySecret)}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-700 cursor-pointer"
                      >
                        {showKeySecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    {paymentSettings?.hasKeySecret && (
                      <span className="text-[10px] text-emerald-600 font-semibold block mt-1">
                        ✓ Encrypted secret is active on server
                      </span>
                    )}
                  </div>

                  {/* Webhook Secret */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Webhook Secret (Optional)
                    </label>
                    <div className="relative">
                      <input
                        type={showWebhookSecret ? 'text' : 'password'}
                        value={paymentForm.webhookSecret}
                        onChange={e => setPaymentForm({ ...paymentForm, webhookSecret: e.target.value.trim() })}
                        placeholder={paymentSettings?.hasWebhookSecret ? '•••••••••••••••• (Leave blank to keep existing)' : 'e.g. your_webhook_secret_key'}
                        className="w-full pl-3.5 pr-10 py-2.5 text-xs font-mono bg-slate-50 border border-slate-300 focus:bg-white focus:border-blue-500 rounded-xl outline-none transition-colors"
                        id="input-razorpay-webhook-secret"
                      />
                      <button
                        type="button"
                        onClick={() => setShowWebhookSecret(!showWebhookSecret)}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-700 cursor-pointer"
                      >
                        {showWebhookSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    {paymentSettings?.hasWebhookSecret && (
                      <span className="text-[10px] text-emerald-600 font-semibold block mt-1">
                        ✓ Encrypted webhook secret active on server
                      </span>
                    )}
                  </div>

                  {/* Active Toggle */}
                  <div className="sm:col-span-2 pt-2">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={paymentForm.isActive}
                        onChange={e => setPaymentForm({ ...paymentForm, isActive: e.target.checked })}
                        className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
                        id="input-razorpay-is-active"
                      />
                      <span className="text-xs font-bold text-slate-800">
                        Enable Razorpay & UPI at Store Checkout
                      </span>
                    </label>
                    <p className="text-[11px] text-slate-500 pl-7 mt-0.5">
                      When enabled, customers can choose Razorpay or Instant UPI during checkout.
                    </p>
                  </div>
                </div>

                {/* Form Buttons */}
                <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={handleTestPaymentConnection}
                    disabled={testConnectionStatus?.loading}
                    className="w-full sm:w-auto px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
                  >
                    {testConnectionStatus?.loading ? (
                      <div className="w-3.5 h-3.5 border-2 border-slate-400 border-t-slate-700 rounded-full animate-spin" />
                    ) : (
                      <Zap className="w-3.5 h-3.5 text-blue-600" />
                    )}
                    <span>Test API Connection</span>
                  </button>

                  <button
                    type="submit"
                    disabled={isSavingPaymentSettings}
                    className="w-full sm:w-auto px-6 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 cursor-pointer transition-colors"
                    id="btn-save-payment-settings"
                  >
                    {isSavingPaymentSettings ? (
                      <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <Save className="w-3.5 h-3.5" />
                    )}
                    <span>Save Razorpay Credentials</span>
                  </button>
                </div>

                {/* Test Connection Output */}
                {testConnectionStatus && (
                  <div className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 ${
                    testConnectionStatus.success
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                      : 'bg-rose-50 border-rose-200 text-rose-800'
                  }`}>
                    {testConnectionStatus.success ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    )}
                    <span>{testConnectionStatus.message}</span>
                  </div>
                )}
              </form>

              {/* Webhook Configuration Guide Card */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-blue-600" />
                    <h4 className="font-bold text-xs sm:text-sm text-slate-900">
                      Webhook Synchronization URL
                    </h4>
                  </div>
                  <span className="text-[10px] text-slate-500 bg-white border border-slate-200 px-2 py-0.5 rounded-md font-medium">
                    Idempotent & HMAC Verified
                  </span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  In your Razorpay Dashboard, navigate to <strong>Settings → Webhooks</strong>, add a webhook with the URL below, and subscribe to <code className="bg-white border border-slate-200 px-1 py-0.5 rounded text-[11px] font-mono text-slate-700">payment.captured</code> and <code className="bg-white border border-slate-200 px-1 py-0.5 rounded text-[11px] font-mono text-slate-700">order.paid</code>.
                </p>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 min-w-0">
                  <input
                    type="text"
                    readOnly
                    value={`${window.location.origin}/api/payments/razorpay/webhook`}
                    className="flex-1 min-w-0 px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-xl outline-none select-all truncate"
                  />
                  <button
                    type="button"
                    onClick={handleCopyWebhookUrl}
                    className="px-3.5 py-2 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-center gap-1.5 cursor-pointer transition-colors shrink-0"
                  >
                    {copiedWebhookUrl ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy URL</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ==================== TAB 8: DELETE REQUESTS WORKFLOW ==================== */}
          {activeTab === 'delete_requests' && (
            <DeleteRequestsTab
              adminProfile={adminProfile}
              adminToken={adminToken}
              onRefreshOrders={() => {
                // Trigger re-render by fetching updated orders if available
                window.location.reload();
              }}
              onRefreshCustomers={() => {
                if (adminToken) {
                  fetch('/api/admin/customers', {
                    headers: { Authorization: `Bearer ${adminToken}` },
                  })
                    .then(res => parseApiResponse(res))
                    .then(result => {
                      if (result.ok && result.data?.customers) {
                        setAdminCustomers(result.data.customers);
                      }
                    })
                    .catch(() => {});
                }
              }}
            />
          )}

          {/* ==================== TAB 9: IMMUTABLE AUDIT LOGS ==================== */}
          {activeTab === 'audit_logs' && (
            <AuditLogsTab
              adminProfile={adminProfile}
              adminToken={adminToken}
            />
          )}

          {/* ==================== TAB: REPORTS & FINANCIAL AUDIT ==================== */}
          {activeTab === 'reports' && (
            <AdminReportsTab
              orders={orders}
              products={products}
              storeSettings={storeSettings}
            />
          )}

          {/* ==================== TAB: BACKUP & DATA TOOLS ==================== */}
          {activeTab === 'backup' && (
            <AdminBackupTab
              products={products}
              categories={categories}
              orders={orders}
              storeSettings={storeSettings}
              adminToken={adminToken}
              updateStoreSettings={updateStoreSettings}
            />
          )}

          {/* ==================== TAB: WHATSAPP NOTIFICATIONS & TEMPLATE ENGINE ==================== */}
          {activeTab === 'whatsapp' && (
            <AdminWhatsAppNotificationsTab
              storeSettings={storeSettings}
              updateStoreSettings={updateStoreSettings}
            />
          )}

          {/* ==================== TAB: COUPONS & DISCOUNTS ==================== */}
          {activeTab === 'coupons' && <AdminCouponsTab />}

          {/* ==================== TAB: FLASH SALES ==================== */}
          {activeTab === 'flash_sales' && <AdminFlashSalesTab />}

          {/* ==================== TAB: REVIEWS MODERATION ==================== */}
          {activeTab === 'reviews' && <AdminReviewsTab />}

          {/* ==================== TAB: RETURNS & REFUNDS ==================== */}
          {activeTab === 'returns' && <AdminReturnsTab />}

          {/* ==================== TAB: MULTI-VENDOR MARKETPLACE ==================== */}
          {activeTab === 'vendors' && <AdminVendorsTab />}

          {/* ==================== TAB: PROMOTIONAL OFFERS & BANNERS ==================== */}
          {activeTab === 'offers' && <AdminOffersTab />}

          {/* ==================== TAB: ENTERPRISE INTEGRATIONS & LOGISTICS ==================== */}
          {activeTab === 'integrations' && <AdminIntegrationsTab />}

          {/* ==================== TAB: THEME, LAYOUT & FEATURE TOGGLES ==================== */}
          {activeTab === 'theme_layout' && <AdminThemeLayoutTab />}

        </div>
      </main>
    </div>

      {/* Customer WhatsApp Notification Modal */}
      {selectedWhatsAppOrder && (
        <OrderWhatsAppModal
          isOpen={Boolean(selectedWhatsAppOrder)}
          onClose={() => setSelectedWhatsAppOrder(null)}
          order={selectedWhatsAppOrder}
          storeSettings={storeSettings}
        />
      )}

      {/* 4x6 Thermal Shipping Label Modal */}
      {selectedShippingLabelOrder && (
        <ShippingLabelModal
          isOpen={!!selectedShippingLabelOrder}
          onClose={() => setSelectedShippingLabelOrder(null)}
          order={selectedShippingLabelOrder}
          storeSettings={storeSettings}
          onOrderUpdated={(orderId, updates) => {
            updateOrderStatus(orderId, selectedShippingLabelOrder.status, {
              courierPartner: updates.courierPartner,
              trackingId: updates.trackingId,
            });
            setSelectedShippingLabelOrder((prev: any) => prev ? { ...prev, ...updates } : null);
          }}
        />
      )}

      {/* Tax Invoice Modal */}
      {selectedInvoiceOrder && (
        <AdminInvoiceModal
          isOpen={Boolean(selectedInvoiceOrder)}
          onClose={() => setSelectedInvoiceOrder(null)}
          order={selectedInvoiceOrder}
          storeSettings={storeSettings}
        />
      )}

      {/* Multi-Party Safe Delete Request Modal */}
      {deleteRequestTarget && (
        <DeleteRequestModal
          isOpen={!!deleteRequestTarget}
          onClose={() => setDeleteRequestTarget(null)}
          targetType={deleteRequestTarget.type}
          targetId={deleteRequestTarget.id}
          targetSummary={deleteRequestTarget.summary}
          adminEmail={adminProfile?.email || 'admin@infostors.com'}
          adminRole={(adminProfile?.role as any) || 'admin'}
          adminName={adminProfile?.name}
          onSubmitRequest={handleSubmitDeleteRequest}
        />
      )}

      {/* Update Courier Partner & Tracking Dispatch Modal */}
      {dispatchModalOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-blue-400" />
                <h3 className="font-bold text-sm">Update Courier & Tracking</h3>
              </div>
              <button
                type="button"
                onClick={() => setDispatchModalOrder(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveDispatchDetails} className="p-5 space-y-4">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900">
                <div className="font-bold">Order #{dispatchModalOrder.orderId}</div>
                <div className="text-[11px] text-blue-700 mt-0.5">
                  Recipient: {dispatchModalOrder.customer.fullName} ({dispatchModalOrder.customer.city}, {dispatchModalOrder.customer.state})
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Courier Partner Name *
                </label>
                <input
                  type="text"
                  required
                  list="courier-partner-list"
                  value={dispatchCourierInput}
                  onChange={e => setDispatchCourierInput(e.target.value)}
                  placeholder="e.g. Delhivery Express, BlueDart, DTDC, XpressBees"
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500"
                />
                <datalist id="courier-partner-list">
                  <option value="Delhivery Express" />
                  <option value="Blue Dart Express" />
                  <option value="DTDC Courier" />
                  <option value="XpressBees" />
                  <option value="Ecom Express" />
                  <option value="Shadowfax" />
                  <option value="India Post Speed Post" />
                </datalist>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  AWB / Tracking Number *
                </label>
                <input
                  type="text"
                  required
                  value={dispatchTrackingInput}
                  onChange={e => setDispatchTrackingInput(e.target.value.trim())}
                  placeholder="e.g. DEL7823901452IN"
                  className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-blue-500 uppercase"
                />
                <p className="text-[10px] text-slate-500 mt-1">
                  Tracking number will appear on 4×6 thermal shipping labels and update customer tracking directly.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setDispatchModalOrder(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={dispatchLoading}
                  className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>{dispatchLoading ? 'Saving...' : 'Save Dispatch Details'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Direct Message Modal (Section 17) */}
      <CustomerMessageModal
        isOpen={!!selectedMessageCustomer}
        onClose={() => setSelectedMessageCustomer(null)}
        customer={selectedMessageCustomer}
        adminToken={adminToken}
        adminName={adminProfile?.name || 'INFOSTORS Staff'}
      />
    </div>
  );
};
