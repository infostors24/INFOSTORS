import React, { useState, useEffect } from 'react';
import { MessageCircle, Download } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const UnifiedFloatingActions: React.FC = () => {
  const { storeSettings } = useShop();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    }
  };

  const handleWhatsApp = () => {
    const phone = storeSettings.helpline?.replace(/[^0-9]/g, '') || '919477839200';
    const cleanPhone = phone.startsWith('91') ? phone : `91${phone}`;
    const text = encodeURIComponent('Hi INFOSTORS Support! I have a question regarding products on your store.');
    window.open(`https://wa.me/${cleanPhone}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed bottom-20 sm:bottom-6 right-3 sm:right-6 z-40 flex flex-col items-end gap-2.5 pointer-events-none">
      {/* Optional Install PWA App Floating Button */}
      {deferredPrompt && (
        <button
          onClick={handleInstall}
          className="pointer-events-auto flex items-center gap-2 px-3.5 py-2 rounded-full bg-slate-900/90 hover:bg-slate-900 text-white text-xs font-bold shadow-lg border border-slate-700/60 backdrop-blur-md active:scale-95 transition-all group"
          title="Install INFOSTORS App"
        >
          <div className="w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center text-white">
            <Download className="w-3.5 h-3.5" />
          </div>
          <span className="hidden sm:inline">Install App</span>
        </button>
      )}

      {/* WhatsApp Help Floating Action */}
      <button
        onClick={handleWhatsApp}
        className="pointer-events-auto flex items-center gap-2 p-3 sm:px-4 sm:py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xl shadow-emerald-600/30 hover:shadow-emerald-600/50 active:scale-95 transition-all"
        title="Chat with Us on WhatsApp"
        aria-label="WhatsApp Support"
      >
        <MessageCircle className="w-5 h-5 fill-current" />
        <span className="hidden sm:inline font-bold">WhatsApp Support</span>
      </button>
    </div>
  );
};
