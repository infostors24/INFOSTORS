import React, { useState, useRef, useEffect } from 'react';
import { 
  Search, 
  ShoppingCart, 
  Heart, 
  User, 
  Menu, 
  X, 
  Sparkles, 
  MapPin, 
  Phone,
  MessageCircle,
  SlidersHorizontal,
  ChevronDown,
  ShieldCheck,
  Sun,
  Moon,
  Package,
  LogOut,
  ExternalLink
} from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { InfostorsLogo } from './InfostorsLogo';
import { AppInstallNavButton } from './pwa/AppInstallNavButton';
import { DeliveryLocationModal } from './DeliveryLocationModal';
import { OrderTrackingModal } from './customer/OrderTrackingModal';
import { CategoriesModal } from './customer/CategoriesModal';

export const Header: React.FC = () => {
  const {
    categories,
    storeSettings,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    cartCount,
    cartSubtotal,
    wishlist,
    setIsCartOpen,
    setIsWishlistOpen,
    setIsAccountOpen,
    setPolicyModal,
    deliveryLocation,
    setDeliveryLocation,
    isLocationModalOpen,
    setIsLocationModalOpen,
    customer,
    customerLogout,
    themeMode,
    setThemeMode,
  } = useShop();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [accountDropdownOpen, setAccountDropdownOpen] = useState(false);
  const accountDropdownRef = useRef<HTMLDivElement>(null);
  const [pinCode, setPinCode] = useState('700084');
  const [isEditingPin, setIsEditingPin] = useState(false);
  const [tempPin, setTempPin] = useState('700084');
  const [isTrackingModalOpen, setIsTrackingModalOpen] = useState(false);
  const [isCategoriesModalOpen, setIsCategoriesModalOpen] = useState(false);

  // Close account dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (accountDropdownRef.current && !accountDropdownRef.current.contains(event.target as Node)) {
        setAccountDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempPin.trim().length === 6) {
      setPinCode(tempPin.trim());
      setIsEditingPin(false);
    }
  };

  const trendingTags = [
    { label: 'Earbuds', catId: 'audio-sound' },
    { label: 'Smartwatches', catId: 'electronics' },
    { label: 'GaN Chargers', catId: 'mobile-accessories' },
    { label: 'Massage Guns', catId: 'massagers' },
    { label: 'RGB Lights', catId: 'rgb-lights' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/98 dark:bg-slate-900/98 backdrop-blur-md border-b border-slate-200/90 dark:border-slate-800 shadow-sm transition-colors duration-200">
      {/* Top micro announcement bar */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-700 text-white text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 font-medium tracking-wide">
            <span className="bg-amber-400 text-slate-950 font-bold px-1.5 py-0.5 rounded text-[10px] uppercase">
              Free Delivery
            </span>
            <span className="hidden sm:inline">{storeSettings.announcement}</span>
            <span className="sm:hidden">Free Delivery above ₹{storeSettings.freeDeliveryMin}</span>
          </div>

          <div className="flex items-center gap-3 sm:gap-4 text-slate-200 text-[11px]">
            <button 
              onClick={() => setIsTrackingModalOpen(true)}
              className="hover:text-white transition-colors cursor-pointer hidden md:inline flex items-center gap-1 font-medium"
            >
              <span>Track Order</span>
            </button>
            <span className="hidden sm:inline">•</span>
            <a 
              href={`mailto:${storeSettings.email}`}
              className="hover:text-white transition-colors cursor-pointer hidden lg:inline"
            >
              Support: {storeSettings.email}
            </a>
            <span className="hidden sm:inline">•</span>
            <a
              href={`tel:${(storeSettings.helpline || '+919477839200').replace(/[^0-9+]/g, '')}`}
              className="text-blue-100 hover:text-white transition-colors cursor-pointer inline-flex items-center gap-1 font-semibold"
              title={`Call Customer Helpline: ${storeSettings.helpline}`}
              id="header-helpline-link"
            >
              <Phone className="w-3.5 h-3.5 text-blue-200" />
              <span>{storeSettings.helpline}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Header Row */}
      <div className="max-w-7xl mx-auto px-3 sm:px-4 pt-1.5 pb-2">
        {/* Mobile View: Balanced 3-part layout (Menu - Centered Logo - Wishlist & Cart) */}
        <div className="flex md:hidden items-center justify-between gap-1.5 sm:gap-2">
          {/* Left: Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 -ml-1 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl cursor-pointer shrink-0 transition-colors"
            id="header-mobile-menu-button"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          {/* Center: Perfectly Centered, Sharp INFOSTORS Logo */}
          <div className="flex-1 flex justify-center items-center min-w-0 px-1">
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center justify-center text-center group cursor-pointer hover:opacity-95 transition-all"
              id="infostors-brand-logo-mobile"
              title="INFOSTORS - Smart Gadgets | Better Life"
            >
              <InfostorsLogo 
                className="h-8 xs:h-10 sm:h-12 w-auto max-w-[160px] xs:max-w-[210px] sm:max-w-[260px] drop-shadow-xs transition-transform duration-200 group-hover:scale-[1.02]" 
              />
            </button>
          </div>

          {/* Right: Wishlist & Cart Quick Actions */}
          <div className="flex items-center gap-1 shrink-0">
            {/* Wishlist */}
            <button
              onClick={() => setIsWishlistOpen(true)}
              className="relative p-2 text-slate-700 dark:text-slate-200 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50/60 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
              id="header-wishlist-button-mobile"
              title="Wishlist"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute 0.5 top-0.5 right-0.5 bg-rose-500 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-700 dark:text-blue-300 rounded-xl transition-all border border-blue-200/90 dark:border-blue-800 cursor-pointer shadow-xs"
              id="header-cart-button-mobile"
              title="View Cart"
              aria-label="View Cart"
            >
              <ShoppingCart className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-blue-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Desktop View: 12-column grid with PIN selector, centered prominent Logo, and Account/Cart */}
        <div className="hidden md:grid md:grid-cols-12 items-center gap-4">
          {/* Left Column (3 cols): Delivery Pin & Helpline Info */}
          <div className="col-span-3 flex items-center gap-2.5">
            {/* Indian PIN Delivery Selector with Location Modal */}
            <button
              type="button"
              onClick={() => setIsLocationModalOpen(true)}
              className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100/90 dark:hover:bg-slate-700/80 border border-slate-200/80 dark:border-slate-700 px-2.5 py-1.5 rounded-xl shrink-0 transition-colors text-left cursor-pointer group"
              title="Click to select delivery location"
              id="header-delivery-location-btn"
            >
              <MapPin className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 group-hover:scale-110 transition-transform" />
              <div>
                <div className="text-[10px] text-slate-400 font-medium leading-tight">Deliver to</div>
                <div className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-0.5 leading-tight">
                  <span className="truncate max-w-[100px]">{deliveryLocation.area || deliveryLocation.city || deliveryLocation.pincode}</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </div>
              </div>
            </button>

            {/* Helpline quick badge (WhatsApp/Call) */}
            <a
              href="https://wa.me/919477839200"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden lg:flex items-center gap-1.5 text-xs text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 border border-emerald-200/80 dark:border-emerald-800 px-2.5 py-1.5 rounded-xl transition-colors shrink-0"
              title="Chat on WhatsApp: +91 94778 39200"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <div className="text-left">
                <span className="text-[9px] text-emerald-600 dark:text-emerald-400 font-bold block uppercase tracking-wider leading-none">WhatsApp</span>
                <span className="font-bold text-[11px] leading-tight">+91 94778 39200</span>
              </div>
            </a>
          </div>

          {/* Center Column (6 cols): Perfectly Centered, Large, Crisp INFOSTORS Logo */}
          <div className="col-span-6 flex justify-center items-center">
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center justify-center text-center group cursor-pointer hover:opacity-95 transition-all p-1"
              id="infostors-brand-logo"
              title="INFOSTORS - Smart Gadgets | Better Life"
            >
              <InfostorsLogo 
                className="h-16 md:h-20 lg:h-24 w-auto max-w-[320px] md:max-w-[400px] lg:max-w-[460px] drop-shadow-md transition-transform duration-200 group-hover:scale-[1.02]" 
              />
            </button>
          </div>

          {/* Right Column (3 cols): Account, Wishlist, Cart Actions */}
          <div className="col-span-3 flex items-center justify-end gap-2 lg:gap-3">
            {/* Quick Install Android App Button */}
            <AppInstallNavButton variant="header" />

            {/* Account / Login with Dropdown */}
            <div className="relative" ref={accountDropdownRef}>
              <button
                type="button"
                onClick={() => setAccountDropdownOpen(!accountDropdownOpen)}
                className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-2 text-slate-700 dark:text-slate-200 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100/80 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer select-none"
                id="header-account-button"
                title={customer ? `Signed in as ${customer.fullName}` : 'Account & Orders'}
              >
                <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300 shrink-0">
                  <User className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                </div>
                <div className="hidden xl:flex flex-col text-left">
                  <span className="text-[10px] text-slate-400 font-medium">
                    {customer ? 'Welcome back' : 'Orders & Account'}
                  </span>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-100 leading-tight flex items-center gap-1">
                    <span>{customer ? `Hi, ${customer.fullName.split(' ')[0]}` : 'Sign In'}</span>
                    <ChevronDown className="w-3 h-3 text-slate-400" />
                  </span>
                </div>
              </button>

              {/* Desktop Account Dropdown Menu */}
              {accountDropdownOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 py-2.5 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800">
                    <div className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                      {customer ? customer.fullName : 'Welcome to INFOSTORS'}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {customer ? customer.email : 'Sign in to access your orders & rewards'}
                    </div>
                  </div>

                  <div className="py-1 border-b border-slate-100 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => {
                        setIsAccountOpen(true);
                        setAccountDropdownOpen(false);
                      }}
                      className="w-full px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5 transition-colors cursor-pointer text-left"
                    >
                      <User className="w-4 h-4 text-blue-600" />
                      <span>{customer ? 'My Profile & Dashboard' : 'Sign In / Register'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setIsAccountOpen(true);
                        setAccountDropdownOpen(false);
                      }}
                      className="w-full px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5 transition-colors cursor-pointer text-left"
                    >
                      <Package className="w-4 h-4 text-blue-600" />
                      <span>My Orders</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setIsWishlistOpen(true);
                        setAccountDropdownOpen(false);
                      }}
                      className="w-full px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5 transition-colors cursor-pointer text-left"
                    >
                      <Heart className="w-4 h-4 text-rose-500" />
                      <span>My Wishlist ({wishlist.length})</span>
                    </button>
                  </div>

                  {/* Theme Switcher inside Profile Menu */}
                  <div className="px-4 py-2.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                      {themeMode === 'dark' ? <Moon className="w-3.5 h-3.5 text-indigo-400" /> : <Sun className="w-3.5 h-3.5 text-amber-500" />}
                      <span>Theme</span>
                    </span>

                    <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-lg p-0.5 border border-slate-200 dark:border-slate-700">
                      <button
                        type="button"
                        onClick={() => setThemeMode('light')}
                        className={`p-1 px-2 rounded-md text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer ${
                          themeMode === 'light'
                            ? 'bg-white text-slate-900 shadow-2xs'
                            : 'text-slate-500 hover:text-slate-900'
                        }`}
                      >
                        <Sun className="w-3 h-3 text-amber-500" />
                        <span>Light</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setThemeMode('dark')}
                        className={`p-1 px-2 rounded-md text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer ${
                          themeMode === 'dark'
                            ? 'bg-slate-900 text-white shadow-2xs'
                            : 'text-slate-500 hover:text-slate-900'
                        }`}
                      >
                        <Moon className="w-3 h-3 text-indigo-400" />
                        <span>Dark</span>
                      </button>
                    </div>
                  </div>

                  {customer && (
                    <div className="pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          customerLogout();
                          setAccountDropdownOpen(false);
                        }}
                        className="w-full px-4 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-2 transition-colors cursor-pointer text-left"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Wishlist */}
            <button
              onClick={() => setIsWishlistOpen(true)}
              className="relative p-2 text-slate-700 dark:text-slate-200 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50/60 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
              id="header-wishlist-button"
              title="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-extrabold w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative flex items-center gap-2 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-700 dark:text-blue-300 font-semibold px-3 py-2 rounded-xl transition-all border border-blue-200/90 dark:border-blue-800 cursor-pointer shadow-xs group shrink-0"
              id="header-cart-button"
              title="View Cart"
            >
              <div className="relative">
                <ShoppingCart className="w-5 h-5 text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-blue-600 text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900">
                    {cartCount}
                  </span>
                )}
              </div>
              <div className="hidden sm:flex flex-col text-left">
                <span className="text-[10px] text-blue-600/80 dark:text-blue-400/80 font-medium">Cart</span>
                <span className="text-xs font-black text-blue-900 dark:text-blue-100 leading-none">
                  {cartSubtotal > 0 ? `₹${cartSubtotal.toLocaleString('en-IN')}` : '₹0'}
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* Integrated Centered Search Bar & Category Selector */}
        <div className="mt-2 pb-1">
          <div className="max-w-3xl mx-auto">
            <div className="relative flex items-center bg-slate-100/90 dark:bg-slate-800/90 hover:bg-slate-100 dark:hover:bg-slate-800 focus-within:bg-white dark:focus-within:bg-slate-900 border border-slate-300/80 dark:border-slate-700 focus-within:border-blue-500 dark:focus-within:border-blue-400 rounded-2xl shadow-xs transition-all focus-within:ring-3 focus-within:ring-blue-500/15">
              
              {/* Category selector inside search */}
              <div className="hidden sm:flex items-center pl-3 pr-2 border-r border-slate-200 dark:border-slate-700">
                <select
                  value={selectedCategory}
                  onChange={e => {
                    setSelectedCategory(e.target.value);
                    const el = document.getElementById('products-grid-section');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="bg-transparent text-xs font-semibold text-slate-700 dark:text-slate-200 outline-none cursor-pointer pr-1 py-2 max-w-[140px] truncate"
                >
                  <option value="all" className="dark:bg-slate-900 dark:text-slate-100">All Categories</option>
                  {categories.filter(c => c.id !== 'all').map(c => (
                    <option key={c.id} value={c.id} className="dark:bg-slate-900 dark:text-slate-100">
                      {c.emoji} {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Search text input */}
              <div className="relative flex-1 flex items-center">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search for smart gadgets, chargers, soundbars, kitchen products..."
                  className="w-full pl-9 pr-28 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 outline-none bg-transparent"
                  id="search-input-header"
                />

                {searchQuery ? (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-18 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs px-1.5 py-0.5 rounded cursor-pointer"
                  >
                    Clear
                  </button>
                ) : null}

                <button
                  onClick={() => {
                    const el = document.getElementById('products-grid-section');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="absolute right-1.5 px-3 sm:px-4 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 active:from-blue-800 active:to-indigo-800 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
                >
                  Search
                </button>
              </div>
            </div>

            {/* Quick Trending tags */}
            <div className="hidden sm:flex items-center justify-center gap-2 mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-semibold text-slate-400 dark:text-slate-500">🔥 Trending:</span>
              {trendingTags.map(tag => (
                <button
                  key={tag.label}
                  onClick={() => {
                    setSelectedCategory(tag.catId);
                    const el = document.getElementById('products-grid-section');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="hover:text-blue-600 dark:hover:text-blue-400 hover:underline cursor-pointer"
                >
                  {tag.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-4 space-y-4 shadow-xl">
          {/* Profile & Account Section with Embedded Dark/Light Mode Switch */}
          <div className="bg-slate-50 dark:bg-slate-800/80 rounded-2xl p-3.5 border border-slate-200/90 dark:border-slate-700/80 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-950/80 border border-blue-200 dark:border-blue-800 flex items-center justify-center text-blue-600 shrink-0">
                  <User className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                    {customer ? customer.fullName : 'Account & Orders'}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {customer ? customer.email : 'Sign in to track orders & rewards'}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setIsAccountOpen(true);
                  setMobileMenuOpen(false);
                }}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shrink-0 cursor-pointer shadow-xs"
              >
                {customer ? 'Manage' : 'Sign In'}
              </button>
            </div>

            {/* Strictly Placed Inside Profile/Account Section: Dark / Light Mode Toggle */}
            <div className="pt-2.5 border-t border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                {themeMode === 'dark' ? <Moon className="w-3.5 h-3.5 text-indigo-400" /> : <Sun className="w-3.5 h-3.5 text-amber-500" />}
                <span>Theme Mode</span>
              </span>

              <div className="flex items-center bg-slate-200/80 dark:bg-slate-700/80 p-0.5 rounded-xl border border-slate-300/60 dark:border-slate-600/60">
                <button
                  type="button"
                  onClick={() => setThemeMode('light')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    themeMode === 'light'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
                  }`}
                  title="Switch to Light Theme"
                >
                  <Sun className="w-3 h-3 text-amber-500" />
                  <span>Light</span>
                </button>
                <button
                  type="button"
                  onClick={() => setThemeMode('dark')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    themeMode === 'dark'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
                  }`}
                  title="Switch to Dark Theme"
                >
                  <Moon className="w-3 h-3 text-indigo-400" />
                  <span>Dark</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick Actions Links */}
          <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
            <button
              type="button"
              onClick={() => {
                setIsAccountOpen(true);
                setMobileMenuOpen(false);
              }}
              className="p-2.5 bg-slate-50 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl border border-slate-200/80 dark:border-slate-700 flex items-center gap-2 cursor-pointer transition-colors"
            >
              <Package className="w-4 h-4 text-blue-600" />
              <span>My Orders</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setIsWishlistOpen(true);
                setMobileMenuOpen(false);
              }}
              className="p-2.5 bg-slate-50 dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl border border-slate-200/80 dark:border-slate-700 flex items-center gap-2 cursor-pointer transition-colors"
            >
              <Heart className="w-4 h-4 text-rose-500" />
              <span>Wishlist ({wishlist.length})</span>
            </button>
          </div>

          {/* Categories */}
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 block">
              Shop Categories
            </span>
            <div className="grid grid-cols-2 gap-2">
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    setMobileMenuOpen(false);
                    const el = document.getElementById('products-grid-section');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`flex items-center gap-2 p-2 rounded-xl text-xs font-medium text-left transition-colors cursor-pointer ${
                    selectedCategory === cat.id
                      ? 'bg-blue-50 text-blue-700 font-bold border border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800'
                      : 'bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-200 hover:bg-slate-100 border border-slate-200/60 dark:border-slate-700/60'
                  }`}
                >
                  <span className="text-base">{cat.emoji}</span>
                  <span className="truncate">{cat.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-slate-100 dark:border-slate-800 pt-3">
            <AppInstallNavButton variant="mobile" className="w-full justify-center" />
          </div>
        </div>
      )}

      {/* Delivery Location Selector Modal */}
      <DeliveryLocationModal
        isOpen={isLocationModalOpen}
        onClose={() => setIsLocationModalOpen(false)}
        currentLocation={deliveryLocation}
        onSaveLocation={setDeliveryLocation}
      />

      {/* Live Order Tracking Modal */}
      <OrderTrackingModal
        isOpen={isTrackingModalOpen}
        onClose={() => setIsTrackingModalOpen(false)}
      />

      {/* Categories Showcase Modal */}
      <CategoriesModal
        isOpen={isCategoriesModalOpen}
        onClose={() => setIsCategoriesModalOpen(false)}
      />
    </header>
  );
};
