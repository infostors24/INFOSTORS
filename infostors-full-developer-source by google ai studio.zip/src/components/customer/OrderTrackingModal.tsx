import React, { useState, useEffect } from 'react';
import { X, Search, Package, Truck, CheckCircle2, Clock, AlertCircle, MapPin, ExternalLink } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Order } from '../../types';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialOrderId?: string;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  initialOrderId = '',
}) => {
  const { orders } = useShop();
  const [searchQuery, setSearchQuery] = useState(initialOrderId);
  const [searchedOrder, setSearchedOrder] = useState<Order | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  useEffect(() => {
    if (initialOrderId) {
      setSearchQuery(initialOrderId);
      handleSearch(initialOrderId);
    }
  }, [initialOrderId, isOpen]);

  if (!isOpen) return null;

  const handleSearch = (idToSearch?: string) => {
    const query = (idToSearch || searchQuery).trim().toLowerCase();
    if (!query) return;
    setHasSearched(true);
    const found = orders.find(
      o => o.id.toLowerCase() === query || 
           o.customerMobile?.includes(query) ||
           o.customerEmail?.toLowerCase() === query
    ) || null;
    setSearchedOrder(found);
  };

  const steps = [
    { title: 'Order Confirmed', status: 'confirmed' },
    { title: 'Processing & Packed', status: 'processing' },
    { title: 'Shipped / Dispatched', status: 'shipped' },
    { title: 'Delivered', status: 'delivered' },
  ];

  const getStepIndex = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'processing': return 1;
      case 'shipped': return 2;
      case 'delivered': return 3;
      default: return 0;
    }
  };

  const currentStep = searchedOrder ? getStepIndex(searchedOrder.status) : 0;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Track Your Order</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Real-time express shipment tracking</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-5 border-b border-slate-200/80 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSearch()}
                placeholder="Enter Order ID (e.g. ORD-...) or Mobile"
                className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <button
              onClick={() => handleSearch()}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition-colors"
            >
              Track
            </button>
          </div>
        </div>

        {/* Result Area */}
        <div className="p-5 max-h-[60vh] overflow-y-auto">
          {searchedOrder ? (
            <div className="space-y-6">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-500">Order ID:</span>
                    <span className="font-mono font-bold text-sm ml-1 text-slate-900 dark:text-white">{searchedOrder.id}</span>
                  </div>
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase ${
                    searchedOrder.status === 'delivered' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-400' :
                    searchedOrder.status === 'cancelled' ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/80 dark:text-rose-400' :
                    'bg-blue-100 text-blue-700 dark:bg-blue-950/80 dark:text-blue-400'
                  }`}>
                    {searchedOrder.status}
                  </span>
                </div>
                {searchedOrder.courierPartner && (
                  <div className="mt-2 pt-2 border-t border-slate-200 dark:border-slate-700/60 text-xs text-slate-600 dark:text-slate-300 flex items-center justify-between">
                    <span>Courier: <strong>{searchedOrder.courierPartner}</strong></span>
                    <span>Tracking: <strong className="font-mono">{searchedOrder.trackingId || 'In Transit'}</strong></span>
                  </div>
                )}
              </div>

              {/* Timeline Steps */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Delivery Status Timeline</h4>
                <div className="relative pl-6 space-y-6 border-l-2 border-slate-200 dark:border-slate-800 ml-3">
                  {steps.map((s, idx) => {
                    const isDone = idx <= currentStep && searchedOrder.status !== 'cancelled';
                    return (
                      <div key={idx} className="relative">
                        <div className={`absolute -left-[31px] top-0 w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                          isDone ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30' : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                        }`}>
                          {isDone ? <CheckCircle2 className="w-3.5 h-3.5" /> : idx + 1}
                        </div>
                        <div>
                          <p className={`text-xs font-bold ${isDone ? 'text-slate-900 dark:text-white' : 'text-slate-400'}`}>{s.title}</p>
                          {isDone && idx === currentStep && (
                            <p className="text-[11px] text-blue-600 dark:text-blue-400 mt-0.5">Current Status</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : hasSearched ? (
            <div className="py-8 text-center text-slate-500 space-y-2">
              <AlertCircle className="w-10 h-10 text-slate-400 mx-auto" />
              <p className="font-semibold text-sm">No order found matching "{searchQuery}"</p>
              <p className="text-xs">Please verify your Order ID or registered mobile number.</p>
            </div>
          ) : (
            <div className="py-8 text-center text-slate-400 space-y-2">
              <Package className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-700" />
              <p className="text-xs">Enter your order ID above to see live dispatch and tracking updates.</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
