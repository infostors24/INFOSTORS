import React, { useState, useEffect } from 'react';
import { Download } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

interface AppInstallNavButtonProps {
  variant?: string;
  className?: string;
}

export const AppInstallNavButton: React.FC<AppInstallNavButtonProps> = ({ className = '' }) => {
  const { storeSettings } = useShop();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setIsInstallable(false);
      }
      setDeferredPrompt(null);
    }
  };

  if (!isInstallable) return null;

  return (
    <button
      onClick={handleInstall}
      className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800/60 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors ${className}`}
      title={`Install ${storeSettings.storeName || 'INFOSTORS'} App`}
    >
      <Download className="w-3.5 h-3.5" />
      <span className="hidden md:inline">Install App</span>
    </button>
  );
};
