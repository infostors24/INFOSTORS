import React from 'react';
import { CheckCircle2, X, Package, Truck, ArrowRight } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const OrderConfirmationModal: React.FC = () => {
  const { isOrderSuccessOpen, setIsOrderSuccessOpen, activeOrder, storeSettings, setIsAccountOpen } = useShop();

  if (!isOrderSuccessOpen || !activeOrder) return null;

  const orderId = activeOrder.orderId || activeOrder.id || 'INF-ORDER';
  const customerName = activeOrder.shippingAddress?.fullName || activeOrder.customer?.fullName || activeOrder.customerName || 'Customer';
  const address = activeOrder.shippingAddress?.address || activeOrder.customer?.address || '';
  const city = activeOrder.shippingAddress?.city || activeOrder.customer?.city || '';
  const pincode = activeOrder.shippingAddress?.pincode || activeOrder.customer?.pincode || '';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Success Banner */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 p-6 text-white text-center relative">
          <button
            onClick={() => setIsOrderSuccessOpen(false)}
            className="absolute top-4 right-4 p-1 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="w-16 h-16 mx-auto rounded-full bg-white/20 flex items-center justify-center mb-3">
            <CheckCircle2 className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl font-black">Order Placed Successfully!</h2>
          <p className="text-emerald-100 text-xs mt-1">Thank you for shopping with {storeSettings.storeName || 'INFOSTORS'}</p>
        </div>

        {/* Details */}
        <div className="p-6 space-y-4 text-sm text-slate-700 dark:text-slate-300">
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Order ID</p>
              <p className="font-mono font-bold text-slate-900 dark:text-white">{orderId}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-500 dark:text-slate-400">Total Amount</p>
              <p className="font-bold text-emerald-600 dark:text-emerald-400">₹{activeOrder.totalAmount?.toLocaleString('en-IN')}</p>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span>Items Purchased</span>
              <span>{activeOrder.items?.length || 0} product(s)</span>
            </div>
            <div className="max-h-40 overflow-y-auto space-y-2 pr-1">
              {activeOrder.items?.map((item, idx) => (
                <div key={idx} className="flex items-center gap-3 p-2 rounded-lg bg-slate-50 dark:bg-slate-800/40">
                  <img src={item.product?.image} alt={item.product?.name} className="w-10 h-10 object-cover rounded-md" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">{item.product?.name}</p>
                    <p className="text-[11px] text-slate-500">Qty: {item.quantity} × ₹{item.product?.price}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {address && (
            <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-800/60 flex items-start gap-2.5">
              <Truck className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
              <div className="text-xs text-blue-900 dark:text-blue-200">
                <p className="font-semibold">Delivering To:</p>
                <p className="text-blue-700 dark:text-blue-300 mt-0.5">
                  {customerName}, {address}, {city} - {pincode}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex flex-wrap gap-2 justify-end">
          <button
            onClick={() => {
              setIsOrderSuccessOpen(false);
              setIsAccountOpen(true);
            }}
            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl font-bold text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          >
            <Package className="w-4 h-4" />
            <span>View in Account</span>
          </button>
          <button
            onClick={() => setIsOrderSuccessOpen(false)}
            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-500 text-white shadow-md transition-colors"
          >
            <span>Continue Shopping</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
