import React, { useState, useEffect } from 'react';
import { 
  X, 
  Star, 
  Heart, 
  ShoppingBag, 
  Zap, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Check, 
  MapPin, 
  Plus, 
  Minus,
  Sparkles,
  Share2,
  ExternalLink,
  MessageSquare
} from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { Review } from '../types';

export const ProductDetailModal: React.FC = () => {
  const {
    selectedProduct,
    setSelectedProduct,
    addToCart,
    buyNow,
    toggleWishlist,
    isInWishlist,
    cart,
    featureFlags,
    fetchProductReviews,
    submitReview,
    customer,
  } = useShop();

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [pinCode, setPinCode] = useState('110001');
  const [checkedPin, setCheckedPin] = useState(false);
  const [copied, setCopied] = useState(false);

  // Reviews state
  const [productReviews, setProductReviews] = useState<Review[]>([]);
  const [isWritingReview, setIsWritingReview] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewAuthor, setReviewAuthor] = useState('');
  const [reviewSubmitting, setReviewSubmitting] = useState(false);
  const [reviewSuccessMsg, setReviewSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    if (selectedProduct) {
      fetchProductReviews(selectedProduct.id).then(revs => {
        if (Array.isArray(revs)) setProductReviews(revs);
      });
      setReviewAuthor(customer?.fullName || '');
    }
  }, [selectedProduct, customer]);

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct || !reviewComment.trim()) return;

    setReviewSubmitting(true);
    const res = await submitReview(
      selectedProduct.id,
      reviewRating,
      reviewComment.trim(),
      reviewAuthor.trim() || undefined
    );
    setReviewSubmitting(false);

    if (res.success) {
      setReviewSuccessMsg('Review submitted successfully! Thank you for your feedback.');
      setReviewComment('');
      setIsWritingReview(false);
      fetchProductReviews(selectedProduct.id).then(revs => {
        if (Array.isArray(revs)) setProductReviews(revs);
      });
      setTimeout(() => setReviewSuccessMsg(null), 4000);
    }
  };

  if (!selectedProduct) return null;

  const validImages = (
    selectedProduct.images && selectedProduct.images.length > 0
      ? selectedProduct.images
      : [selectedProduct.image]
  )
    .map(url => (typeof url === 'string' ? url.trim() : ''))
    .filter(url => url.length > 0);

  const images = validImages.length > 0 ? validImages : [selectedProduct.image];
  const safeActiveIndex = activeImageIndex < images.length ? activeImageIndex : 0;
  const currentImage = images[safeActiveIndex] || selectedProduct.image;
  const isLiked = isInWishlist(selectedProduct.id);
  const cartItem = cart.find(item => item.product.id === selectedProduct.id);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCheckPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinCode.length === 6) {
      setCheckedPin(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 md:p-6 animate-in fade-in duration-200">
      <div 
        className="relative bg-white dark:bg-slate-900 w-full max-w-4xl rounded-xl sm:rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 overflow-hidden my-auto max-h-[92vh] flex flex-col transition-colors duration-200"
        id="product-detail-modal-card"
      >
        {/* Top bar with close button */}
        <div className="flex items-center justify-between px-3.5 sm:px-5 py-2.5 sm:py-3.5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 shrink-0">
          <div className="flex items-center gap-1.5 sm:gap-2 text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium truncate min-w-0">
            <span>Store</span>
            <span>/</span>
            <span className="capitalize">{selectedProduct.category.replace('-', ' ')}</span>
            <span>/</span>
            <span className="text-slate-800 dark:text-slate-200 font-semibold truncate max-w-[120px] sm:max-w-[200px]">
              {selectedProduct.brand}
            </span>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              onClick={handleShare}
              className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer"
              title="Share product link"
            >
              <Share2 className="w-4 h-4" />
              <span className="hidden sm:inline">{copied ? 'Link Copied!' : 'Share'}</span>
            </button>

            <button
              onClick={() => setSelectedProduct(null)}
              className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-3.5 sm:p-6 flex-1">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 sm:gap-8">
            {/* Left: Gallery (5 cols) */}
            <div className="md:col-span-5 space-y-4">
              {/* Main large image with zoom hover */}
              <div className="relative aspect-square w-full bg-slate-50 rounded-2xl border border-slate-200/80 p-6 flex items-center justify-center overflow-hidden group">
                <img
                  src={currentImage}
                  alt={selectedProduct.name}
                  className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-300"
                />

                {selectedProduct.discount > 0 && (
                  <span className="absolute top-3 left-3 bg-blue-600 text-white font-extrabold text-xs px-2.5 py-1 rounded-md shadow-sm">
                    {selectedProduct.discount}% OFF
                  </span>
                )}

                <button
                  onClick={() => toggleWishlist(selectedProduct.id)}
                  className={`absolute top-3 right-3 p-2 rounded-full shadow-md transition-all cursor-pointer ${
                    isLiked
                      ? 'bg-rose-50 text-rose-600 ring-1 ring-rose-200'
                      : 'bg-white/90 text-slate-400 hover:text-rose-500'
                  }`}
                  title="Add to Wishlist"
                >
                  <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                </button>

                {/* Open Link for current image */}
                <a
                  href={currentImage}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute bottom-3 right-3 px-2 py-1 bg-white/95 hover:bg-white text-slate-700 hover:text-blue-600 rounded-lg shadow-sm border border-slate-200 text-[10px] font-bold flex items-center gap-1 transition-all backdrop-blur-xs cursor-pointer"
                  title="Open full image in new tab"
                >
                  <ExternalLink className="w-3 h-3 text-blue-500" />
                  <span>Open Image</span>
                </a>
              </div>

              {/* Thumbnail strip - strictly displays ONLY the provided images and hides empty image boxes */}
              {images.length > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto pb-1" id="product-detail-thumbnails">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIndex(idx)}
                      className={`w-16 h-16 rounded-xl border p-1 bg-slate-50 shrink-0 transition-all cursor-pointer ${
                        safeActiveIndex === idx
                          ? 'border-blue-600 ring-2 ring-blue-500/20 shadow-xs'
                          : 'border-slate-200 hover:border-slate-300 opacity-70 hover:opacity-100'
                      }`}
                      title={`View angle ${idx + 1}`}
                    >
                      <img src={img} alt="" className="w-full h-full object-contain" />
                    </button>
                  ))}
                </div>
              )}

              {/* Guarantees Box */}
              <div className="bg-slate-50 border border-slate-200/70 rounded-xl p-3.5 space-y-2 text-xs text-slate-700">
                <div className="flex items-center gap-2 font-semibold text-slate-900">
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                  <span>INFOSTORS Assured Quality</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 pt-1">
                  <div className="flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-slate-500" />
                    <span>Free Shipping &gt; ₹499</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                    <span>7 Days Replacement</span>
                  </div>
                </div>
                {selectedProduct.warranty && (
                  <div className="text-[11px] text-emerald-700 font-medium pt-1 border-t border-slate-200">
                    🛡️ {selectedProduct.warranty}
                  </div>
                )}
              </div>
            </div>

            {/* Right: Details & Purchase Options (7 cols) */}
            <div className="md:col-span-7 space-y-5">
              <div>
                <div className="text-xs font-bold text-blue-600 uppercase tracking-wide">
                  {selectedProduct.brand}
                </div>
                <h1 className="text-xl sm:text-2xl font-black text-slate-950 mt-1 leading-snug">
                  {selectedProduct.name}
                </h1>
                
                {/* Rating Bar */}
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex items-center gap-1 bg-emerald-600 text-white text-xs font-bold px-2 py-0.5 rounded">
                    <span>{selectedProduct.rating}</span>
                    <Star className="w-3 h-3 fill-white text-white" />
                  </div>
                  <span className="text-xs text-slate-500">
                    {selectedProduct.reviewsCount.toLocaleString('en-IN')} Ratings & Verified Reviews
                  </span>
                </div>
              </div>

              {/* Price Block */}
              <div className="p-4 bg-slate-50/80 rounded-2xl border border-slate-200/80 space-y-1">
                <div className="flex items-baseline gap-3">
                  <span className="text-2xl sm:text-3xl font-black text-slate-950">
                    ₹{selectedProduct.price.toLocaleString('en-IN')}
                  </span>
                  {selectedProduct.originalPrice > selectedProduct.price && (
                    <>
                      <span className="text-sm text-slate-400 line-through">
                        ₹{selectedProduct.originalPrice.toLocaleString('en-IN')}
                      </span>
                      <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                        Save ₹{(selectedProduct.originalPrice - selectedProduct.price).toLocaleString('en-IN')} ({selectedProduct.discount}%)
                      </span>
                    </>
                  )}
                </div>
                <div className="text-[11px] text-slate-500">
                  Inclusive of all taxes. Cash on delivery eligible.
                </div>
              </div>

              {/* Stock Status & Quantity selector */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-700">Availability:</span>
                  {selectedProduct.stock > 0 ? (
                    <span className="text-emerald-700 bg-emerald-50 font-bold px-2 py-0.5 rounded flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                      In Stock ({selectedProduct.stock} units available)
                    </span>
                  ) : (
                    <span className="text-rose-600 font-bold">Currently Out of Stock</span>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs font-semibold text-slate-700">Quantity:</span>
                  <div className="flex items-center border border-slate-200 rounded-xl bg-white shadow-xs">
                    <button
                      onClick={() => setQuantity(q => Math.max(1, q - 1))}
                      disabled={quantity <= 1}
                      className="p-2 text-slate-600 hover:text-blue-600 disabled:opacity-30 cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-3 text-xs font-bold text-slate-900">{quantity}</span>
                    <button
                      onClick={() => setQuantity(q => Math.min(selectedProduct.stock, q + 1))}
                      disabled={quantity >= selectedProduct.stock}
                      className="p-2 text-slate-600 hover:text-blue-600 disabled:opacity-30 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2 sm:gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => addToCart(selectedProduct, quantity)}
                  className="py-3 px-2 sm:px-4 bg-slate-900 hover:bg-slate-800 active:bg-slate-950 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 sm:gap-2 cursor-pointer"
                  id="detail-add-to-cart"
                >
                  <ShoppingBag className="w-4 h-4 shrink-0" />
                  <span className="hidden sm:inline">
                    {cartItem ? `Add More (${cartItem.quantity} in cart)` : 'Add to Cart'}
                  </span>
                  <span className="sm:hidden">
                    {cartItem ? `+ Add (${cartItem.quantity})` : 'Add to Cart'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => buyNow(selectedProduct, quantity)}
                  className="py-3 px-2 sm:px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg shadow-blue-600/30 hover:shadow-blue-600/50 transition-all flex items-center justify-center gap-1.5 sm:gap-2 cursor-pointer"
                  id="detail-buy-now"
                >
                  <Zap className="w-4 h-4 fill-white shrink-0" />
                  <span>Buy Now</span>
                </button>
              </div>

              {/* PIN Code Delivery Checker */}
              <div className="p-3.5 border border-slate-200/90 rounded-xl space-y-2 bg-slate-50/50">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                  <MapPin className="w-3.5 h-3.5 text-blue-600" />
                  <span>Delivery Options & Estimated Date</span>
                </div>
                <form onSubmit={handleCheckPin} className="flex gap-2">
                  <input
                    type="text"
                    maxLength={6}
                    value={pinCode}
                    onChange={e => {
                      setPinCode(e.target.value.replace(/\D/g, ''));
                      setCheckedPin(false);
                    }}
                    placeholder="Enter 6 digit PIN code"
                    className="flex-1 px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg outline-none focus:border-blue-500"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-lg cursor-pointer transition-colors"
                  >
                    Check
                  </button>
                </form>
                {checkedPin && (
                  <div className="text-xs text-emerald-700 bg-emerald-50 p-2 rounded-lg space-y-1">
                    <div className="font-bold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      <span>Delivery available to {pinCode}</span>
                    </div>
                    <div className="text-[11px] text-slate-600">
                      Standard Express: Delivered within 2-3 business days. Cash on Delivery is supported.
                    </div>
                  </div>
                )}
              </div>

              {/* Description & Key Features */}
              <div className="space-y-3 pt-2">
                <h3 className="font-bold text-sm text-slate-900">Product Overview</h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {selectedProduct.description}
                </p>

                <h3 className="font-bold text-sm text-slate-900 pt-2">Key Highlights</h3>
                <ul className="space-y-1.5">
                  {selectedProduct.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-slate-600">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-1.5 shrink-0"></span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Customer Reviews & Ratings Section (Controlled by featureFlags.reviews) */}
              {featureFlags.reviews && (
                <div className="pt-4 border-t border-slate-200 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                        <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                        <span>Customer Reviews & Ratings</span>
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {selectedProduct.rating} out of 5 stars based on verified purchases
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => setIsWritingReview(!isWritingReview)}
                      className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold rounded-xl transition cursor-pointer"
                    >
                      {isWritingReview ? 'Cancel' : 'Write a Review'}
                    </button>
                  </div>

                  {reviewSuccessMsg && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{reviewSuccessMsg}</span>
                    </div>
                  )}

                  {/* Write Review Form */}
                  {isWritingReview && (
                    <form onSubmit={handleSubmitReview} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                      <h4 className="font-bold text-xs text-slate-800">Your Rating & Review</h4>

                      {/* Star rating selector */}
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map(star => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setReviewRating(star)}
                            className="p-1 cursor-pointer focus:outline-none"
                          >
                            <Star
                              className={`w-5 h-5 transition-transform hover:scale-110 ${
                                star <= reviewRating
                                  ? 'text-amber-400 fill-amber-400'
                                  : 'text-slate-300'
                              }`}
                            />
                          </button>
                        ))}
                        <span className="text-xs font-bold text-slate-700 ml-2">
                          {reviewRating === 5 ? 'Excellent' : reviewRating === 4 ? 'Very Good' : reviewRating === 3 ? 'Average' : reviewRating === 2 ? 'Poor' : 'Terrible'}
                        </span>
                      </div>

                      <div>
                        <input
                          type="text"
                          value={reviewAuthor}
                          onChange={e => setReviewAuthor(e.target.value)}
                          placeholder="Your Name (e.g. Swattik S.)"
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500"
                        />
                      </div>

                      <div>
                        <textarea
                          rows={3}
                          required
                          value={reviewComment}
                          onChange={e => setReviewComment(e.target.value)}
                          placeholder="What did you like or dislike about this product? How is the build quality and performance?"
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl outline-none focus:border-blue-500 resize-none"
                        />
                      </div>

                      <div className="flex justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setIsWritingReview(false)}
                          className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 font-semibold cursor-pointer"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          disabled={reviewSubmitting}
                          className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition cursor-pointer"
                        >
                          {reviewSubmitting ? 'Posting...' : 'Submit Review'}
                        </button>
                      </div>
                    </form>
                  )}

                  {/* Reviews List */}
                  <div className="space-y-3 pt-1">
                    {productReviews.length > 0 ? (
                      productReviews.slice(0, 5).map(rev => (
                        <div key={rev.id} className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl space-y-1.5 text-xs">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-900">{rev.customerName}</span>
                              <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-semibold flex items-center gap-0.5">
                                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                                <span>Verified Buyer</span>
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-400">
                              {new Date(rev.createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' })}
                            </span>
                          </div>

                          <div className="flex items-center gap-0.5">
                            {[1, 2, 3, 4, 5].map(s => (
                              <Star
                                key={s}
                                className={`w-3.5 h-3.5 ${
                                  s <= rev.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-300'
                                }`}
                              />
                            ))}
                          </div>

                          <p className="text-slate-700 leading-relaxed">{rev.comment}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-slate-400 italic">
                        No reviews yet for this product. Be the first to write a review!
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
