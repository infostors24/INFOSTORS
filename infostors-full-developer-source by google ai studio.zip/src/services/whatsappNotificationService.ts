import { WhatsAppNotificationSettings } from '../types';

export const DEFAULT_WHATSAPP_NOTIFICATION_SETTINGS: WhatsAppNotificationSettings = {
  businessNumber: '+919477839200',
  autoPromptOnStatusChange: true,
  enabledTypes: {
    order_confirmed: true,
    order_processing: true,
    order_dispatched: true,
    out_for_delivery: true,
    order_delivered: true,
    order_cancelled: true,
    payment_received: true,
  },
  templates: {
    order_confirmed: {
      title: 'Order Confirmed',
      body: 'Hi {{customer_name}}, thank you for shopping with INFOSTORS! Your order #{{order_id}} has been confirmed.',
    },
    order_processing: {
      title: 'Order Processing',
      body: 'Hi {{customer_name}}, your order #{{order_id}} is being packed and prepared for dispatch.',
    },
    order_dispatched: {
      title: 'Order Dispatched',
      body: 'Hi {{customer_name}}, your order #{{order_id}} has been shipped with {{courier_partner}}. Tracking ID: {{tracking_id}}.',
    },
    out_for_delivery: {
      title: 'Out for Delivery',
      body: 'Hi {{customer_name}}, your order #{{order_id}} is out for delivery today.',
    },
    order_delivered: {
      title: 'Order Delivered',
      body: 'Hi {{customer_name}}, your order #{{order_id}} has been successfully delivered. Enjoy your smart gadgets!',
    },
    order_cancelled: {
      title: 'Order Cancelled',
      body: 'Hi {{customer_name}}, your order #{{order_id}} has been cancelled. Any refund due will be processed shortly.',
    },
    payment_received: {
      title: 'Payment Received',
      body: 'Hi {{customer_name}}, payment of ₹{{amount}} for order #{{order_id}} has been received.',
    },
  },
};

export function buildWhatsAppMessage(template: string, data: Record<string, string>): string {
  let message = template;
  for (const [key, value] of Object.entries(data)) {
    message = message.replaceAll(`{{${key}}}`, value || '');
  }
  return message;
}

export function openWhatsAppChat(phone: string, text: string) {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}
