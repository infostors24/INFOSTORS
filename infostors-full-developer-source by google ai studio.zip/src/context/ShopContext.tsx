import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { 
  Product, 
  CartItem, 
  CustomerDetails, 
  Order, 
  PaymentMethod, 
  PackageStatus, 
  Category, 
  StoreSettings,
  Customer,
  AdminProfile,
  AdminUser,
  AdminRole,
  DEFAULT_PWA_SETTINGS,
  DeliveryLocation,
  FeatureFlags,
  DEFAULT_FEATURE_FLAGS,
  ThemeMode,
  ThemeSettings,
  DEFAULT_THEME_SETTINGS,
  LayoutSettings,
  DEFAULT_LAYOUT_SETTINGS,
  Coupon,
  FlashSale,
  Review,
  ReturnRequest,
  RefundRecord,
  LoyaltyTransaction,
  WalletTransaction,
  PromotionalOffer,
  Vendor,
  ReportSummary
} from '../types';
import { DEFAULT_WHATSAPP_NOTIFICATION_SETTINGS } from '../services/whatsappNotificationService';
import { INITIAL_PRODUCTS, CATEGORIES } from '../data/products';

interface ShopContextType {
  products: Product[];
  categories: Category[];
  cart: CartItem[];
  wishlist: string[];
  orders: Order[];
  searchQuery: string;
  selectedCategory: string;
  selectedSection: 'all' | 'trending' | 'bestseller' | 'new' | 'deals';
  sortBy: 'featured' | 'price-low' | 'price-high' | 'rating' | 'discount';
  selectedProduct: Product | null;
  isCartOpen: boolean;
  isWishlistOpen: boolean;
  isCheckoutOpen: boolean;
  isAccountOpen: boolean;
  isAdminOpen: boolean;
  isOrderSuccessOpen: boolean;
  activeOrder: Order | null;
  policyModal: string | null;
  userEmail: string;
  storeSettings: StoreSettings;

  // Feature Flags
  featureFlags: FeatureFlags;
  isFeatureEnabled: (feature: keyof FeatureFlags) => boolean;
  updateFeatureFlags: (flags: Partial<FeatureFlags>) => Promise<void>;

  // Theme & Dark Mode
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  themeSettings: ThemeSettings;
  updateThemeSettings: (settings: Partial<ThemeSettings>) => Promise<void>;

  // Layout Settings
  layoutSettings: LayoutSettings;
  updateLayoutSettings: (settings: Partial<LayoutSettings>) => Promise<void>;

  // 1. Coupons
  coupons: Coupon[];
  activeCoupons: Coupon[];
  appliedCoupon: Coupon | null;
  couponDiscount: number;
  applyCoupon: (code: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  removeCoupon: () => void;
  saveCoupon: (coupon: Partial<Coupon>) => Promise<{ success: boolean; error?: string; coupon?: Coupon }>;
  deleteCoupon: (id: string) => Promise<{ success: boolean; error?: string }>;

  // 2. Flash Sales
  flashSales: FlashSale[];
  activeFlashSales: FlashSale[];
  saveFlashSale: (sale: Partial<FlashSale>) => Promise<{ success: boolean; error?: string; flashSale?: FlashSale }>;
  deleteFlashSale: (id: string) => Promise<{ success: boolean; error?: string }>;

  // 3. Reviews & Ratings
  reviews: Review[];
  fetchProductReviews: (productId: string) => Promise<Review[]>;
  submitReview: (productId: string, rating: number, comment: string, customerName?: string) => Promise<{ success: boolean; error?: string }>;
  moderateReview: (id: string, status: 'approved' | 'rejected') => Promise<{ success: boolean; error?: string }>;
  deleteReview: (id: string) => Promise<{ success: boolean; error?: string }>;

  // 4. Returns
  returns: ReturnRequest[];
  customerReturns: ReturnRequest[];
  submitReturnRequest: (orderId: string, items: any[], reason: string, description?: string) => Promise<{ success: boolean; error?: string }>;
  updateReturnStatus: (id: string, status: string, adminNotes?: string) => Promise<{ success: boolean; error?: string }>;

  // 5. Refunds
  refunds: RefundRecord[];
  processRefund: (payload: Partial<RefundRecord>) => Promise<{ success: boolean; error?: string }>;
  updateRefundStatus: (id: string, status: string, notes?: string) => Promise<{ success: boolean; error?: string }>;

  // 6. Loyalty & Rewards
  loyaltyBalance: number;
  loyaltyTransactions: LoyaltyTransaction[];
  redeemedLoyaltyDiscount: number;
  redeemLoyaltyPoints: (points: number) => { pointsRedeemed: number; discountAmount: number };
  clearLoyaltyRedemption: () => void;

  // 7. Customer Wallet
  walletBalance: number;
  walletTransactions: WalletTransaction[];
  useWalletBalance: boolean;
  setUseWalletBalance: (use: boolean) => void;
  walletDeduction: number;

  // 8. Promotional Offers
  offers: PromotionalOffer[];
  activeOffers: PromotionalOffer[];
  saveOffer: (offer: Partial<PromotionalOffer>) => Promise<{ success: boolean; error?: string }>;
  deleteOffer: (id: string) => Promise<{ success: boolean; error?: string }>;

  // 9. Multi-Vendor
  vendors: Vendor[];
  saveVendor: (vendor: Partial<Vendor>) => Promise<{ success: boolean; error?: string }>;
  deleteVendor: (id: string) => Promise<{ success: boolean; error?: string }>;

  // 10. Advanced Reports
  fetchAdvancedReports: (range?: string) => Promise<ReportSummary | null>;

  setSearchQuery: (query: string) => void;
  setSelectedCategory: (cat: string) => void;
  setSelectedSection: (sec: 'all' | 'trending' | 'bestseller' | 'new' | 'deals') => void;
  setSortBy: (sort: 'featured' | 'price-low' | 'price-high' | 'rating' | 'discount') => void;
  setSelectedProduct: (p: Product | null) => void;
  setIsCartOpen: (open: boolean) => void;
  setIsWishlistOpen: (open: boolean) => void;
  setIsCheckoutOpen: (open: boolean) => void;
  setIsAccountOpen: (open: boolean) => void;
  setIsAdminOpen: (open: boolean) => void;
  setIsOrderSuccessOpen: (open: boolean) => void;
  setActiveOrder: (order: Order | null) => void;
  setPolicyModal: (policy: string | null) => void;
  setUserEmail: (email: string) => void;

  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  buyNow: (product: Product, quantity?: number) => void;
  buyNowItem: CartItem | null;
  isBuyNowMode: boolean;
  cancelBuyNow: () => void;
  activeCheckoutItems: CartItem[];
  activeCheckoutSubtotal: number;
  activeCheckoutSavings: number;
  activeCheckoutDeliveryCharge: number;
  activeCheckoutGstAmount: number;
  activeCheckoutGrandTotal: number;

  cartCount: number;
  cartSubtotal: number;
  cartSavings: number;
  deliveryCharge: number;
  gstAmount: number;
  gstRate: number;
  isGstActive: boolean;
  gstType: 'inclusive' | 'exclusive';
  cartGrandTotal: number;

  deliveryLocation: DeliveryLocation;
  setDeliveryLocation: (loc: DeliveryLocation) => void;
  isLocationModalOpen: boolean;
  setIsLocationModalOpen: (open: boolean) => void;

  placeOrder: (customer: CustomerDetails, paymentMethod: PaymentMethod, upiApp?: string, upiId?: string, razorpayPaymentId?: string) => Order;
  confirmOrderSuccess: (order: Order) => void;
  addProduct: (product: Product) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;

  addCategory: (category: Category) => void;
  updateCategory: (category: Category) => void;
  deleteCategory: (categoryId: string) => void;

  updateOrderStatus: (orderId: string, status: PackageStatus, details?: { courierPartner?: string; trackingId?: string; resolution?: string }) => Promise<any> | void;
  updateStoreSettings: (settings: Partial<StoreSettings>) => Promise<{ success: boolean; message?: string; error?: string }>;
  refreshStoreSettings: () => Promise<void>;

  // Customer Authentication & Account Management
  customer: Customer | null;
  customerToken: string | null;
  isCustomerLoading: boolean;
  customerOrders: Order[];
  customerRegister: (fullName: string, email: string, mobile: string, password: string, confirmPassword: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  customerLogin: (identifier: string, password: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  customerLogout: () => void;
  customerUpdateProfile: (fullName: string, email: string, mobile: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  customerChangePassword: (currentPassword: string, newPassword: string, confirmPassword: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  customerForgotPassword: (email: string) => Promise<{ success: boolean; message?: string; previewLink?: string; error?: string }>;
  customerResetPassword: (token: string, newPassword: string, confirmPassword: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  resetTokenParam: string | null;
  setResetTokenParam: (token: string | null) => void;

  // Admin Authentication & Session
  adminProfile: AdminProfile | null;
  adminToken: string | null;
  isAdminAuthenticated: boolean;
  adminGoogleLogin: (payload: { credential?: string; email?: string; name?: string; picture?: string }) => Promise<{ success: boolean; message?: string; error?: string }>;
  adminEmailPasswordLogin: (payload: { email: string; identifier?: string; password?: string; mobile?: string }) => Promise<{ success: boolean; message?: string; error?: string }>;
  adminLogout: () => void;
  fetchAdminList: () => Promise<AdminUser[]>;
  createAdmin: (admin: { fullName: string; email: string; mobile: string; role?: AdminRole }) => Promise<{ success: boolean; message?: string; error?: string; admin?: AdminUser }>;
  modifyAdmin: (id: string, updates: Partial<AdminUser>) => Promise<{ success: boolean; message?: string; error?: string; admin?: AdminUser }>;
  removeAdmin: (id: string) => Promise<{ success: boolean; message?: string; error?: string }>;
}

const DEFAULT_SETTINGS: StoreSettings = {
  storeName: 'INFOSTORS',
  tagline: 'Smart Gadgets | Better Life',
  logoUrl: '',
  headerLogoHeight: 72,
  helpline: '+91 94778 39200 (Toll Free / WhatsApp)',
  email: 'contactinfostors@gmail.com',
  officeAddress: 'INFOSTORS Headquarters, Garia station road, Kolkata 700084, India',
  freeDeliveryMin: 499,
  announcement: 'Free Delivery on all orders above ₹499 across India',
  whatsappUrl: 'https://wa.me/919477839200',
  whatsapp: 'https://wa.me/919477839200',
  instagram: 'https://www.instagram.com/infostors',
  facebook: 'https://www.facebook.com/Infostors',
  youtube: 'https://www.youtube.com/@InfoStors',
  returnWindow: '7 Days Replacement Guarantee',

  // Delivery Charge Configuration
  standardDeliveryCharge: 49,
  enableFreeDeliveryThreshold: true,

  // Full Profile GST Configuration
  gstEnabled: false,
  gstin: '19AAACI1234F1Z8',
  businessLegalName: 'INFOSTORS ENTERPRISES PRIVATE LIMITED',
  tradeName: 'INFOSTORS',
  gstPercentage: 18,
  gstType: 'inclusive',
  gstState: '19 - West Bengal',
  showGstinOnInvoice: true,
  allowCustomerB2bGst: true,

  // PWA Settings
  pwaSettings: DEFAULT_PWA_SETTINGS,

  // WhatsApp Order Notifications Settings
  whatsappNotificationSettings: DEFAULT_WHATSAPP_NOTIFICATION_SETTINGS,

  // 4x6 Shipping Label & Thermal Bill Settings
  shippingLabelSettings: {
    showCustomerEmail: false,
    showCustomerMobile: true,
    showPickupLocation: true,
    showPickupContact: true,
    showCourierPartner: true,
    showTrackingId: true,
    showOrderId: true,
    showPaymentMethod: true,
    showProductDetails: true,
    showPrices: true,
    showBarcode: true,
    showDataMatrix: true,
    autoPdfAfterFinalize: false,
    pickupLocation: {
      companyName: 'INFOSTORS Logistics Hub',
      address: 'Garia Station Road, Near Metro Gate 2',
      city: 'Kolkata',
      state: 'West Bengal',
      pincode: '700084',
      contactNumber: '+91 94778 39200',
    },
    branding: {
      logoEnabled: true,
      logoUrl: '',
      showOnInvoice: true,
      showOnLabel: true,
      alignment: 'left',
      size: 'medium',
    },
  },

  featureFlags: DEFAULT_FEATURE_FLAGS,
  themeSettings: DEFAULT_THEME_SETTINGS,
  layoutSettings: DEFAULT_LAYOUT_SETTINGS,
};

const INITIAL_ORDERS: Order[] = [
  {
    orderId: 'INF-8924',
    customerId: 'cust-demo-001',
    date: new Date(Date.now() - 86400000 * 2).toISOString(),
    customer: {
      fullName: 'Rahul Sharma',
      phone: '9477839200',
      email: 'rahul@infostors.com',
      address: 'Flat 402, Green Valley Apartments, MG Road',
      city: 'Kolkata',
      state: 'West Bengal',
      pincode: '700084',
    },
    items: [
      { product: INITIAL_PRODUCTS[0], quantity: 1 },
      { product: INITIAL_PRODUCTS[3], quantity: 1 },
    ],
    subtotal: 2698,
    deliveryCharge: 0,
    discountSavings: 3100,
    totalAmount: 2698,
    paymentMethod: 'upi',
    upiApp: 'gpay',
    status: 'dispatched',
    estimatedDeliveryDate: 'Fri, 25 Sept',
  },
  {
    orderId: 'INF-7412',
    customerId: 'cust-demo-002',
    date: new Date(Date.now() - 86400000 * 5).toISOString(),
    customer: {
      fullName: 'Priya Mukherjee',
      phone: '9830123456',
      email: 'priya.m@gmail.com',
      address: 'House 18, Southern Avenue',
      city: 'Kolkata',
      state: 'West Bengal',
      pincode: '700029',
    },
    items: [
      { product: INITIAL_PRODUCTS[5], quantity: 1 },
    ],
    subtotal: 1899,
    deliveryCharge: 0,
    discountSavings: 2100,
    totalAmount: 1899,
    paymentMethod: 'cod',
    status: 'delivered',
    estimatedDeliveryDate: 'Wed, 23 Sept',
  },
];

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('infostors_products');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_PRODUCTS;
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('infostors_categories');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error(e);
      }
    }
    return CATEGORIES;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('infostors_cart');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [];
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('infostors_wishlist');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return ['inf-101', 'inf-104'];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('infostors_orders');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_ORDERS;
  });

  const [storeSettings, setStoreSettings] = useState<StoreSettings>(() => {
    const saved = localStorage.getItem('infostors_settings');
    if (saved) {
      try {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      } catch (e) {
        console.error(e);
      }
    }
    return DEFAULT_SETTINGS;
  });

  const [userEmail, setUserEmail] = useState<string>(() => {
    return localStorage.getItem('infostors_user_email') || 'contactinfostors@gmail.com';
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedSection, setSelectedSection] = useState<'all' | 'trending' | 'bestseller' | 'new' | 'deals'>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'rating' | 'discount'>('featured');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [buyNowItem, setBuyNowItem] = useState<CartItem | null>(null);

  const handleSetIsCheckoutOpen = (open: boolean) => {
    setIsCheckoutOpen(open);
    if (!open) {
      setBuyNowItem(null);
    }
  };

  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isOrderSuccessOpen, setIsOrderSuccessOpen] = useState(false);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [policyModal, setPolicyModal] = useState<string | null>(null);

  // ─────────────────────────────────────────────────────────────
  // DELIVERY LOCATION STATE
  // ─────────────────────────────────────────────────────────────
  const [deliveryLocation, setDeliveryLocationState] = useState<DeliveryLocation>(() => {
    try {
      const saved = localStorage.getItem('infostors_delivery_location');
      if (saved) return JSON.parse(saved);
    } catch (_) {}
    return {
      pincode: '700084',
      city: 'Kolkata',
      state: 'West Bengal',
      area: 'Kolkata',
      formattedAddress: 'Kolkata, West Bengal - 700084',
    };
  });

  const setDeliveryLocation = useCallback((loc: DeliveryLocation) => {
    setDeliveryLocationState(loc);
    try {
      localStorage.setItem('infostors_delivery_location', JSON.stringify(loc));
    } catch (_) {}
  }, []);

  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);

  // ─────────────────────────────────────────────────────────────
  // CUSTOMER AUTH STATE
  // ─────────────────────────────────────────────────────────────
  const [customer, setCustomer] = useState<Customer | null>(() => {
    const saved = localStorage.getItem('infostors_customer');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return null;
  });

  const [customerToken, setCustomerToken] = useState<string | null>(() => {
    return localStorage.getItem('infostors_customer_token');
  });

  const [isCustomerLoading, setIsCustomerLoading] = useState(false);
  const [resetTokenParam, setResetTokenParam] = useState<string | null>(null);

  // ─────────────────────────────────────────────────────────────
  // 13 MASTER ECOMMERCE STATE & FEATURES
  // ─────────────────────────────────────────────────────────────
  // Feature Flags
  const featureFlags = useMemo(() => storeSettings.featureFlags || DEFAULT_FEATURE_FLAGS, [storeSettings.featureFlags]);
  const isFeatureEnabled = useCallback((feature: keyof FeatureFlags) => {
    return featureFlags[feature] !== false;
  }, [featureFlags]);

  const updateFeatureFlags = async (flags: Partial<FeatureFlags>) => {
    const nextFlags = { ...featureFlags, ...flags };
    await updateStoreSettings({ featureFlags: nextFlags });
  };

  // Theme & Dark Mode
  const applyThemeToDOM = useCallback((mode: ThemeMode) => {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    const body = document.body;
    const isDark = mode === 'dark' || (mode === 'system' && typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);

    if (isDark) {
      root.classList.add('dark');
      root.setAttribute('data-theme', 'dark');
      if (body) {
        body.classList.add('dark');
        body.setAttribute('data-theme', 'dark');
      }
    } else {
      root.classList.remove('dark');
      root.setAttribute('data-theme', 'light');
      if (body) {
        body.classList.remove('dark');
        body.setAttribute('data-theme', 'light');
      }
    }
  }, []);

  const [themeMode, setThemeModeState] = useState<ThemeMode>(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const saved = localStorage.getItem('infostors_theme_mode');
        if (saved === 'dark' || saved === 'light' || saved === 'system') return saved;
      }
    } catch (_) {}
    return 'light';
  });

  const setThemeMode = useCallback((mode: ThemeMode) => {
    setThemeModeState(mode);
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem('infostors_theme_mode', mode);
      }
    } catch (_) {}
    applyThemeToDOM(mode);
  }, [applyThemeToDOM]);

  const themeSettings = useMemo(() => storeSettings.themeSettings || DEFAULT_THEME_SETTINGS, [storeSettings.themeSettings]);

  const updateThemeSettings = async (settings: Partial<ThemeSettings>) => {
    const nextTheme = { ...themeSettings, ...settings };
    await updateStoreSettings({ themeSettings: nextTheme });
  };

  // Inject CSS variables and dark mode class to documentElement and body
  useEffect(() => {
    applyThemeToDOM(themeMode);

    if (typeof document !== 'undefined') {
      const root = document.documentElement;
      const theme = themeSettings;
      root.style.setProperty('--color-primary', theme.primaryColor);
      root.style.setProperty('--color-secondary', theme.secondaryColor);
      root.style.setProperty('--color-accent', theme.accentColor);
      root.style.setProperty('--color-button', theme.buttonColor);
      root.style.setProperty('--border-radius', theme.borderRadius === 'full' ? '9999px' : theme.borderRadius === 'xl' ? '1rem' : theme.borderRadius === 'lg' ? '0.75rem' : theme.borderRadius === 'md' ? '0.5rem' : '0.25rem');
    }
  }, [themeMode, themeSettings, applyThemeToDOM]);

  // Layout Settings
  const layoutSettings = useMemo(() => storeSettings.layoutSettings || DEFAULT_LAYOUT_SETTINGS, [storeSettings.layoutSettings]);
  const updateLayoutSettings = async (settings: Partial<LayoutSettings>) => {
    const nextLayout = {
      customer: { ...layoutSettings.customer, ...settings.customer },
      admin: { ...layoutSettings.admin, ...settings.admin },
    };
    await updateStoreSettings({ layoutSettings: nextLayout });
  };

  // 1. Coupons
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponDiscount, setCouponDiscount] = useState<number>(0);

  const activeCoupons = useMemo(() => {
    const now = new Date().toISOString();
    return coupons.filter(c => c.isActive && c.startDate <= now && c.expiryDate >= now);
  }, [coupons]);

  const applyCoupon = async (code: string) => {
    try {
      const res = await fetch('/api/coupons/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          subtotal: activeCheckoutSubtotal,
          customerId: customer?.id,
          isFirstOrder: customerOrders.length === 0,
        }),
      });
      const data = await res.json();
      if (!data.success) {
        return { success: false, error: data.error || 'Invalid coupon code.' };
      }
      setAppliedCoupon(data.coupon);
      setCouponDiscount(data.discountAmount || 0);
      return { success: true, message: `Coupon "${data.coupon.code}" applied! You saved ₹${data.discountAmount}.` };
    } catch (e: any) {
      return { success: false, error: 'Failed to apply coupon.' };
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponDiscount(0);
  };

  const saveCoupon = async (couponData: Partial<Coupon>) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch('/api/admin/coupons', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(couponData),
      });
      const data = await res.json();
      if (data.success && data.coupon) {
        setCoupons(prev => {
          const map = new Map(prev.map(c => [c.id, c]));
          map.set(data.coupon.id, data.coupon);
          return Array.from(map.values());
        });
        return { success: true, coupon: data.coupon };
      }
      return { success: false, error: data.error || 'Failed to save coupon.' };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  const deleteCoupon = async (id: string) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch(`/api/admin/coupons/${id}`, {
        method: 'DELETE',
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      const data = await res.json();
      if (data.success) {
        setCoupons(prev => prev.filter(c => c.id !== id));
        if (appliedCoupon?.id === id) removeCoupon();
        return { success: true };
      }
      return { success: false, error: data.error || 'Failed to delete coupon.' };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  // 2. Flash Sales
  const [flashSales, setFlashSales] = useState<FlashSale[]>([]);
  const activeFlashSales = useMemo(() => {
    const now = new Date().toISOString();
    return flashSales.filter(f => f.isActive && f.startDate <= now && f.endDate >= now);
  }, [flashSales]);

  const saveFlashSale = async (saleData: Partial<FlashSale>) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch('/api/admin/flash-sales', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(saleData),
      });
      const data = await res.json();
      if (data.success && data.flashSale) {
        setFlashSales(prev => {
          const map = new Map(prev.map(f => [f.id, f]));
          map.set(data.flashSale.id, data.flashSale);
          return Array.from(map.values());
        });
        return { success: true, flashSale: data.flashSale };
      }
      return { success: false, error: data.error || 'Failed to save flash sale.' };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  const deleteFlashSale = async (id: string) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch(`/api/admin/flash-sales/${id}`, {
        method: 'DELETE',
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      const data = await res.json();
      if (data.success) {
        setFlashSales(prev => prev.filter(f => f.id !== id));
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  // 3. Reviews & Ratings
  const [reviews, setReviews] = useState<Review[]>([]);

  const fetchProductReviews = async (productId: string) => {
    try {
      const res = await fetch(`/api/products/${productId}/reviews`);
      const data = await res.json();
      if (data.success && Array.isArray(data.reviews)) {
        return data.reviews;
      }
    } catch {}
    return reviews.filter(r => r.productId === productId && r.status === 'approved');
  };

  const submitReview = async (productId: string, rating: number, comment: string, customerName?: string) => {
    try {
      const res = await fetch(`/api/products/${productId}/reviews`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(customerToken ? { Authorization: `Bearer ${customerToken}` } : {}),
        },
        body: JSON.stringify({
          rating,
          comment,
          customerName: customerName || customer?.fullName || 'Verified Buyer',
        }),
      });
      const data = await res.json();
      if (data.success && data.review) {
        setReviews(prev => [data.review, ...prev]);
        return { success: true };
      }
      return { success: false, error: data.error || 'Failed to submit review.' };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  const moderateReview = async (id: string, status: 'approved' | 'rejected') => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch(`/api/admin/reviews/${id}/moderate`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      if (data.success) {
        setReviews(prev => prev.map(r => r.id === id ? { ...r, status } : r));
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  const deleteReview = async (id: string) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch(`/api/admin/reviews/${id}`, {
        method: 'DELETE',
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      const data = await res.json();
      if (data.success) {
        setReviews(prev => prev.filter(r => r.id !== id));
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  // 4. Returns
  const [returns, setReturns] = useState<ReturnRequest[]>([]);
  const [refunds, setRefunds] = useState<RefundRecord[]>([]);

  const customerReturns = useMemo(() => {
    if (!customer) return [];
    return returns.filter(r => r.customerId === customer.id || r.customerEmail === customer.email);
  }, [returns, customer]);

  const submitReturnRequest = async (orderId: string, items: any[], reason: string, description?: string) => {
    try {
      const res = await fetch('/api/customer/returns', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(customerToken ? { Authorization: `Bearer ${customerToken}` } : {}),
        },
        body: JSON.stringify({ orderId, items, reason, description }),
      });
      const data = await res.json();
      if (data.success && data.returnRequest) {
        setReturns(prev => [data.returnRequest, ...prev]);
        return { success: true };
      }
      return { success: false, error: data.error || 'Failed to submit return request.' };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  const updateReturnStatus = async (id: string, status: string, adminNotes?: string) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch(`/api/admin/returns/${id}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ status, adminNotes }),
      });
      const data = await res.json();
      if (data.success && data.returnRequest) {
        setReturns(prev => prev.map(r => r.id === id ? data.returnRequest : r));
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  // 5. Refunds
  const processRefund = async (payload: Partial<RefundRecord>) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch('/api/admin/refunds', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.success && data.refund) {
        setRefunds(prev => [data.refund, ...prev]);
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  const updateRefundStatus = async (id: string, status: string, notes?: string) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch(`/api/admin/refunds/${id}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ status, notes }),
      });
      const data = await res.json();
      if (data.success && data.refund) {
        setRefunds(prev => prev.map(r => r.id === id ? data.refund : r));
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  // 6. Loyalty & Rewards
  const [loyaltyBalance, setLoyaltyBalance] = useState<number>(150); // Welcome bonus points
  const [loyaltyTransactions, setLoyaltyTransactions] = useState<LoyaltyTransaction[]>([]);
  const [redeemedLoyaltyDiscount, setRedeemedLoyaltyDiscount] = useState<number>(0);

  const redeemLoyaltyPoints = (points: number) => {
    const maxRedeem = Math.min(points, loyaltyBalance, Math.floor(activeCheckoutSubtotal * 0.2));
    const discount = Math.max(0, maxRedeem);
    setRedeemedLoyaltyDiscount(discount);
    return { pointsRedeemed: maxRedeem, discountAmount: discount };
  };

  const clearLoyaltyRedemption = () => {
    setRedeemedLoyaltyDiscount(0);
  };

  // 7. Customer Wallet
  const [walletBalance, setWalletBalance] = useState<number>(500); // Promotional starting wallet balance
  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>([]);
  const [useWalletBalance, setUseWalletBalance] = useState<boolean>(false);

  // 8. Promotional Offers
  const [offers, setOffers] = useState<PromotionalOffer[]>([]);
  const activeOffers = useMemo(() => {
    const now = new Date().toISOString();
    return offers.filter(o => o.isActive && o.validTill >= now);
  }, [offers]);

  const saveOffer = async (offerData: Partial<PromotionalOffer>) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch('/api/admin/offers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(offerData),
      });
      const data = await res.json();
      if (data.success && data.offer) {
        setOffers(prev => {
          const map = new Map(prev.map(o => [o.id, o]));
          map.set(data.offer.id, data.offer);
          return Array.from(map.values());
        });
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  const deleteOffer = async (id: string) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch(`/api/admin/offers/${id}`, {
        method: 'DELETE',
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      const data = await res.json();
      if (data.success) {
        setOffers(prev => prev.filter(o => o.id !== id));
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  // 9. Multi-Vendor
  const [vendors, setVendors] = useState<Vendor[]>([]);

  const saveVendor = async (vendorData: Partial<Vendor>) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch('/api/admin/vendors', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(vendorData),
      });
      const data = await res.json();
      if (data.success && data.vendor) {
        setVendors(prev => {
          const map = new Map(prev.map(v => [v.id, v]));
          map.set(data.vendor.id, data.vendor);
          return Array.from(map.values());
        });
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  const deleteVendor = async (id: string) => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch(`/api/admin/vendors/${id}`, {
        method: 'DELETE',
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      const data = await res.json();
      if (data.success) {
        setVendors(prev => prev.filter(v => v.id !== id));
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  // 10. Advanced Reports
  const fetchAdvancedReports = async (range = '30d') => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch(`/api/admin/reports/advanced?range=${range}`, {
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      const data = await res.json();
      if (data.success && data.report) {
        return data.report;
      }
    } catch {}
    return null;
  };

  // Fetch initial master features on mount
  useEffect(() => {
    fetch('/api/coupons').then(r => r.json()).then(d => { if (d.success) setCoupons(d.coupons); }).catch(() => {});
    fetch('/api/flash-sales').then(r => r.json()).then(d => { if (d.success) setFlashSales(d.flashSales); }).catch(() => {});
    fetch('/api/offers').then(r => r.json()).then(d => { if (d.success) setOffers(d.offers); }).catch(() => {});
  }, []);

  // ─────────────────────────────────────────────────────────────
  // ADMIN AUTH STATE
  // ─────────────────────────────────────────────────────────────
  const [adminProfile, setAdminProfile] = useState<AdminProfile | null>(() => {
    const saved = localStorage.getItem('infostors_admin_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return null;
  });

  const [adminToken, setAdminToken] = useState<string | null>(() => {
    return localStorage.getItem('infostors_admin_token');
  });

  const isAdminAuthenticated = Boolean(adminToken && adminProfile?.email);

  // Fetch Admin Feature Data when Admin is Authenticated
  useEffect(() => {
    if (adminToken) {
      fetch('/api/admin/coupons', { headers: { Authorization: `Bearer ${adminToken}` } }).then(r => r.json()).then(d => { if (d.success) setCoupons(d.coupons); }).catch(() => {});
      fetch('/api/admin/flash-sales', { headers: { Authorization: `Bearer ${adminToken}` } }).then(r => r.json()).then(d => { if (d.success) setFlashSales(d.flashSales); }).catch(() => {});
      fetch('/api/admin/reviews', { headers: { Authorization: `Bearer ${adminToken}` } }).then(r => r.json()).then(d => { if (d.success) setReviews(d.reviews); }).catch(() => {});
      fetch('/api/admin/returns', { headers: { Authorization: `Bearer ${adminToken}` } }).then(r => r.json()).then(d => { if (d.success) setReturns(d.returns); }).catch(() => {});
      fetch('/api/admin/refunds', { headers: { Authorization: `Bearer ${adminToken}` } }).then(r => r.json()).then(d => { if (d.success) setRefunds(d.refunds); }).catch(() => {});
      fetch('/api/admin/vendors', { headers: { Authorization: `Bearer ${adminToken}` } }).then(r => r.json()).then(d => { if (d.success) setVendors(d.vendors); }).catch(() => {});
    }
  }, [adminToken]);

  // Fetch Customer Features Data when Customer is Logged In
  useEffect(() => {
    if (customerToken) {
      fetch('/api/customer/loyalty', { headers: { Authorization: `Bearer ${customerToken}` } }).then(r => r.json()).then(d => { if (d.success && d.loyalty) { setLoyaltyBalance(d.loyalty.pointsBalance); setLoyaltyTransactions(d.loyalty.transactions || []); } }).catch(() => {});
      fetch('/api/customer/wallet', { headers: { Authorization: `Bearer ${customerToken}` } }).then(r => r.json()).then(d => { if (d.success && d.wallet) { setWalletBalance(d.wallet.balance); setWalletTransactions(d.wallet.transactions || []); } }).catch(() => {});
      fetch('/api/customer/returns', { headers: { Authorization: `Bearer ${customerToken}` } }).then(r => r.json()).then(d => { if (d.success && d.returns) setReturns(d.returns); }).catch(() => {});
    }
  }, [customerToken]);

  // Check URL admin route or reset_token parameter on mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const checkAdminRoute = () => {
        const path = window.location.pathname.toLowerCase();
        const hash = window.location.hash.toLowerCase();
        const params = new URLSearchParams(window.location.search);
        
        if (
          path === '/admin' || 
          path.startsWith('/admin/') || 
          hash === '#admin' || 
          hash.startsWith('#/admin') || 
          params.get('admin') === 'true'
        ) {
          setIsAdminOpen(true);
        }
      };

      checkAdminRoute();
      window.addEventListener('popstate', checkAdminRoute);
      window.addEventListener('hashchange', checkAdminRoute);

      const params = new URLSearchParams(window.location.search);
      const token = params.get('reset_token');
      if (token) {
        setResetTokenParam(token);
        setIsAccountOpen(true);
      }

      return () => {
        window.removeEventListener('popstate', checkAdminRoute);
        window.removeEventListener('hashchange', checkAdminRoute);
      };
    }
  }, []);

  // Sync Customer State to localStorage
  useEffect(() => {
    if (customer) {
      localStorage.setItem('infostors_customer', JSON.stringify(customer));
      setUserEmail(customer.email);
    } else {
      localStorage.removeItem('infostors_customer');
    }
  }, [customer]);

  useEffect(() => {
    if (customerToken) {
      localStorage.setItem('infostors_customer_token', customerToken);
    } else {
      localStorage.removeItem('infostors_customer_token');
    }
  }, [customerToken]);

  // Sync Admin State to localStorage
  useEffect(() => {
    if (adminProfile && adminToken) {
      localStorage.setItem('infostors_admin_profile', JSON.stringify(adminProfile));
      localStorage.setItem('infostors_admin_token', adminToken);
    } else {
      localStorage.removeItem('infostors_admin_profile');
      localStorage.removeItem('infostors_admin_token');
    }
  }, [adminProfile, adminToken]);

  // Validate Admin Session Token on mount
  useEffect(() => {
    if (adminToken) {
      fetch('/api/admin/verify-session', {
        headers: { Authorization: `Bearer ${adminToken}` },
      })
        .then(res => res.json())
        .then(data => {
          if (data && data.success && data.admin) {
            setAdminProfile(data.admin);
          } else {
            // Token expired or invalid
            setAdminToken(null);
            setAdminProfile(null);
            localStorage.removeItem('infostors_admin_token');
            localStorage.removeItem('infostors_admin_profile');
          }
        })
        .catch(() => {
          // On network failure retain current session
        });
    }
  }, []);

  // Fetch live products and categories from primary backend on mount
  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        if (data && data.success && Array.isArray(data.products) && data.products.length > 0) {
          setProducts(data.products);
        }
      })
      .catch(() => {});

    fetch('/api/categories')
      .then(res => res.json())
      .then(data => {
        if (data && data.success && Array.isArray(data.categories) && data.categories.length > 0) {
          setCategories(data.categories);
        }
      })
      .catch(() => {});
  }, []);

  // Sync orders from primary backend for Admin
  useEffect(() => {
    if (adminToken) {
      fetch('/api/admin/orders', {
        headers: { Authorization: `Bearer ${adminToken}` },
      })
        .then(res => res.json())
        .then(data => {
          if (data && data.success && Array.isArray(data.orders)) {
            setOrders(prev => {
              const map = new Map<string, Order>();
              data.orders.forEach((o: any) => {
                map.set(o.id || o.orderId, {
                  orderId: o.id || o.orderId,
                  customerId: o.customerId,
                  date: o.createdAt || o.date,
                  customer: o.customer,
                  items: o.items?.map((it: any) => ({
                    product: it.product || {
                      id: it.productId,
                      name: it.name,
                      price: it.price,
                      image: it.image || '',
                      stock: 10,
                      category: 'electronics',
                      originalPrice: it.price,
                      discount: 0,
                      description: '',
                      shortDescription: '',
                      features: [],
                      rating: 4.8,
                      reviewsCount: 100,
                      brand: 'INFOSTORS',
                    },
                    quantity: it.quantity || 1,
                  })) || [],
                  subtotal: o.subtotal,
                  deliveryCharge: o.shipping ?? o.deliveryCharge ?? 0,
                  discountSavings: o.discount ?? o.discountSavings ?? 0,
                  tax: o.tax,
                  taxBreakdown: o.taxBreakdown,
                  totalAmount: o.finalAmount || o.totalAmount,
                  paymentMethod: o.paymentMethod,
                  paymentStatus: o.paymentStatus,
                  orderStatus: o.orderStatus,
                  status: o.orderStatus === 'confirmed' ? 'received' : o.orderStatus === 'shipped' ? 'dispatched' : o.orderStatus || 'received',
                  courierPartner: o.courierPartner,
                  trackingId: o.trackingId,
                  estimatedDeliveryDate: o.estimatedDeliveryDate,
                  resolution: o.resolution,
                });
              });
              prev.forEach(o => {
                if (!map.has(o.orderId)) map.set(o.orderId, o);
              });
              return Array.from(map.values());
            });
          }
        })
        .catch(() => {});
    }
  }, [adminToken]);

  // Sync orders from primary backend for Customer
  useEffect(() => {
    if (customerToken) {
      fetch('/api/customer/orders', {
        headers: { Authorization: `Bearer ${customerToken}` },
      })
        .then(res => res.json())
        .then(data => {
          if (data && data.success && Array.isArray(data.orders)) {
            setOrders(prev => {
              const map = new Map<string, Order>();
              data.orders.forEach((o: any) => {
                map.set(o.id || o.orderId, {
                  orderId: o.id || o.orderId,
                  customerId: o.customerId,
                  date: o.createdAt || o.date,
                  customer: o.customer,
                  items: o.items?.map((it: any) => ({
                    product: it.product || {
                      id: it.productId,
                      name: it.name,
                      price: it.price,
                      image: it.image || '',
                      stock: 10,
                      category: 'electronics',
                      originalPrice: it.price,
                      discount: 0,
                      description: '',
                      shortDescription: '',
                      features: [],
                      rating: 4.8,
                      reviewsCount: 100,
                      brand: 'INFOSTORS',
                    },
                    quantity: it.quantity || 1,
                  })) || [],
                  subtotal: o.subtotal,
                  deliveryCharge: o.shipping ?? o.deliveryCharge ?? 0,
                  discountSavings: o.discount ?? o.discountSavings ?? 0,
                  tax: o.tax,
                  taxBreakdown: o.taxBreakdown,
                  totalAmount: o.finalAmount || o.totalAmount,
                  paymentMethod: o.paymentMethod,
                  paymentStatus: o.paymentStatus,
                  orderStatus: o.orderStatus,
                  status: o.orderStatus === 'confirmed' ? 'received' : o.orderStatus === 'shipped' ? 'dispatched' : o.orderStatus || 'received',
                  courierPartner: o.courierPartner,
                  trackingId: o.trackingId,
                  estimatedDeliveryDate: o.estimatedDeliveryDate,
                  resolution: o.resolution,
                });
              });
              prev.forEach(o => {
                if (!map.has(o.orderId)) map.set(o.orderId, o);
              });
              return Array.from(map.values());
            });
          }
        })
        .catch(() => {});
    }
  }, [customerToken]);

  // Sync store data to localStorage
  useEffect(() => {
    localStorage.setItem('infostors_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('infostors_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('infostors_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('infostors_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('infostors_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('infostors_settings', JSON.stringify(storeSettings));
  }, [storeSettings]);

  useEffect(() => {
    localStorage.setItem('infostors_user_email', userEmail);
  }, [userEmail]);

  // Customer Orders Filter: strict customer privacy
  // Customer can ONLY view their own orders!
  const customerOrders = useMemo(() => {
    if (!customer) return [];
    const cleanCustomerMobile = customer.mobile.replace(/\D/g, '').slice(-10);
    const customerEmailLower = customer.email.toLowerCase().trim();

    return orders.filter(o => {
      if (o.customerId && o.customerId === customer.id) return true;
      if (o.customer?.email && o.customer.email.toLowerCase().trim() === customerEmailLower) return true;
      if (o.customer?.phone && o.customer.phone.replace(/\D/g, '').slice(-10) === cleanCustomerMobile) return true;
      return false;
    });
  }, [orders, customer]);

  // ─────────────────────────────────────────────────────────────
  // CUSTOMER AUTH METHODS
  // ─────────────────────────────────────────────────────────────
  const customerRegister = async (
    fullName: string,
    email: string,
    mobile: string,
    password: string,
    confirmPassword: string
  ) => {
    setIsCustomerLoading(true);
    try {
      const res = await fetch('/api/customer/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName, email, mobile, password, confirmPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Registration failed' };
      }
      setCustomer(data.customer);
      setCustomerToken(data.token);
      return { success: true, message: data.message || 'Account created successfully.' };
    } catch (err: any) {
      console.error(err);
      return { success: false, error: 'Network error during registration.' };
    } finally {
      setIsCustomerLoading(false);
    }
  };

  const customerLogin = async (identifier: string, password: string) => {
    setIsCustomerLoading(true);
    try {
      const res = await fetch('/api/customer/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Invalid email/mobile number or password.' };
      }
      setCustomer(data.customer);
      setCustomerToken(data.token);
      return { success: true, message: data.message || 'Signed in successfully.' };
    } catch (err: any) {
      console.error(err);
      return { success: false, error: 'Network error during sign in.' };
    } finally {
      setIsCustomerLoading(false);
    }
  };

  const customerLogout = () => {
    setCustomer(null);
    setCustomerToken(null);
    localStorage.removeItem('infostors_customer');
    localStorage.removeItem('infostors_customer_token');
  };

  const customerUpdateProfile = async (fullName: string, email: string, mobile: string) => {
    if (!customerToken) {
      return { success: false, error: 'Please sign in first.' };
    }
    setIsCustomerLoading(true);
    try {
      const res = await fetch('/api/customer/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${customerToken}`,
        },
        body: JSON.stringify({ fullName, email, mobile }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Failed to update profile.' };
      }
      setCustomer(data.customer);
      return { success: true, message: data.message || 'Profile updated successfully.' };
    } catch (err) {
      return { success: false, error: 'Network error during profile update.' };
    } finally {
      setIsCustomerLoading(false);
    }
  };

  const customerChangePassword = async (
    currentPassword: string,
    newPassword: string,
    confirmPassword: string
  ) => {
    if (!customerToken) {
      return { success: false, error: 'Please sign in first.' };
    }
    setIsCustomerLoading(true);
    try {
      const res = await fetch('/api/customer/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${customerToken}`,
        },
        body: JSON.stringify({ currentPassword, newPassword, confirmPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Failed to update password.' };
      }
      return { success: true, message: data.message || 'Your password has been updated successfully.' };
    } catch (err) {
      return { success: false, error: 'Network error during password update.' };
    } finally {
      setIsCustomerLoading(false);
    }
  };

  const customerForgotPassword = async (email: string) => {
    setIsCustomerLoading(true);
    try {
      // Server secure token notification
      const res = await fetch('/api/customer/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      return {
        success: true,
        message: data.message || 'If an account exists with this email, a password reset link has been sent.',
        previewLink: data.previewLink,
      };
    } catch (err) {
      return { success: false, error: 'Network error. Please try again.' };
    } finally {
      setIsCustomerLoading(false);
    }
  };

  const customerResetPassword = async (token: string, newPassword: string, confirmPassword: string) => {
    setIsCustomerLoading(true);
    try {
      const res = await fetch('/api/customer/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, newPassword, confirmPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Failed to reset password.' };
      }
      return { success: true, message: data.message || 'Your password has been updated successfully.' };
    } catch (err) {
      return { success: false, error: 'Network error during password reset.' };
    } finally {
      setIsCustomerLoading(false);
    }
  };

  // ─────────────────────────────────────────────────────────────
  // ADMIN GOOGLE AUTH METHODS
  // ─────────────────────────────────────────────────────────────
  const adminGoogleLogin = async (payload: {
    credential?: string;
    email?: string;
    name?: string;
    picture?: string;
  }) => {
    try {
      const res = await fetch('/api/admin/google-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: data.error || 'Access Denied — This Google account is not authorized as an Admin.',
        };
      }
      setAdminProfile(data.admin);
      setAdminToken(data.token);
      return { success: true, message: data.message || 'Admin authenticated successfully.' };
    } catch (err) {
      console.error('Admin login error:', err);
      return { success: false, error: 'Failed to verify admin credentials with server.' };
    }
  };

  const adminLogout = () => {
    setAdminProfile(null);
    setAdminToken(null);
    localStorage.removeItem('infostors_admin_profile');
    localStorage.removeItem('infostors_admin_token');
  };

  const adminEmailPasswordLogin = async (payload: { email: string; identifier?: string; password?: string; mobile?: string }) => {
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...payload,
          identifier: payload.identifier || payload.email,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: data.error || 'Access Denied — This account is not authorized as an Admin.',
        };
      }
      setAdminProfile(data.admin);
      setAdminToken(data.token);
      return { success: true, message: data.message || 'Admin authenticated successfully.' };
    } catch (err) {
      console.error('Admin login error:', err);
      return { success: false, error: 'Failed to verify admin credentials with server.' };
    }
  };

  const fetchAdminList = async (): Promise<AdminUser[]> => {
    try {
      const res = await fetch('/api/admin/admins', {
        headers: {
          ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {}),
        },
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.admins)) {
        return data.admins;
      }
      return [];
    } catch (err) {
      console.error('Failed to fetch admin list:', err);
      return [];
    }
  };

  const createAdmin = async (admin: { fullName: string; email: string; mobile: string; role?: AdminRole }) => {
    try {
      const res = await fetch('/api/admin/admins', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {}),
        },
        body: JSON.stringify(admin),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Failed to add admin.' };
      }
      return { success: true, message: data.message, admin: data.admin };
    } catch (err) {
      return { success: false, error: 'Network error while adding admin.' };
    }
  };

  const modifyAdmin = async (id: string, updates: Partial<AdminUser>) => {
    try {
      const res = await fetch(`/api/admin/admins/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {}),
        },
        body: JSON.stringify(updates),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Failed to update admin.' };
      }
      return { success: true, message: data.message, admin: data.admin };
    } catch (err) {
      return { success: false, error: 'Network error while updating admin.' };
    }
  };

  const removeAdmin = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/admins/${id}`, {
        method: 'DELETE',
        headers: {
          ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {}),
        },
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Failed to remove admin.' };
      }
      return { success: true, message: data.message };
    } catch (err) {
      return { success: false, error: 'Network error while removing admin.' };
    }
  };

  // ─────────────────────────────────────────────────────────────
  // CART & CHECKOUT OPERATIONS
  // ─────────────────────────────────────────────────────────────
  const addToCart = (product: Product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: Math.min(item.quantity + quantity, product.stock) }
            : item
        );
      }
      return [...prev, { product, quantity: Math.min(quantity, product.stock) }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.product.id === productId
          ? { ...item, quantity: Math.min(quantity, item.product.stock) }
          : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId: string) => {
    setWishlist(prev =>
      prev.includes(productId)
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  const buyNow = (product: Product, quantity = 1) => {
    const safeQty = Math.max(1, Math.min(quantity, product.stock));
    setBuyNowItem({ product, quantity: safeQty });
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const cancelBuyNow = () => {
    setBuyNowItem(null);
  };

  const isBuyNowMode = buyNowItem !== null;
  const activeCheckoutItems: CartItem[] = buyNowItem ? [buyNowItem] : cart;

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const cartSubtotal = cart.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );

  const cartOriginalTotal = cart.reduce(
    (acc, item) => acc + item.product.originalPrice * item.quantity,
    0
  );

  const cartSavings = cartOriginalTotal - cartSubtotal;

  // Delivery charge calculation based on admin configuration
  const isFreeDelivery = (storeSettings.enableFreeDeliveryThreshold ?? true)
    && Number(storeSettings.freeDeliveryMin) > 0
    && cartSubtotal >= Number(storeSettings.freeDeliveryMin);

  const standardDeliveryCharge = Math.max(0, Number(storeSettings.standardDeliveryCharge ?? 49));
  const deliveryCharge = cartSubtotal === 0 || standardDeliveryCharge === 0 || isFreeDelivery ? 0 : standardDeliveryCharge;

  // Full GST profile calculation
  const isGstActive = Boolean(storeSettings.gstEnabled);
  const gstRate = isGstActive ? Math.max(0, Number(storeSettings.gstPercentage) || 0) : 0;
  const gstType = storeSettings.gstType || 'inclusive';

  let gstAmount = 0;
  if (isGstActive && gstRate > 0 && cartSubtotal > 0) {
    if (gstType === 'exclusive') {
      gstAmount = Math.round((cartSubtotal * gstRate) / 100);
    } else {
      gstAmount = Math.round(cartSubtotal - (cartSubtotal / (1 + gstRate / 100)));
    }
  }

  // If exclusive, GST is added on top of subtotal + delivery; if inclusive, it is already part of subtotal
  const cartGrandTotal = cartSubtotal + deliveryCharge + (isGstActive && gstType === 'exclusive' ? gstAmount : 0);

  // Active checkout calculations (isolated for Buy Now vs Cart)
  const activeCheckoutSubtotal = activeCheckoutItems.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );

  const activeCheckoutOriginalTotal = activeCheckoutItems.reduce(
    (acc, item) => acc + item.product.originalPrice * item.quantity,
    0
  );

  const activeCheckoutSavings = activeCheckoutOriginalTotal - activeCheckoutSubtotal;

  const isCheckoutFreeDelivery = (storeSettings.enableFreeDeliveryThreshold ?? true)
    && Number(storeSettings.freeDeliveryMin) > 0
    && activeCheckoutSubtotal >= Number(storeSettings.freeDeliveryMin);

  const activeCheckoutDeliveryCharge = activeCheckoutSubtotal === 0 || standardDeliveryCharge === 0 || isCheckoutFreeDelivery ? 0 : standardDeliveryCharge;

  let activeCheckoutGstAmount = 0;
  if (isGstActive && gstRate > 0 && activeCheckoutSubtotal > 0) {
    if (gstType === 'exclusive') {
      activeCheckoutGstAmount = Math.round((activeCheckoutSubtotal * gstRate) / 100);
    } else {
      activeCheckoutGstAmount = Math.round(activeCheckoutSubtotal - (activeCheckoutSubtotal / (1 + gstRate / 100)));
    }
  }

  const totalDiscounts = couponDiscount + redeemedLoyaltyDiscount;
  const subtotalAfterDiscounts = Math.max(0, activeCheckoutSubtotal - totalDiscounts);
  const totalBeforeWallet = subtotalAfterDiscounts + activeCheckoutDeliveryCharge + (isGstActive && gstType === 'exclusive' ? activeCheckoutGstAmount : 0);
  const walletDeduction = useWalletBalance ? Math.min(walletBalance, totalBeforeWallet) : 0;
  const activeCheckoutGrandTotal = Math.max(0, totalBeforeWallet - walletDeduction);

  // Sync store settings from server on initial load and upon refresh
  const refreshStoreSettings = useCallback(async () => {
    try {
      const res = await fetch('/api/store/settings');
      const data = await res.json();
      if (data.success && data.settings) {
        setStoreSettings(prev => ({ ...DEFAULT_SETTINGS, ...data.settings }));
        try {
          localStorage.setItem('infostors_settings', JSON.stringify(data.settings));
        } catch (e) {}
      }
    } catch (e) {}
  }, []);

  useEffect(() => {
    refreshStoreSettings();
  }, [refreshStoreSettings]);

  // Place Order (Associates customerId if logged in or derives from mobile)
  const placeOrder = (
    customerDetails: CustomerDetails, 
    paymentMethod: PaymentMethod, 
    upiApp?: string, 
    upiId?: string, 
    razorpayPaymentId?: string
  ): Order => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const datePrefix = `INF-${year}${month}${day}`;

    // Generate collision-safe monotonic sequence for today
    const todaysOrders = orders.filter(o => o.orderId.startsWith(datePrefix));
    let nextNum = todaysOrders.length + 1;
    let orderId = `${datePrefix}-${String(nextNum).padStart(4, '0')}`;
    while (orders.some(o => o.orderId === orderId)) {
      nextNum++;
      orderId = `${datePrefix}-${String(nextNum).padStart(4, '0')}`;
    }

    const cleanMobile = customerDetails.phone.replace(/\D/g, '').slice(-10);
    const assignedCustomerId = customer ? customer.id : `CUS-${cleanMobile}`;
    
    const deliveryDate = new Date(now);
    deliveryDate.setDate(now.getDate() + 3);
    const formattedDelivery = deliveryDate.toLocaleDateString('en-IN', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });

    const newOrder: Order = {
      orderId,
      customerId: assignedCustomerId,
      date: new Date().toISOString(),
      customer: customerDetails,
      items: [...activeCheckoutItems],
      subtotal: activeCheckoutSubtotal,
      deliveryCharge: activeCheckoutDeliveryCharge,
      discountSavings: activeCheckoutSavings,
      tax: isGstActive && gstType === 'exclusive' ? activeCheckoutGstAmount : 0,
      taxBreakdown: {
        gstEnabled: isGstActive,
        gstRate,
        gstType,
        gstAmount: activeCheckoutGstAmount,
        storeGstin: isGstActive && storeSettings.showGstinOnInvoice ? storeSettings.gstin : undefined,
      },
      totalAmount: activeCheckoutGrandTotal,
      paymentMethod,
      upiApp,
      upiId,
      razorpayPaymentId,
      status: 'received',
      courierPartner: 'Delhivery Express',
      trackingId: `TRK${orderId.replace(/\D/g, '').slice(-8)}IN`,
      estimatedDeliveryDate: formattedDelivery,
    };

    setOrders(prev => [newOrder, ...prev]);
    setActiveOrder(newOrder);
    if (buyNowItem) {
      setBuyNowItem(null);
    } else {
      clearCart();
    }
    setIsCheckoutOpen(false);
    setIsOrderSuccessOpen(true);

    return newOrder;
  };

  const confirmOrderSuccess = (order: Order) => {
    setOrders(prev => {
      const existingIdx = prev.findIndex(o => o.orderId === order.orderId);
      if (existingIdx !== -1) {
        const copy = [...prev];
        copy[existingIdx] = order;
        return copy;
      }
      return [order, ...prev];
    });
    setActiveOrder(order);
    if (buyNowItem) {
      setBuyNowItem(null);
    } else {
      clearCart();
    }
    setIsCheckoutOpen(false);
    setIsOrderSuccessOpen(true);
  };

  // Admin capabilities - Products & Categories (server-authoritative Supabase API)
  const adminAuthHeaders = () => {
    const token = adminToken || localStorage.getItem('infostors_admin_token');
    return { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) };
  };

  const addProduct = async (product: Product) => {
    const res = await fetch('/api/products', { method: 'POST', headers: adminAuthHeaders(), body: JSON.stringify(product) });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'Failed to add product');
    setProducts(prev => [data.product, ...prev]);
  };

  const updateProduct = async (product: Product) => {
    const res = await fetch(`/api/products/${product.id}`, { method: 'PUT', headers: adminAuthHeaders(), body: JSON.stringify(product) });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'Failed to update product');
    setProducts(prev => prev.map(p => (p.id === product.id ? data.product : p)));
  };

  const deleteProduct = async (productId: string) => {
    const res = await fetch(`/api/products/${productId}`, { method: 'DELETE', headers: adminAuthHeaders() });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'Failed to delete product');
    setProducts(prev => prev.filter(p => p.id !== productId));
  };

  const addCategory = async (category: Category) => {
    const res = await fetch('/api/categories', { method: 'POST', headers: adminAuthHeaders(), body: JSON.stringify(category) });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'Failed to save category');
    setCategories(prev => { const filtered = prev.filter(c => c.id !== category.id); return [...filtered, data.category]; });
  };

  const updateCategory = async (category: Category) => {
    const res = await fetch(`/api/categories/${category.id}`, { method: 'PUT', headers: adminAuthHeaders(), body: JSON.stringify(category) });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'Failed to update category');
    setCategories(prev => prev.map(c => c.id === category.id ? data.category : c));
  };

  const deleteCategory = async (categoryId: string) => {
    if (categoryId === 'all') return;
    const res = await fetch(`/api/categories/${categoryId}`, { method: 'DELETE', headers: adminAuthHeaders() });
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.error || 'Failed to delete category');
    setCategories(prev => prev.filter(c => c.id !== categoryId));
  };

  // Admin capabilities - Orders Status & Dispatch
  const updateOrderStatus = async (
    orderId: string, 
    status: PackageStatus,
    details?: { courierPartner?: string; trackingId?: string; resolution?: string }
  ) => {
    // 1. Optimistic local state update
    setOrders(prev =>
      prev.map(o => {
        if (o.orderId === orderId) {
          return {
            ...o,
            status,
            courierPartner: details?.courierPartner !== undefined ? details.courierPartner : o.courierPartner,
            trackingId: details?.trackingId !== undefined ? details.trackingId : o.trackingId,
            resolution: details?.resolution !== undefined ? details.resolution : o.resolution,
          };
        }
        return o;
      })
    );
    setActiveOrder(prev => (prev && prev.orderId === orderId ? { ...prev, status, ...details } : prev));

    // 2. Persist directly to Primary Backend
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      if (details?.courierPartner || details?.trackingId) {
        await fetch(`/api/admin/orders/${orderId}/dispatch`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({
            courierPartner: details.courierPartner,
            trackingId: details.trackingId,
            orderStatus: status === 'received' ? 'confirmed' : status === 'dispatched' ? 'shipped' : status,
          }),
        });
      } else {
        await fetch(`/api/admin/orders/${orderId}/status`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ status }),
        });
      }
    } catch (err) {
      console.warn('Backend order update notice:', err);
    }

    return { success: true, message: `Order #${orderId} status updated to ${status}.` };
  };

  // Admin capabilities - Store Settings
  const updateStoreSettings = async (settings: Partial<StoreSettings>): Promise<{ success: boolean; message?: string; error?: string }> => {
    try {
      const token = adminToken || localStorage.getItem('infostors_admin_token');
      const res = await fetch('/api/admin/store/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(settings),
      });

      const data = await res.json();
      if (data.success && data.settings) {
        setStoreSettings(data.settings);
        try {
          localStorage.setItem('infostors_settings', JSON.stringify(data.settings));
        } catch (e) {}
        return { success: true, message: data.message || 'Store settings updated successfully.' };
      }
      return { success: false, error: data.error || 'Failed to save settings to server.' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to connect to backend server.' };
    }
  };

  return (
    <ShopContext.Provider
      value={{
        products,
        categories,
        cart,
        wishlist,
        orders,
        storeSettings,
        searchQuery,
        selectedCategory,
        selectedSection,
        sortBy,
        selectedProduct,
        isCartOpen,
        isWishlistOpen,
        isCheckoutOpen,
        isAccountOpen,
        isAdminOpen,
        isOrderSuccessOpen,
        activeOrder,
        policyModal,
        userEmail,
        setSearchQuery,
        setSelectedCategory,
        setSelectedSection,
        setSortBy,
        setSelectedProduct,
        setIsCartOpen,
        setIsWishlistOpen,
        setIsCheckoutOpen: handleSetIsCheckoutOpen,
        setIsAccountOpen,
        setIsAdminOpen,
        setIsOrderSuccessOpen,
        setActiveOrder,
        setPolicyModal,
        setUserEmail,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        toggleWishlist,
        isInWishlist,
        buyNow,
        buyNowItem,
        isBuyNowMode,
        cancelBuyNow,
        activeCheckoutItems,
        activeCheckoutSubtotal,
        activeCheckoutSavings,
        activeCheckoutDeliveryCharge,
        activeCheckoutGstAmount,
        activeCheckoutGrandTotal,
        cartCount,
        cartSubtotal,
        cartSavings,
        deliveryCharge,
        gstAmount,
        gstRate,
        isGstActive,
        gstType,
        cartGrandTotal,

        deliveryLocation,
        setDeliveryLocation,
        isLocationModalOpen,
        setIsLocationModalOpen,

        placeOrder,
        confirmOrderSuccess,
        addProduct,
        updateProduct,
        deleteProduct,
        addCategory,
        updateCategory,
        deleteCategory,
        updateOrderStatus,
        updateStoreSettings,
        refreshStoreSettings,

        // Customer
        customer,
        customerToken,
        isCustomerLoading,
        customerOrders,
        customerRegister,
        customerLogin,
        customerLogout,
        customerUpdateProfile,
        customerChangePassword,
        customerForgotPassword,
        customerResetPassword,
        resetTokenParam,
        setResetTokenParam,

        // Admin
        adminProfile,
        adminToken,
        isAdminAuthenticated,
        adminGoogleLogin,
        adminEmailPasswordLogin,
        adminLogout,
        fetchAdminList,
        createAdmin,
        modifyAdmin,
        removeAdmin,

        // Feature Flags
        featureFlags,
        isFeatureEnabled,
        updateFeatureFlags,

        // Theme & Dark Mode
        themeMode,
        setThemeMode,
        themeSettings,
        updateThemeSettings,

        // Layout Settings
        layoutSettings,
        updateLayoutSettings,

        // 1. Coupons
        coupons,
        activeCoupons,
        appliedCoupon,
        couponDiscount,
        applyCoupon,
        removeCoupon,
        saveCoupon,
        deleteCoupon,

        // 2. Flash Sales
        flashSales,
        activeFlashSales,
        saveFlashSale,
        deleteFlashSale,

        // 3. Reviews & Ratings
        reviews,
        fetchProductReviews,
        submitReview,
        moderateReview,
        deleteReview,

        // 4. Returns
        returns,
        customerReturns,
        submitReturnRequest,
        updateReturnStatus,

        // 5. Refunds
        refunds,
        processRefund,
        updateRefundStatus,

        // 6. Loyalty & Rewards
        loyaltyBalance,
        loyaltyTransactions,
        redeemedLoyaltyDiscount,
        redeemLoyaltyPoints,
        clearLoyaltyRedemption,

        // 7. Customer Wallet
        walletBalance,
        walletTransactions,
        useWalletBalance,
        setUseWalletBalance,
        walletDeduction,

        // 8. Promotional Offers
        offers,
        activeOffers,
        saveOffer,
        deleteOffer,

        // 9. Multi-Vendor
        vendors,
        saveVendor,
        deleteVendor,

        // 10. Advanced Reports
        fetchAdvancedReports,
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
