# INFOSTORS — SUPABASE ROW LEVEL SECURITY (RLS) & ACCESS CONTROL

**Target Project ID:** `oewerfftzqklptdsdfrm`  
**Security Standard:** Strict Customer Isolation + Role-Based Access Control (RBAC)  
**Classification:** DEFENSE-IN-DEPTH ARCHITECTURE  

---

## 1. ROW LEVEL SECURITY CONSTITUTION

In the INFOSTORS ecosystem, security is enforced **at the database engine level (PostgreSQL)**, ensuring that frontend client manipulation, forged API requests, or direct Supabase REST API queries cannot bypass access controls.

### Core Principles:
1. **100% RLS Coverage**: Row Level Security is enabled on **all 20 public tables**.
2. **Zero Open Writes**: No public table allows anonymous or unverified `INSERT`, `UPDATE`, or `DELETE`.
3. **Strict Customer Isolation**: Authenticated customers can read and mutate **only their own** records (`auth_user_id = auth.uid()`).
4. **Granular Admin RBAC**: Administrative mutations require explicit membership in `admin_users` and verified permissions in `role_permissions`.
5. **Immutable Security Records**: `audit_logs` has zero `UPDATE` or `DELETE` policies, guaranteeing non-repudiation.

---

## 2. INSECURE DIRECT OBJECT REFERENCE (IDOR) DEFENSES

| Attack Vector | Attacker Action | Database Defense Mechanism | Result |
|---|---|---|---|
| **Order Hijacking** | Customer A tampers with order ID to view Customer B's order: `GET /orders?id=eq.INF-20260926-0002` | `orders` SELECT policy requires `customer_id IN (SELECT id FROM customers WHERE auth_user_id = auth.uid())` | Returns `404 / Empty array` |
| **Address Modification** | Customer A attempts `UPDATE /customer_addresses?id=eq.<Customer B UUID>` | `customer_addresses` UPDATE policy requires `customer_id IN (SELECT id FROM customers WHERE auth_user_id = auth.uid())` | Database rejects update (0 rows affected) |
| **Price Tampering** | Shopper sends crafted `subtotal: 1.00` in order creation payload | Server recalculates totals independently; `order_items` unit prices checked against `products.price` | Tampered amounts rejected |
| **Privilege Escalation** | Regular user attempts `UPDATE /admin_users` to grant themselves `main_admin` | `admin_users` has RLS enabled; non-admins have zero write policies | Query returns `403 Forbidden` |
| **Payment Secrets Leak** | Shopper queries `GET /payment_settings` via REST API | `payment_settings` SELECT policy requires `public.has_permission('payments.read')`; keys are AES-256 encrypted | Query returns `403 Forbidden` |

---

## 3. SECURITY DEFINER HELPER FUNCTIONS

These functions run with elevated privileges (`SECURITY DEFINER`) to evaluate permissions safely without exposing raw user tables:

```sql
-- 1. Check if user is an active administrator
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.admin_users
        WHERE auth_user_id = auth.uid()
          AND status = 'active'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- 2. Check if user is the Primary Main Administrator
CREATE OR REPLACE FUNCTION public.is_main_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.admin_users
        WHERE auth_user_id = auth.uid()
          AND role = 'main_admin'
          AND status = 'active'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- 3. Check granular permission
CREATE OR REPLACE FUNCTION public.has_permission(required_permission TEXT)
RETURNS BOOLEAN AS $$
BEGIN
    IF public.is_main_admin() THEN
        RETURN true;
    END IF;

    RETURN EXISTS (
        SELECT 1 
        FROM public.admin_users au
        JOIN public.role_permissions rp ON au.role = rp.role_id
        WHERE au.auth_user_id = auth.uid()
          AND au.status = 'active'
          AND rp.permission_id = required_permission
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;
```

---

## 4. COMPLETE RLS POLICY MATRIX

| Table Name | Policy Action | Target Role / Identity | Policy Definition / Condition |
|---|---|---|---|
| `products` | `SELECT` | Public / Shoppers | `is_active = true OR public.is_admin()` |
| `products` | `ALL` | Staff with `products.write` | `public.has_permission('products.write')` |
| `categories` | `SELECT` | Public / Shoppers | `true` (Taxonomy is public) |
| `categories` | `ALL` | Staff with `products.write` | `public.has_permission('products.write')` |
| `customers` | `SELECT` | Owner / Customer Support | `auth_user_id = auth.uid() OR public.has_permission('customers.read')` |
| `customers` | `UPDATE` | Owner / Customer Support | `auth_user_id = auth.uid() OR public.has_permission('customers.read')` |
| `customer_addresses` | `ALL` | Owner Customer | `customer_id IN (SELECT id FROM customers WHERE auth_user_id = auth.uid())` |
| `orders` | `SELECT` | Owner / Fulfillment Staff | `customer_id IN (SELECT id FROM customers WHERE auth_user_id = auth.uid()) OR public.has_permission('orders.read')` |
| `orders` | `INSERT` | Checkout Process | `true` (Enforced with status = 'pending') |
| `orders` | `UPDATE` | Fulfillment Staff | `public.has_permission('orders.write')` |
| `orders` | `DELETE` | Main Admin Only | `public.is_main_admin()` (Via Two-Man Rule) |
| `store_settings` | `SELECT` | Public / Shoppers | `true` (Brand profile, delivery fee, helpline) |
| `store_settings` | `UPDATE` | Staff with `settings.write` | `public.has_permission('settings.write')` |
| `payment_settings` | `SELECT` | Staff with `payments.read` | `public.has_permission('payments.read')` (NEVER public) |
| `payment_settings` | `UPDATE` | Main Admin Only | `public.is_main_admin()` |
| `delete_requests` | `SELECT` | All Staff | `public.is_admin()` |
| `delete_requests` | `INSERT` | All Staff | `public.is_admin()` |
| `delete_requests` | `UPDATE` | Main Admin Only | `public.is_main_admin()` |
| `audit_logs` | `SELECT` | Security Auditors | `public.has_permission('activity.read')` |
| `audit_logs` | `INSERT` | Internal Triggers / System | `true` (Zero UPDATE or DELETE policies) |
| `customer_messages` | `SELECT` | Target Customer / Staff | `customer_id IN (SELECT id FROM customers WHERE auth_user_id = auth.uid()) OR public.is_admin()` |
| `notifications` | `SELECT` | Target Audience / Public | `target_audience = 'all' OR target_customer_id IN (...) OR public.is_admin()` |

---

## 5. STORAGE BUCKET SECURITY POLICIES

| Bucket | Access | Allowed MIME Types | Max Size | RLS Read Policy | RLS Upload / Manage Policy |
|---|---|---|---|---|---|
| `product-images` | Public | JPG, PNG, WEBP, SVG | 10 MB | Public read: `bucket_id = 'product-images'` | `public.has_permission('products.write')` |
| `store-assets` | Public | JPG, PNG, WEBP, SVG, JSON | 5 MB | Public read: `bucket_id = 'store-assets'` | `public.has_permission('settings.write')` |
| `invoices` | Private | PDF | 10 MB | `public.is_admin() OR name LIKE (auth.uid() || '/%')` | `public.is_admin() OR auth.role() = 'service_role'` |
| `shipping-labels` | Private | PDF, PNG | 10 MB | `public.has_permission('orders.write')` | `public.has_permission('orders.write')` |
